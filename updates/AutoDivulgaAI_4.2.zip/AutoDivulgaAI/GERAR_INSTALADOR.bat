@echo off
setlocal
cd /d "%~dp0"
title AutoDivulga AI - gerar instalador
echo ============================================================
echo  Gera a versao instalavel do AutoDivulga AI (nao precisa de Python
echo  no computador de quem for usar). Leva de 3 a 10 minutos.
echo ============================================================
if not exist ".venv\Scripts\python.exe" (
  echo Abra o INICIAR.bat uma vez antes, para criar o ambiente do programa.
  pause & exit /b 1
)
set "VPY=%~dp0.venv\Scripts\python.exe"
echo Instalando o PyInstaller...
"%VPY%" -m pip install --upgrade pyinstaller >> build.log 2>&1 || goto erro
if exist dist\AutoDivulgaAI rmdir /s /q dist\AutoDivulgaAI
echo Gerando o programa (.exe)...
"%VPY%" -m PyInstaller --noconfirm --clean --name AutoDivulgaAI --onedir --console ^
  --add-data "templates;templates" --add-data "static;static" --add-data "cloudflare;cloudflare" ^
  --collect-all googleapiclient --hidden-import google_auth_oauthlib.flow --hidden-import tkinter ^
  launcher.py >> build.log 2>&1 || goto erro
copy /y README.md dist\AutoDivulgaAI\ >nul
copy /y config.env.example dist\AutoDivulgaAI\ >nul
echo.
echo Programa gerado em: %~dp0dist\AutoDivulgaAI
set "ISCC="
for %%I in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LocalAppData%\Programs\Inno Setup 6\ISCC.exe") do if exist %%I set "ISCC=%%~I"
if not defined ISCC (
  echo Inno Setup nao encontrado: tentando instalar pelo winget...
  winget install -e --id JRSoftware.InnoSetup --accept-package-agreements --accept-source-agreements >> build.log 2>&1
  for %%I in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LocalAppData%\Programs\Inno Setup 6\ISCC.exe") do if exist %%I set "ISCC=%%~I"
)
if defined ISCC (
  echo Gerando o instalador ^(Setup.exe^)...  
  "%ISCC%" /Qp instalador.iss >> build.log 2>&1 || goto erro
  echo.
  echo PRONTO! Instalador em: %~dp0exports
  explorer "%~dp0exports"
) else (
  echo Sem o Inno Setup: use a pasta dist\AutoDivulgaAI compactada em .zip para distribuir.
  explorer "%~dp0dist"
)
pause
exit /b 0
:erro
echo.
echo Deu erro. Veja os detalhes no arquivo build.log desta pasta.
pause
exit /b 1
