"""Publicadores por plataforma.

Cada publicador recebe uma publicacao da fila e devolve um PublishResult.
Hoje existe o publicador assistido (prepara tudo e avisa voce). Nas etapas 2 e 3
os publicadores reais do YouTube e do TikTok serao registrados aqui com register().
"""
from dataclasses import dataclass


class TemporaryError(Exception):
    """Falha passageira (internet, limite de cota): o agendador tenta de novo mais tarde."""


class PermanentError(Exception):
    """Falha que nao se resolve tentando de novo (arquivo faltando, conta desconectada)."""


@dataclass
class PublishResult:
    status: str          # "Publicada" ou "Aguardando você"
    message: str = ""
    url: str = ""


UPLOAD_PAGES = {
    "YouTube": "https://www.youtube.com/upload",
    "TikTok": "https://www.tiktok.com/upload",
}


class AssistedPublisher:
    """Sem conta conectada: deixa o material pronto e pede uma confirmacao sua."""
    name = "Assistido"
    automatic = False

    def __init__(self, platform):
        self.platform = platform

    def is_connected(self):
        return False

    def publish(self, pub):
        return PublishResult("Aguardando você",
                             f"Material pronto. Conta do {self.platform} ainda não conectada: "
                             "abra a publicação, copie o texto e envie o vídeo.")


_registry = {}


def register(platform, publisher):
    _registry[platform] = publisher


def get(platform):
    pub = _registry.get(platform)
    if pub is not None and pub.is_connected():
        return pub
    return AssistedPublisher(platform)


def status_by_platform():
    return {p: get(p).name for p in UPLOAD_PAGES}
