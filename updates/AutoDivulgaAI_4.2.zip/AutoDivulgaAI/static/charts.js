/* AutoDivulga AI · graficos leves em SVG (sem bibliotecas externas, funciona offline) */
(function(){
const NS='http://www.w3.org/2000/svg';
const css=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const fmt=n=>{n=+n||0;if(n>=1e6)return(n/1e6).toFixed(1).replace('.',',')+' mi';if(n>=1e4)return Math.round(n/1e3)+' mil';if(n>=1e3)return(n/1e3).toFixed(1).replace('.',',')+' mil';return String(Math.round(n))};
function el(tag,attrs,parent,text){const e=document.createElementNS(NS,tag);for(const k in attrs)e.setAttribute(k,attrs[k]);if(text!=null)e.textContent=text;if(parent)parent.appendChild(e);return e}
function svg(box,w,h){box.innerHTML='';const s=el('svg',{viewBox:`0 0 ${w} ${h}`,class:'chart-svg',role:'img'},box);return s}
function niceMax(v){if(v<=0)return 1;const p=Math.pow(10,Math.floor(Math.log10(v)));const n=v/p;return (n<=1?1:n<=2?2:n<=5?5:10)*p}
function grid(s,x0,x1,y0,y1,max,ticks){const c=css('--line-soft'),t=css('--faint');
  for(let i=0;i<=ticks;i++){const y=y1-(y1-y0)*i/ticks;el('line',{x1:x0,x2:x1,y1:y,y2:y,stroke:c,'stroke-width':1},s);
    el('text',{x:x0-8,y:y+4,'text-anchor':'end','font-size':11,fill:t},s,fmt(max*i/ticks))}}
function tip(node,text){el('title',{},node,text)}

/* colunas verticais: items=[{label,value,color,title}] */
function columns(box,items,o={}){
  if(!items.length){box.innerHTML='<p class="muted small">Sem dados ainda.</p>';return}
  const W=Math.max(box.clientWidth||640,320),H=o.height||240,L=52,R=10,T=14,B=o.rotate?62:34;
  const s=svg(box,W,H),max=niceMax(Math.max(...items.map(i=>i.value)));grid(s,L,W-R,T,H-B,max,4);
  const step=(W-L-R)/items.length,bw=Math.max(Math.min(step*.68,46),3);
  items.forEach((it,i)=>{const h=(H-B-T)*(it.value/max),x=L+step*i+(step-bw)/2,y=H-B-h;
    const r=el('rect',{x,y,width:bw,height:Math.max(h,1),rx:3,fill:it.color||css('--signal'),class:'bar'},s);
    tip(r,(it.title||it.label)+': '+fmt(it.value)+(o.unit||''));
    if(o.values&&items.length<=16)el('text',{x:x+bw/2,y:y-4,'text-anchor':'middle','font-size':10.5,fill:css('--muted')},s,fmt(it.value));
    const every=Math.ceil(items.length/(o.rotate?24:12));
    if(i%every===0){const tx=x+bw/2,ty=H-B+15;const t=el('text',{x:tx,y:ty,'text-anchor':o.rotate?'end':'middle','font-size':10.5,fill:css('--faint')},s,it.label);
      if(o.rotate)t.setAttribute('transform',`rotate(-40 ${tx} ${ty})`)}});
}

/* barras horizontais (ranking): items=[{label,value,sub,href}] */
function ranking(box,items,o={}){
  if(!items.length){box.innerHTML='<p class="muted small">Sem dados ainda.</p>';return}
  const max=Math.max(...items.map(i=>i.value))||1;box.innerHTML='';
  items.forEach((it,i)=>{const row=document.createElement(it.href?'a':'div');row.className='rank';if(it.href){row.href=it.href;row.target='_blank';row.rel='noopener'}
    row.innerHTML=`<span class="rank-n">${i+1}</span><span class="rank-body"><span class="rank-label"></span><span class="rank-track"><i style="width:${Math.max(it.value*100/max,1.5)}%"></i></span></span><b class="rank-v">${fmt(it.value)}</b>`;
    row.querySelector('.rank-label').textContent=it.label+(it.sub?' · '+it.sub:'');box.appendChild(row)});
}

/* linha: points=[{label,value}] */
function line(box,points,o={}){
  if(points.length<2){box.innerHTML=`<div class="chart-empty">${o.empty||'O gráfico aparece a partir do 2º dia de histórico.'}</div>`;return}
  const W=Math.max(box.clientWidth||640,320),H=o.height||220,L=52,R=14,T=14,B=30;
  const s=svg(box,W,H),vals=points.map(p=>p.value),max=niceMax(Math.max(...vals));grid(s,L,W-R,T,H-B,max,4);
  const X=i=>L+(W-L-R)*(points.length===1?.5:i/(points.length-1)),Y=v=>H-B-(H-B-T)*(v/max);
  const color=o.color||css('--signal');
  const area=`M${X(0)},${H-B} `+points.map((p,i)=>`L${X(i)},${Y(p.value)}`).join(' ')+` L${X(points.length-1)},${H-B} Z`;
  el('path',{d:area,fill:color,opacity:.12},s);
  el('path',{d:points.map((p,i)=>(i?'L':'M')+X(i)+','+Y(p.value)).join(' '),fill:'none',stroke:color,'stroke-width':2.2,'stroke-linejoin':'round'},s);
  const every=Math.ceil(points.length/10);
  points.forEach((p,i)=>{const c=el('circle',{cx:X(i),cy:Y(p.value),r:3.5,fill:color},s);tip(c,p.label+': '+fmt(p.value)+(o.unit||''));
    if(i%every===0||i===points.length-1)el('text',{x:X(i),y:H-B+16,'text-anchor':'middle','font-size':10.5,fill:css('--faint')},s,p.label)});
}
window.ADCharts={columns,ranking,line,fmt,css};
})();
