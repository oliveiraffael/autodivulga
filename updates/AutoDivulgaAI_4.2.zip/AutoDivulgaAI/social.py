"""Anuncio automatico de episodio novo em redes abertas: Bluesky, Mastodon e canal do Telegram.

Regra: 1 anuncio por campanha por rede, so no SEU perfil/canal, quando a campanha fica "Publicada"
com o link do video (ou quando voce clica em "Anunciar agora"). Tudo por APIs oficiais e gratuitas.
"""
import re
from datetime import datetime, timezone

import requests

import links
import telegram
from core import VERSION, db, log, now_iso, save_env, setting, _lock

UA = f"AutoDivulgaAI/{VERSION}"
TIMEOUT = 25
NETWORKS = {"bluesky": "Bluesky", "mastodon": "Mastodon", "telegram": "Telegram"}
SRC = {"bluesky": "bs", "mastodon": "md", "telegram": "tg"}
VIDEO_SQL = ("c.video_url LIKE '%youtu.be/%' OR c.video_url LIKE '%youtube.com/watch%' "
             "OR c.video_url LIKE '%youtube.com/shorts/%' OR c.video_url LIKE '%tiktok.com/%/video/%'")
VIDEO_LINK = re.compile(r"(youtu\.be/|youtube\.com/(watch|shorts/)|tiktok\.com/@[^/]+/video/)")


class SocialError(Exception):
    pass


# ---------------- configuracao ----------------
def bluesky_on():
    return bool(setting("BSKY_HANDLE") and setting("BSKY_APP_PASSWORD"))


def mastodon_on():
    return bool(setting("MASTO_INSTANCE") and setting("MASTO_TOKEN"))


def configured():
    return {"bluesky": bluesky_on(), "mastodon": mastodon_on(), "telegram": telegram.is_configured()}


def auto_enabled(net):
    key = {"bluesky": "BSKY_AUTO", "mastodon": "MASTO_AUTO", "telegram": "TG_AUTO"}[net]
    return configured()[net] and setting(key) != "off"


# ---------------- texto ----------------
def compose(c, limit, link_url):
    tags = " ".join(t for t in (c["hashtags"] or "").split() if t.startswith("#"))[:120]
    body = re.sub(r"#\w+", "", c["caption"] or c["title"] or "").strip()
    body = re.sub(r"\s+\n", "\n", body)
    room = limit - len(link_url) - len(tags) - 6
    if room < 40:
        tags, room = "", limit - len(link_url) - 4
    if len(body) > room:
        body = body[:room - 1].rsplit(" ", 1)[0] + "…"
    return "\n\n".join(x for x in (body, link_url, tags) if x)


# ---------------- Bluesky ----------------
def _bsky_pds():
    return (setting("BSKY_PDS") or "https://bsky.social").rstrip("/")


def bsky_session(handle=None, password=None):
    try:
        r = requests.post(_bsky_pds() + "/xrpc/com.atproto.server.createSession", timeout=TIMEOUT,
                          json={"identifier": (handle or setting("BSKY_HANDLE")).strip().lstrip("@"),
                                "password": (password or setting("BSKY_APP_PASSWORD")).strip()})
        data = r.json()
    except Exception as e:
        raise SocialError(f"o Bluesky não respondeu ({e.__class__.__name__})") from e
    if r.status_code != 200:
        msg = data.get("message") or data.get("error") or r.status_code
        if r.status_code == 401:
            msg = "usuário ou senha de app incorretos (use uma senha de app, não a senha da conta)"
        raise SocialError(f"Bluesky: {msg}")
    return data


def _facets(text, url):
    facets, raw = [], text.encode("utf-8")
    start = raw.find(url.encode("utf-8"))
    if start >= 0:
        facets.append({"index": {"byteStart": start, "byteEnd": start + len(url.encode("utf-8"))},
                       "features": [{"$type": "app.bsky.richtext.facet#link", "uri": url}]})
    for m in re.finditer(r"#(\w+)", text):
        b0 = len(text[:m.start()].encode("utf-8"))
        b1 = b0 + len(m.group(0).encode("utf-8"))
        facets.append({"index": {"byteStart": b0, "byteEnd": b1},
                       "features": [{"$type": "app.bsky.richtext.facet#tag", "tag": m.group(1)}]})
    return facets


def bluesky_post(c, link_url):
    s = bsky_session()
    auth = {"Authorization": f"Bearer {s['accessJwt']}", "User-Agent": UA}
    text = compose(c, 290, link_url)
    record = {"$type": "app.bsky.feed.post", "text": text, "langs": ["pt"], "facets": _facets(text, link_url),
              "createdAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")}
    external = {"uri": link_url, "title": (c["title"] or "")[:200],
                "description": re.sub(r"#\w+", "", c["caption"] or "").strip()[:280]}
    thumb = _thumb_blob(c, auth)
    if thumb:
        external["thumb"] = thumb
    record["embed"] = {"$type": "app.bsky.embed.external", "external": external}
    r = requests.post(_bsky_pds() + "/xrpc/com.atproto.repo.createRecord", headers=auth, timeout=TIMEOUT,
                      json={"repo": s["did"], "collection": "app.bsky.feed.post", "record": record})
    if r.status_code != 200:
        raise SocialError(f"Bluesky recusou o post: {r.json().get('message', r.status_code)}")
    rkey = r.json()["uri"].rsplit("/", 1)[-1]
    return f"https://bsky.app/profile/{s.get('handle', setting('BSKY_HANDLE'))}/post/{rkey}"


def _thumb_blob(c, auth):
    import partners
    url = partners.thumb_for(c["video_url"])
    if not url:
        return None
    try:
        img = requests.get(url, timeout=TIMEOUT)
        if img.status_code != 200 or len(img.content) > 950_000:
            return None
        r = requests.post(_bsky_pds() + "/xrpc/com.atproto.repo.uploadBlob", data=img.content, timeout=TIMEOUT,
                          headers={**auth, "Content-Type": img.headers.get("Content-Type", "image/jpeg")})
        return r.json().get("blob") if r.status_code == 200 else None
    except Exception:
        return None


# ---------------- Mastodon ----------------
def _masto(method, path, token=None, inst=None, **kw):
    inst = (inst or setting("MASTO_INSTANCE")).strip().rstrip("/")
    if inst and not inst.startswith("http"):
        inst = "https://" + inst
    if "@" in inst.split("//", 1)[-1]:  # "https://usuario@servidor" -> "https://servidor"
        scheme, rest = inst.split("//", 1)
        inst = scheme + "//" + rest.split("@")[-1]
    try:
        r = requests.request(method, inst + path, timeout=TIMEOUT, **kw,
                             headers={"Authorization": f"Bearer {token or setting('MASTO_TOKEN')}", "User-Agent": UA})
        data = r.json()
    except Exception as e:
        raise SocialError(f"o Mastodon não respondeu ({e.__class__.__name__})") from e
    if r.status_code >= 400:
        msg = data.get("error", r.status_code) if isinstance(data, dict) else r.status_code
        if r.status_code == 401:
            msg = "token inválido ou sem a permissão write:statuses"
        raise SocialError(f"Mastodon: {msg}")
    return data, inst


def mastodon_verify(inst, token):
    data, inst = _masto("GET", "/api/v1/accounts/verify_credentials", token=token, inst=inst)
    return data.get("acct", ""), inst


def mastodon_post(c, link_url):
    data, _ = _masto("POST", "/api/v1/statuses",
                     data={"status": compose(c, 480, link_url), "visibility": "public", "language": "pt"})
    return data.get("url", "")


def telegram_post(c, link_url):
    telegram.send(f"🎬 {c['title']}\n\n{compose(c, 900, link_url)}")
    return ""


POSTERS = {"bluesky": bluesky_post, "mastodon": mastodon_post, "telegram": telegram_post}


# ---------------- fila ----------------
def init():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS announcements (
            campaign_id INTEGER NOT NULL, network TEXT NOT NULL, url TEXT DEFAULT '', error TEXT DEFAULT '',
            status TEXT DEFAULT 'ok', at TEXT NOT NULL, PRIMARY KEY (campaign_id, network))""")
    for net in NETWORKS:
        if configured()[net] and setting(f"ANNOUNCE_MARKED_{net.upper()}") != "1":
            mark_existing(net)


def mark_existing(net):
    """Ao ligar uma rede, nao anunciar os episodios antigos de uma vez."""
    with _lock, db() as con:
        for r in con.execute("SELECT id FROM campaigns WHERE status='Publicada'").fetchall():
            con.execute("INSERT OR IGNORE INTO announcements(campaign_id, network, status, at) VALUES (?,?,?,?)",
                        (r["id"], net, "ignorado (antigo)", now_iso()))
    save_env({f"ANNOUNCE_MARKED_{net.upper()}": "1"})


def is_video_link(url):
    return bool(VIDEO_LINK.search(url or ""))


def announce(cid, net):
    with db() as con:
        c = con.execute("SELECT * FROM campaigns WHERE id=?", (cid,)).fetchone()
    if not c or not is_video_link(c["video_url"]):
        raise SocialError("a campanha precisa do link do vídeo (não do canal)")
    link_url = links.link(c, SRC[net])
    try:
        url = POSTERS[net](c, link_url)
        status, error = "ok", ""
    except (SocialError, telegram.TelegramError) as e:
        url, status, error = "", "erro", str(e)
    with _lock, db() as con:
        con.execute("""INSERT INTO announcements(campaign_id, network, url, error, status, at) VALUES (?,?,?,?,?,?)
                       ON CONFLICT(campaign_id, network) DO UPDATE SET url=excluded.url, error=excluded.error,
                       status=excluded.status, at=excluded.at""", (cid, net, url, error, status, now_iso()))
    log(f"Anúncio no {NETWORKS[net]} da campanha #{cid}: " + ("enviado" if status == "ok" else f"falhou ({error})"))
    if status != "ok":
        raise SocialError(error)
    return url


def announce_all(cid):
    """Botao 'Anunciar agora': todas as redes ligadas que ainda nao receberam esta campanha."""
    done, failed = [], []
    with db() as con:
        sent = {r["network"] for r in con.execute(
            "SELECT network FROM announcements WHERE campaign_id=? AND status='ok'", (cid,))}
    for net, ok in configured().items():
        if ok and net not in sent:
            try:
                announce(cid, net)
                done.append(NETWORKS[net])
            except SocialError as e:
                failed.append(f"{NETWORKS[net]}: {e}")
    return done, failed


def history(cid):
    with db() as con:
        return con.execute("SELECT * FROM announcements WHERE campaign_id=? ORDER BY at DESC", (cid,)).fetchall()


def run_due():
    """Agendador: anuncia campanhas recem-publicadas (1 envio por chamada, para nao travar o laco)."""
    for net in NETWORKS:
        if not auto_enabled(net):
            continue
        with db() as con:
            row = con.execute(f"""SELECT c.id FROM campaigns c WHERE c.status='Publicada' AND ({VIDEO_SQL})
                                 AND NOT EXISTS (SELECT 1 FROM announcements a WHERE a.campaign_id=c.id AND a.network=?)
                                 ORDER BY c.id LIMIT 1""", (net,)).fetchone()
        if row:
            try:
                announce(row["id"], net)
            except SocialError:
                pass
            return 1
    return 0
