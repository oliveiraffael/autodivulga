"""Texto proprio para cada rede: titulo (YouTube), legenda e hashtags diferentes para YouTube,
TikTok, Instagram e Facebook. Fica guardado na campanha (coluna per_net, em JSON)."""
import json, threading

from core import db, now, now_iso, _lock

NETS = ["YouTube", "TikTok", "Instagram", "Facebook"]
HINTS = {
    "YouTube": "YouTube/Shorts: título com até 70 caracteres que gere curiosidade; descrição de 2 a 3 frases "
               "contando o que a pessoa vai ver; 3 a 5 hashtags.",
    "TikTok": "TikTok: legenda curta (até 150 caracteres) com gancho logo no início, linguagem falada; "
              "3 a 5 hashtags, incluindo 1 ou 2 amplas.",
    "Instagram": "Instagram Reels: primeira linha é o gancho, depois 1 a 2 frases e uma pergunta no fim "
                 "para puxar comentários; 5 a 8 hashtags de nicho.",
    "Facebook": "Facebook Reels: tom de conversa, 1 a 2 frases e uma pergunta no fim; no máximo 3 hashtags.",
}
state = {}        # campaign_id -> "rodando" | "ok" | "erro: ..."


def init():
    with db() as con:
        cols = {r["name"] for r in con.execute("PRAGMA table_info(campaigns)")}
        if "per_net" not in cols:
            con.execute("ALTER TABLE campaigns ADD COLUMN per_net TEXT DEFAULT ''")


def get_campaign_row(cid):
    with db() as con:
        return con.execute("SELECT * FROM campaigns WHERE id=?", (cid,)).fetchone()


def get(c):
    """Dicionario {rede: {titulo, legenda, hashtags}} da campanha (vazio se ainda nao gerado)."""
    try:
        raw = c["per_net"] if "per_net" in c.keys() else ""
        data = json.loads(raw or "{}")
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def texts_for(c, platform):
    """(titulo, legenda, hashtags) para a rede, ou None se a campanha nao tem texto proprio para ela."""
    d = get(c).get(platform)
    if not d or not (d.get("legenda") or "").strip():
        return None
    return ((d.get("titulo") or c["title"])[:100], d["legenda"].strip(), (d.get("hashtags") or c["hashtags"]).strip())


def _tags(v):
    if isinstance(v, list):
        v = " ".join(str(x) for x in v)
    tags = []
    for t in str(v or "").replace(",", " ").split():
        t = "#" + t.lstrip("#")
        if len(t) > 1 and t.lower() not in {x.lower() for x in tags}:
            tags.append(t)
    return " ".join(tags[:10])


def _fallback(c, nets):
    import ai_writer
    out = {}
    for n in nets:
        cap, tags = ai_writer._fallback(c["title"], c["topic"], n)
        out[n] = {"titulo": c["title"][:100], "legenda": cap, "hashtags": tags}
    return out


def generate(cid, nets):
    """Pede a IA um texto por rede (1 chamada so). Sem IA, usa os textos prontos de cada rede."""
    import ai_writer
    c = get_campaign_row(cid)
    if not c:
        state[cid] = "erro: campanha não encontrada"
        return
    state[cid] = "rodando"
    try:
        lines = "\n".join(f"- {n}: {HINTS[n]}" for n in nets)
        keys = ", ".join(f'"{n}": {{"titulo": "...", "legenda": "...", "hashtags": ["#..."]}}' for n in nets)
        prompt = (f"Escreva o texto de divulgação do mesmo vídeo, adaptado para cada rede social.\n"
                  f"Título do vídeo: {c['title']}\nTema: {c['topic'] or 'não informado'}\n"
                  f"Público: {c['audience'] or 'público geral'}\n"
                  f"Texto base (pode reaproveitar ideias): {(c['caption'] or '')[:400]}\n\n"
                  f"Regras de cada rede:\n{lines}\n\n"
                  f"As legendas não levam hashtags (elas vão no campo hashtags). Escreva em português do Brasil.\n"
                  f"Responda SOMENTE com um JSON assim: {{{keys}}}")
        obj = ai_writer._ask_json(prompt) or {}
        data, used_ai = _fallback(c, nets), False
        for n in nets:
            d = obj.get(n) if isinstance(obj, dict) else None
            if isinstance(d, dict) and str(d.get("legenda", "")).strip():
                data[n] = {"titulo": str(d.get("titulo") or c["title"]).strip()[:100],
                           "legenda": str(d["legenda"]).strip()[:2000],
                           "hashtags": _tags(d.get("hashtags")) or data[n]["hashtags"]}
                used_ai = True
        save(cid, data, refresh_pubs=True)
        state[cid] = "ok" if used_ai else "ok: a IA não respondeu, usei textos prontos de cada rede"
    except Exception as e:
        state[cid] = f"erro: {e}"


def generate_async(cid, nets):
    if state.get(cid) == "rodando":
        return False
    state[cid] = "rodando"
    threading.Thread(target=generate, args=(cid, nets), name=f"textos-{cid}", daemon=True).start()
    return True


def save(cid, data, refresh_pubs=False):
    """Grava os textos. Com refresh_pubs, atualiza as publicacoes ainda agendadas que nao foram editadas a mao."""
    old = get_campaign_row(cid)
    with _lock, db() as con:
        con.execute("UPDATE campaigns SET per_net=?, updated_at=? WHERE id=?",
                    (json.dumps(data, ensure_ascii=False), now(), cid))
        if refresh_pubs and old:
            before = get(old)
            for n, d in data.items():
                title = d["titulo"][:100] if n == "YouTube" else d["legenda"][:150]
                prev = before.get(n) or {}
                # so troca o texto das publicacoes que ainda estao com o texto automatico (nao editadas a mao)
                for desc, tags in {(old["caption"], old["hashtags"]), (prev.get("legenda", ""), prev.get("hashtags", ""))}:
                    if not desc:
                        continue
                    con.execute("""UPDATE publications SET title=?, description=?, hashtags=?, updated_at=?
                                   WHERE campaign_id=? AND platform=? AND status='Agendada'
                                   AND description=? AND hashtags=?""",
                                (title, d["legenda"], d["hashtags"], now_iso(), cid, n, desc, tags))
