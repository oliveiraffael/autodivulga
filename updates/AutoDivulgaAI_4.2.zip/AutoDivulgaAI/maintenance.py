"""Backup completo (contas, configuracoes e banco), restauracao e atualizacao automatica.

- Backup: um .zip com .env, banco de dados, chaves/tokens (*.json) e a pasta contas/. Fica em backups/.
  Tem senhas e tokens: guarde em lugar seguro e nunca mande para outras pessoas.
- Atualizacao: confere a ultima versao publicada no site do AutoDivulga (updates/latest.json) e, se for mais nova, baixa o pacote,
  guarda uma copia do programa atual e troca so os arquivos do programa (nunca dados, contas ou chaves).
"""
import io, json, re, shutil, sqlite3, sys, zipfile
from datetime import datetime
from pathlib import Path

import requests

from core import BASE, DB, VERSION, log, setting

BACKUPS = BASE / "backups"
MANIFEST = "autodivulga_backup.json"
KEEP_FULL = 6
DATA_DIRS = ["contas"]
SKIP_JSON = {"package.json"}
CODE_DIRS = ("templates/", "static/", "cloudflare/")
CODE_FILES = ("INICIAR.bat", "requirements.txt", "README.md", "PRIMEIROS_PASSOS.txt", "config.env.example")
update_state = {"checked": "", "latest": "", "url": "", "notes": "", "asset": "", "setup": "", "error": "", "running": False}


def frozen():
    return bool(getattr(sys, "frozen", False))


# ---------------- backup ----------------
def _data_files():
    files = []
    env = BASE / ".env"
    if env.exists():
        files.append(env)
    files += [p for p in BASE.glob("*.json") if p.name not in SKIP_JSON]
    for d in DATA_DIRS:
        if (BASE / d).is_dir():
            files += [p for p in (BASE / d).rglob("*") if p.is_file()]
    return files


def make_backup(reason="manual"):
    BACKUPS.mkdir(exist_ok=True)
    out = BACKUPS / f"AutoDivulga_backup_completo_{datetime.now():%Y-%m-%d_%H%M}.zip"
    tmp_db = BACKUPS / "_db_temp.db"
    src = sqlite3.connect(DB, timeout=15)
    dst = sqlite3.connect(tmp_db)
    try:
        src.backup(dst)
    finally:
        dst.close(); src.close()
    files = _data_files()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(tmp_db, "autodivulga.db")
        for f in files:
            z.write(f, f.relative_to(BASE).as_posix())
        z.writestr(MANIFEST, json.dumps({"app": "AutoDivulga AI", "version": VERSION, "reason": reason,
                                         "created": datetime.now().isoformat(timespec="seconds"),
                                         "files": len(files) + 1}, ensure_ascii=False))
    tmp_db.unlink(missing_ok=True)
    for old in sorted(BACKUPS.glob("AutoDivulga_backup_completo_*.zip"))[:-KEEP_FULL]:
        old.unlink(missing_ok=True)
    log(f"Backup completo criado: {out.name}")
    return out


def list_backups():
    if not BACKUPS.exists():
        return []
    out = []
    for p in sorted(BACKUPS.glob("AutoDivulga_backup_completo_*.zip"), reverse=True):
        out.append({"name": p.name, "size": f"{p.stat().st_size / 1_048_576:.1f} MB",
                    "when": datetime.fromtimestamp(p.stat().st_mtime).strftime("%d/%m/%Y %H:%M")})
    return out


def weekly_hook():
    """Chamado a cada 6 h: faz 1 backup completo por semana."""
    last = sorted(BACKUPS.glob("AutoDivulga_backup_completo_*.zip"))[-1:] if BACKUPS.exists() else []
    if last and (datetime.now().timestamp() - last[0].stat().st_mtime) < 7 * 86400:
        return 0
    try:
        make_backup("semanal")
    except Exception as e:
        print("Falha no backup semanal:", e)
    return 0


def _allowed(name):
    if name in ("autodivulga.db", ".env", MANIFEST):
        return True
    if "/" not in name and name.endswith(".json") and name not in SKIP_JSON:
        return True
    return any(name.startswith(d + "/") for d in DATA_DIRS) and ".." not in name.split("/")


def restore(fileobj):
    """Restaura um backup completo. Antes, guarda um backup do estado atual."""
    data = fileobj.read()
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise RuntimeError("Esse arquivo não é um backup do AutoDivulga (.zip).")
    if MANIFEST not in z.namelist():
        raise RuntimeError("Esse .zip não é um backup completo do AutoDivulga.")
    safety = make_backup("antes de restaurar")
    n = 0
    for name in z.namelist():
        if name.endswith("/") or name == MANIFEST or not _allowed(name):
            continue
        if name == "autodivulga.db":
            tmp = BACKUPS / "_restore.db"
            tmp.write_bytes(z.read(name))
            src, dst = sqlite3.connect(tmp), sqlite3.connect(DB, timeout=30)
            try:
                src.backup(dst)           # copia por dentro do SQLite, seguro com o programa aberto
            finally:
                dst.close(); src.close()
            tmp.unlink(missing_ok=True)
        else:
            target = BASE / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(z.read(name))
        n += 1
    log(f"Backup restaurado ({n} arquivo(s)). Cópia do estado anterior: {safety.name}")
    return n, safety.name


# ---------------- atualizacao ----------------
def _ver(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:3]) or (0,)


def repo():
    return (setting("UPDATE_REPO") or "oliveiraffael/autodivulga").strip()


UPDATE_URL = "https://oliveiraffael.github.io/autodivulga/updates/latest.json"


def check_update():
    """Le o arquivo latest.json publicado no site do AutoDivulga (ou, se houver, o Release do GitHub)."""
    update_state.update(error="", checked=datetime.now().strftime("%d/%m/%Y %H:%M"))
    headers = {"User-Agent": "AutoDivulgaAI", "Cache-Control": "no-cache"}
    try:
        r = requests.get(setting("UPDATE_URL") or UPDATE_URL, timeout=15, headers=headers)
        if r.status_code == 200:
            info = r.json()
            update_state.update(latest=str(info.get("version", "")).lstrip("v"), url=info.get("page", ""),
                                notes=str(info.get("notes", ""))[:1500], asset=info.get("zip", ""),
                                setup=info.get("setup", ""))
            return update_state["latest"]
    except Exception:
        pass
    try:
        r = requests.get(f"https://api.github.com/repos/{repo()}/releases/latest", timeout=15,
                         headers={**headers, "Accept": "application/vnd.github+json"})
        if r.status_code == 404:
            update_state["error"] = "Ainda não há versões publicadas para atualização automática."
            return None
        r.raise_for_status()
        rel = r.json()
    except Exception as e:
        update_state["error"] = f"Não foi possível verificar ({e.__class__.__name__})."
        return None
    asset = next((a["browser_download_url"] for a in rel.get("assets", []) if a["name"].endswith(".zip")
                  and "Setup" not in a["name"]), "")
    update_state.update(latest=(rel.get("tag_name") or "").lstrip("v"), url=rel.get("html_url", ""),
                        notes=(rel.get("body") or "")[:1500], asset=asset)
    return update_state["latest"]


def has_update():
    return bool(update_state["latest"]) and _ver(update_state["latest"]) > _ver(VERSION)


def apply_update():
    """Baixa o pacote e troca so os arquivos do programa. Depois e so reiniciar."""
    if frozen():
        raise RuntimeError("Na versão instalada (.exe), baixe o instalador novo na página da versão.")
    if not has_update() or not update_state["asset"]:
        raise RuntimeError("Nenhuma atualização disponível.")
    r = requests.get(update_state["asset"], timeout=120, headers={"User-Agent": "AutoDivulgaAI"})
    r.raise_for_status()
    z = zipfile.ZipFile(io.BytesIO(r.content))
    names = [n for n in z.namelist() if not n.endswith("/")]
    root = names[0].split("/")[0] + "/" if names and all(n.startswith(names[0].split("/")[0] + "/") for n in names) else ""
    keep = BASE / f"_backup_antes_{update_state['latest']}"
    keep.mkdir(exist_ok=True)
    changed = 0
    for n in names:
        rel = n[len(root):]
        if not rel or ".." in rel.split("/"):
            continue
        is_code = (("/" not in rel and rel.endswith(".py")) or rel in CODE_FILES or rel.startswith(CODE_DIRS))
        if not is_code:
            continue
        target = BASE / rel
        if target.exists():
            (keep / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, keep / rel)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(z.read(n))
        changed += 1
    log(f"Atualizado para a versão {update_state['latest']} ({changed} arquivo(s)). Cópia anterior em {keep.name}")
    return changed
