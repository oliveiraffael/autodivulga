"""Melhor horario aprendido com os seus proprios numeros e comparacao entre os videos que foram
melhor e pior. Usa as tabelas de Desempenho (yt/tt/ig/fb_videos)."""
import math, re, statistics
from datetime import datetime

from core import db, setting

NET_OF = {"YouTube": "yt", "TikTok": "tt", "Instagram": "ig", "Facebook": "fb"}
MIN_VIDEOS = 8          # abaixo disso a amostra e pequena demais para confiar
WEEKDAYS = ["segunda", "terça", "quarta", "quinta", "sexta", "sábado", "domingo"]


def _videos(net):
    try:
        with db() as con:
            rows = [dict(r) for r in con.execute(
                f"SELECT * FROM {net}_videos WHERE (privacy!='private' OR privacy='') AND published_at!=''")]
    except Exception:
        return []
    out = []
    now = datetime.now()
    for v in rows:
        try:
            v["dt"] = datetime.strptime(v["published_at"][:16], "%Y-%m-%d %H:%M")
        except ValueError:
            continue
        if (now - v["dt"]).days < 2:        # muito novo: ainda nao mostrou o resultado
            continue
        out.append(v)
    return out


def _score(v):
    return math.log1p(v.get("views") or 0)


def learned_times(platform, n=3):
    """Ate 3 horarios ('HH:MM') que renderam mais para esta rede, ou [] se a amostra for pequena."""
    net = NET_OF.get(platform, platform)
    vids = _videos(net)
    if len(vids) < MIN_VIDEOS:
        return []
    by_hour = {}
    for v in vids:
        by_hour.setdefault(v["dt"].hour, []).append(_score(v))
    # suaviza: cada hora soma as vizinhas (+-1 h), para nao confiar num video so
    ranked = []
    for h in range(24):
        vals = by_hour.get(h, []) + by_hour.get((h - 1) % 24, []) + by_hour.get((h + 1) % 24, [])
        if len(by_hour.get(h, [])) >= 2 and len(vals) >= 3:
            ranked.append((statistics.median(vals), len(vals), h))
    ranked.sort(reverse=True)
    chosen = []
    for _, _, h in ranked:
        if all(abs(h - c) >= 3 for c in chosen):     # espalha pelo dia
            chosen.append(h)
        if len(chosen) == n:
            break
    return [f"{h:02d}:00" for h in sorted(chosen)]


def smart_on():
    return setting("SMART_TIMES") != "off"


def times_for(platform):
    """Horarios usados no agendamento automatico: os aprendidos (se ligado e houver dados) ou os fixos."""
    if smart_on():
        t = learned_times(platform)
        if t:
            return [datetime.strptime(x, "%H:%M").time() for x in t]
    return None


def summary():
    out = []
    for p, net in NET_OF.items():
        vids = _videos(net)
        out.append({"platform": p, "n": len(vids), "times": learned_times(p), "need": max(MIN_VIDEOS - len(vids), 0)})
    return out


def _median(vals):
    return statistics.median(vals) if vals else 0


def compare(net):
    """Compara o quarto de cima com o quarto de baixo e devolve achados em linguagem simples."""
    vids = _videos(net)
    if len(vids) < 8:
        return {"n": len(vids), "findings": [], "best": [], "worst": []}
    vids.sort(key=lambda v: v.get("views") or 0, reverse=True)
    q = max(len(vids) // 4, 2)
    top, bottom = vids[:q], vids[-q:]
    f = []

    def num(v, k):
        return v.get(k) or 0
    # duracao
    dt, db_ = _median([num(v, "duration_s") for v in top if num(v, "duration_s") > 1]), \
        _median([num(v, "duration_s") for v in bottom if num(v, "duration_s") > 1])
    if dt and db_ and abs(dt - db_) >= max(8, 0.25 * max(dt, db_)):
        f.append(("Duração", f"Os melhores têm em média {int(dt)} s; os piores, {int(db_)} s. "
                  + ("Vídeos mais curtos estão indo melhor: corte as partes lentas." if dt < db_ else
                     "Vídeos um pouco mais longos estão segurando mais gente: desenvolva melhor a história.")))
    # titulo
    lt, lb = _median([len(v.get("title") or "") for v in top]), _median([len(v.get("title") or "") for v in bottom])
    if lt and lb and abs(lt - lb) >= 15:
        f.append(("Tamanho do título/legenda", f"Os melhores têm cerca de {int(lt)} caracteres; os piores, {int(lb)}. "
                  + ("Títulos curtos e diretos funcionam melhor para você." if lt < lb else
                     "Títulos mais descritivos funcionam melhor para você.")))

    def share(group, test):
        return sum(1 for v in group if test(v)) / len(group)
    for label, test, good, bad in (
        ("Pergunta no título", lambda v: "?" in (v.get("title") or ""),
         "Títulos com pergunta aparecem mais entre os melhores. Use mais perguntas.",
         "Títulos com pergunta aparecem mais entre os piores. Prefira afirmações fortes."),
        ("Números no título", lambda v: bool(re.search(r"\d", v.get("title") or "")),
         "Números (episódio, parte, lista) aparecem mais entre os melhores. Numere a série.",
         "Números no título não estão ajudando."),
        ("Hashtags", lambda v: (v.get("title") or "").count("#") >= 3,
         "Os melhores usam 3 ou mais hashtags na legenda.",
         "Muitas hashtags na legenda aparecem mais entre os piores. Use menos e mais específicas.")):
        a, b = share(top, test), share(bottom, test)
        if abs(a - b) >= 0.35:
            f.append((label, good if a > b else bad))
    # dia e horario
    wt = [v["dt"].weekday() for v in top]
    common = max(set(wt), key=wt.count)
    if wt.count(common) >= max(2, len(top) // 2):
        f.append(("Dia da semana", f"Metade ou mais dos seus melhores vídeos saiu numa {WEEKDAYS[common]}."))
    ht, hb = _median([v["dt"].hour for v in top]), _median([v["dt"].hour for v in bottom])
    if abs(ht - hb) >= 4:
        f.append(("Horário", f"Os melhores saíram por volta das {int(ht)}h; os piores, por volta das {int(hb)}h."))
    # engajamento
    def eng(v):
        return (num(v, "likes") + num(v, "comments")) * 100 / num(v, "views") if num(v, "views") else 0
    et, eb = _median([eng(v) for v in top]), _median([eng(v) for v in bottom])
    if et and eb and et > eb * 1.5:
        f.append(("Engajamento", f"Os melhores têm {et:.1f}% de curtidas e comentários por view, contra {eb:.1f}% "
                  "dos piores. Quanto mais gente comenta logo no começo, mais a rede mostra o vídeo.".replace(".", ",", 2)))
    if not f:
        f.append(("Sem padrão claro", "Os vídeos que foram melhor e pior são parecidos em duração, horário e título. "
                  "O que muda é o assunto: repita os temas dos melhores."))
    pick = lambda v: {"title": (v.get("title") or "")[:80], "views": v.get("views") or 0, "url": v.get("url") or ""}
    return {"n": len(vids), "findings": f[:6], "best": [pick(v) for v in top[:3]], "worst": [pick(v) for v in bottom[-3:]]}
