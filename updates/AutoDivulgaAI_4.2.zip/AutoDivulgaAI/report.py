"""Relatorio semanal no Telegram: toda segunda as 9h o bot manda as visualizacoes da semana
(YouTube, TikTok, Instagram e Facebook), o video campeao, comentarios esperando resposta e 3 ideias de video."""
import json, threading
from datetime import datetime, timedelta

from core import db, log, save_env, setting

state = {"running": False, "last": "", "error": ""}
SEND_WEEKDAY, SEND_HOUR = 0, 9          # segunda-feira, 9h


def _fmt(n):
    n = int(n or 0)
    return f"{n/1000:.1f} mil".replace(".", ",") if n >= 1000 else str(n)


def _net_week(prefix):
    """(views ganhas na semana, seguidores agora, ganho de seguidores, campeao, dias de historico)."""
    try:
        with db() as con:
            days = [r["day"] for r in con.execute(f"SELECT DISTINCT day FROM {prefix}_video_daily ORDER BY day")]
            if not days:
                return None
            last = days[-1]
            target = (datetime.strptime(last, "%Y-%m-%d") - timedelta(days=7)).strftime("%Y-%m-%d")
            base = next((d for d in days if d >= target), days[0])
            now_rows = {r["video_id"]: r["views"] for r in
                        con.execute(f"SELECT video_id, views FROM {prefix}_video_daily WHERE day=?", (last,))}
            old_rows = {r["video_id"]: r["views"] for r in
                        con.execute(f"SELECT video_id, views FROM {prefix}_video_daily WHERE day=?", (base,))}
            vids = {r["video_id"]: dict(r) for r in con.execute(f"SELECT * FROM {prefix}_videos")}
            chan = [dict(r) for r in con.execute(f"SELECT * FROM {prefix}_channel_daily ORDER BY day")]
    except Exception:
        return None
    gains = {v: now_rows[v] - old_rows.get(v, 0) for v in now_rows}
    hist_days = (datetime.strptime(last, "%Y-%m-%d") - datetime.strptime(base, "%Y-%m-%d")).days
    if hist_days == 0:          # sem historico ainda: usa os videos da ultima semana pelo total
        week_ago = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
        gains = {v: d["views"] for v, d in vids.items() if (d.get("published_at") or "") >= week_ago}
    champ_id = max(gains, key=gains.get) if gains else None
    champ = vids.get(champ_id) if champ_id else None
    subs_now = chan[-1]["subscribers"] if chan else None
    subs_old = next((c["subscribers"] for c in chan if c["day"] >= base), subs_now) if chan else None
    return {"views": sum(max(g, 0) for g in gains.values()), "subs": subs_now,
            "subs_gain": (subs_now - subs_old) if subs_now is not None and subs_old is not None else None,
            "champ": champ, "champ_gain": gains.get(champ_id, 0), "hist": hist_days}


def build():
    import trends
    yt, tt, ig, fb = _net_week("yt"), _net_week("tt"), _net_week("ig"), _net_week("fb")
    lines = [f"📊 Relatório da semana · AutoDivulga", f"{(datetime.now()-timedelta(days=7)):%d/%m} a {datetime.now():%d/%m}", ""]
    best = None
    emoji = {"YouTube": "▶️", "TikTok": "🎵", "Instagram": "📸", "Facebook": "📘"}
    for name, d, unit, url in (("YouTube", yt, "inscritos", "https://youtu.be/{}"),
                               ("TikTok", tt, "seguidores", None),
                               ("Instagram", ig, "seguidores", None),
                               ("Facebook", fb, "seguidores", None)):
        if not d:
            continue
        g = d["subs_gain"]
        lines.append(f"{emoji[name]} {name}: +{_fmt(d['views'])} visualizações"
                     + (f" · {_fmt(d['subs'])} {unit}" if d["subs"] is not None else "")
                     + (f" ({g:+d})" if g else ""))
        if d["champ"] and (not best or d["champ_gain"] > best[1]):
            link = (d["champ"].get("url") or (url.format(d["champ"]["video_id"]) if url else "")).split("?")[0]
            best = (d["champ"]["title"], d["champ_gain"], name, link)
    if not any((yt, tt, ig, fb)):
        lines.append("Ainda sem números: abra a página Desempenho no painel para começar o histórico.")
    if any(d and d["hist"] < 7 for d in (yt, tt, ig, fb)):
        lines.append("(histórico ainda curto: os números da semana ficam completos depois de 7 dias)")
    if best:
        lines += ["", f"🏆 Vídeo campeão ({best[2]}): “{best[0][:90]}”", f"+{_fmt(best[1])} visualizações na semana",
                  best[3]]
    try:
        import comments
        n = comments.counts().get("novo", 0)
        if n:
            lines += ["", f"💬 {n} comentário(s) esperando resposta no YouTube. Responder rápido ajuda o alcance."]
    except Exception:
        pass
    ideas = trends.load_ideas()
    fresh = ideas.get("ideas") and ideas.get("at", "")[:10] == datetime.now().strftime("%d/%m/%Y")
    if not fresh:
        trends.generate_ideas(ideas.get("platform") or "ambos")      # ideias novas para a semana
        ideas = trends.load_ideas()
    if ideas.get("ideas"):
        lines += ["", "💡 3 ideias para esta semana:"]
        for i, idea in enumerate(ideas["ideas"][:3], 1):
            lines.append(f"{i}. {idea.get('titulo','')}")
            if idea.get("gancho"):
                lines.append(f"   Gancho: “{idea['gancho'][:140]}”")
        lines.append("Abra Em alta no painel e clique em Virar campanha.")
    return "\n".join(lines)


def send_now():
    import tgbot
    if not tgbot.is_linked():
        state["error"] = "Vincule o celular em Contas → Aprovar pelo celular primeiro."
        return False
    state.update(running=True, error="")
    try:
        ok = tgbot.send(build()[:4000])
        if not ok:
            state["error"] = "O Telegram não aceitou a mensagem. Confira o bot em Contas."
            return False
        state["last"] = datetime.now().strftime("%d/%m/%Y %H:%M")
        log("Relatório semanal enviado no Telegram")
        return True
    except Exception as e:
        state["error"] = f"Falha ao montar o relatório: {e}"
        return False
    finally:
        state["running"] = False


def send_async():
    if state["running"]:
        return False
    state["running"] = True
    threading.Thread(target=send_now, name="relatorio", daemon=True).start()
    return True


def enabled():
    return setting("REPORT_WEEKLY") != "off"


def run_due():
    """Chamado pelo agendador a cada 30 s: manda 1 vez por semana, segunda a partir das 9h."""
    import tgbot
    now = datetime.now()
    if not enabled() or not tgbot.is_linked() or now.weekday() != SEND_WEEKDAY or now.hour < SEND_HOUR:
        return
    week = now.strftime("%G-%V")
    if setting("REPORT_LAST_WEEK") == week:
        return
    save_env({"REPORT_LAST_WEEK": week})      # marca antes para nunca mandar em dobro
    send_async()
