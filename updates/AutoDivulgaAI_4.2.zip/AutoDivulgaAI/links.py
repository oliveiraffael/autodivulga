"""Links rastreaveis: um link curto por campanha e por origem, servido pelo Worker da Cloudflare.

https://<worker>/l/c12-wa  ->  conta 1 clique vindo do WhatsApp e abre o video da campanha 12.
Sem Cloudflare publicado, cai no link normal do video (nada quebra).
"""
from urllib.parse import quote

import partners

SOURCES = {  # codigo: (nome, endereco de compartilhar ou "" quando a rede nao tem)
    "wa": ("WhatsApp", "https://wa.me/?text={text}%20{url}"),
    "fb": ("Facebook", "https://www.facebook.com/sharer/sharer.php?u={url}"),
    "x": ("X (Twitter)", "https://twitter.com/intent/tweet?text={text}&url={url}"),
    "th": ("Threads", "https://www.threads.net/intent/post?text={text}%20{url}"),
    "tg": ("Telegram", "https://t.me/share/url?url={url}&text={text}"),
    "bs": ("Bluesky", "https://bsky.app/intent/compose?text={text}%20{url}"),
    "rd": ("Reddit", "https://www.reddit.com/submit?url={url}&title={text}"),
    "md": ("Mastodon", ""),
    "lm": ("Lemmy", ""),
    "ig": ("Instagram (bio ou stories)", ""),
    "tt": ("TikTok (bio ou comentário)", ""),
    "yt": ("YouTube (descrição ou comentário)", ""),
    "pp": ("Pop-up de parceiros", ""),
}

SHARE_ORDER = ["wa", "fb", "x", "th", "tg", "bs", "rd"]
COPY_ONLY = ["ig", "tt", "yt"]


def video_url(c):
    url = (c["video_url"] or "").strip()
    return url if url.startswith("http") else ""


def link(c, src):
    """Link rastreavel da campanha para a origem; sem Cloudflare, o link do proprio video."""
    url = video_url(c)
    if not url:
        return ""
    if partners.is_deployed() and src in SOURCES:
        return f"{partners.worker_url()}/l/c{c['id']}-{src}"
    return url


def share_text(c, limit=200):
    text = (c["caption"] or c["title"] or "").strip()
    return text if len(text) <= limit else text[:limit - 1].rsplit(" ", 1)[0] + "…"


def share_kit(c):
    """Lista de botoes de compartilhar e de links para copiar."""
    text = share_text(c, 180)
    buttons, copies = [], []
    for code in SHARE_ORDER:
        name, tpl = SOURCES[code]
        u = link(c, code)
        if u:
            buttons.append({"code": code, "name": name, "href": tpl.format(text=quote(text), url=quote(u, safe=""))})
    for code in COPY_ONLY:
        u = link(c, code)
        if u:
            copies.append({"code": code, "name": SOURCES[code][0], "link": u})
    return buttons, copies


def stats(cid):
    """Cliques por origem (nome legivel), ou None se nao houver Cloudflare."""
    if not partners.is_deployed():
        return None
    raw = partners.link_stats(90, cid)
    return [(SOURCES.get(k, (k,))[0], n) for k, n in raw.items()]
