"""Aviso opcional de video novo num canal ou grupo seu do Telegram (Bot API oficial)."""
import requests

from core import db, log, now_iso, setting, _lock

TIMEOUT = 20


class TelegramError(Exception):
    pass


def is_configured():
    return bool(setting("TG_BOT_TOKEN") and setting("TG_CHAT_ID"))


def send(text, token=None, chat=None):
    token, chat = token or setting("TG_BOT_TOKEN"), chat or setting("TG_CHAT_ID")
    try:
        r = requests.post(f"https://api.telegram.org/bot{token}/sendMessage", timeout=TIMEOUT,
                          json={"chat_id": chat, "text": text, "disable_web_page_preview": False})
        data = r.json()
    except Exception as e:
        raise TelegramError(f"o Telegram não respondeu ({e.__class__.__name__})") from e
    if not data.get("ok"):
        desc = data.get("description", "erro desconhecido")
        if "chat not found" in desc:
            desc = "canal não encontrado: adicione o bot como administrador do canal e confira o @ do canal"
        elif "Unauthorized" in desc:
            desc = "token do bot inválido"
        raise TelegramError(desc)
    return True


def init():
    with db() as con:
        cols = {r["name"] for r in con.execute("PRAGMA table_info(publications)")}
        if "announced_at" not in cols:
            con.execute("ALTER TABLE publications ADD COLUMN announced_at TEXT DEFAULT ''")
