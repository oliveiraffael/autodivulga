"""Conteudo da aba Ajuda: como usar o AutoDivulga e como conectar cada conta.

Cada secao tem: id, titulo, icone, introducao, passos (titulo, texto em HTML) e dicas.
Os passos a passo detalhados de criacao das chaves (Google, TikTok, Meta) ficam em guides.py.
"""

SECTIONS = [
    {
        "id": "comecar", "title": "Começar", "icon": "play",
        "intro": "O AutoDivulga é um painel que roda só no seu computador. Ele escreve as legendas com IA, agenda e publica "
                 "seus vídeos no YouTube, TikTok, Instagram e Facebook, e mostra como cada vídeo está indo.",
        "steps": [
            ("Abra o painel", "Dê dois cliques em <b>INICIAR.bat</b>. Uma janela preta abre (deixe aberta, é o motor do programa) "
             "e o navegador mostra o painel em <code>http://127.0.0.1:5055</code>. Fechar a janela preta desliga o programa."),
            ("Conecte suas contas", "Vá em <a href='/accounts'>Contas</a> e conecte as redes que você usa. Cada rede tem um "
             "<b>Passo a passo</b> próprio (veja a seção <a href='#contas'>Conectar as contas</a> abaixo)."),
            ("Ligue a IA local (opcional)", "Com o Ollama instalado, a IA escreve legendas, roteiros e ideias de vídeo de graça, "
             "no seu computador. Veja a seção <a href='#ia'>Inteligência artificial</a>."),
            ("Crie a primeira campanha", "Em <a href='/campaign/new'>Nova campanha</a>, informe o título e o arquivo do vídeo. "
             "Uma campanha é um vídeo: dela saem as legendas e as publicações de cada rede."),
            ("Deixe o piloto automático ligado", "Com o piloto automático ligado, o programa confere a fila a cada 30 segundos "
             "e publica na hora marcada. O computador precisa estar ligado e com o painel aberto nessa hora."),
        ],
        "tips": ["O cartão <b>Primeiros passos</b> na Visão geral mostra o que ainda falta configurar.",
                 "Seus dados, senhas e chaves ficam só neste computador. Nada é enviado para o criador do programa."],
    },
    {
        "id": "contas", "title": "Conectar as contas", "icon": "link",
        "intro": "Cada rede social exige uma chave de desenvolvedor grátis. Você cria a sua uma vez, cola no painel e conecta. "
                 "Os passo a passo abaixo mostram cada tela.",
        "cards": [
            ("YouTube", "/guide/google", "10 a 15 min",
             "Crie um projeto grátis no Google Cloud, ative a YouTube Data API v3, baixe o <code>client_secret.json</code> "
             "e envie em Contas → YouTube. Depois clique em <b>Conectar canal</b>. O vídeo sai com a visibilidade que você escolher."),
            ("TikTok", "/guide/tiktok", "10 min",
             "Crie um app no TikTok for Developers (modo Sandbox), adicione seu @ como usuário de teste e cole o Client key e o "
             "Client secret em Contas → TikTok. Os vídeos chegam como <b>rascunho</b> no app do TikTok: você só cola a legenda e publica."),
            ("Instagram e Facebook", "/guide/meta", "15 a 20 min",
             "Precisa de um Instagram <b>profissional</b> ligado a uma <b>Página</b> do Facebook. Crie um app na Meta, cole o "
             "App ID, a Chave Secreta e o ID da configuração em Contas → Instagram e Facebook e clique em Conectar."),
        ],
        "steps": [
            ("Telegram (avisos e aprovação pelo celular)", "No Telegram, fale com <b>@BotFather</b>, mande <code>/newbot</code>, "
             "escolha um nome e copie o token. Cole em <a href='/accounts#telegram'>Contas → Telegram</a> e salve. Para aprovar pelo "
             "celular, mande para o seu bot o código que aparece no cartão <b>Aprovar pelo celular</b>. O relatório semanal é "
             "ligado em <a href='/settings#relatorio'>Configurações</a>."),
            ("Bluesky e Mastodon (anúncios)", "Bluesky: Configurações → Privacidade e segurança → <b>Senhas de app</b> → Adicionar, "
             "e use essa senha (não a sua senha normal). Mastodon: Preferências → Desenvolvimento → Nova aplicação, marque "
             "<code>write:statuses</code> e <code>read:accounts</code> e copie o token."),
            ("Lemmy (comunidades)", "Crie a conta num servidor do Lemmy e conecte em <a href='/accounts#lemmy'>Contas → Lemmy</a>. "
             "Só recebem post as comunidades que você aprovar em Onde divulgar. Alguns servidores aprovam o cadastro manualmente."),
            ("Várias contas", "Em cada rede, <b>Contas neste computador</b> guarda as contas que você já conectou. Use <b>Adicionar outra conta</b> para entrar com outra e <b>Usar esta</b> para voltar a uma conta guardada."),
        ],
        "tips": ["Se o navegador mostrar “não é possível acessar localhost” depois de autorizar, volte ao painel e clique em "
                 "Conectar de novo pelo navegador comum (Chrome ou Edge), não por janelas embutidas.",
                 "O login da Meta vale 60 dias. Para renovar, clique em Trocar de conta e entre com a mesma conta."],
    },
    {
        "id": "publicar", "title": "Criar e publicar", "icon": "calendar",
        "intro": "O caminho de um vídeo: campanha → legendas → publicações agendadas → publicado → números em Desempenho.",
        "steps": [
            ("Nova campanha", "Título, assunto, público e o arquivo do vídeo (ou o link, se já estiver no ar). Escolha a rede ou "
             "<b>Todas as redes</b>. Marque <b>Agendar automaticamente</b> para o programa escolher os próximos horários livres."),
            ("Revise o texto", "A IA gera título, legenda e hashtags para cada rede. Edite o que quiser na campanha e salve. "
             "Use <b>Gerar roteiro com IA</b> para um roteiro cena a cena."),
            ("Agende", "Em <a href='/publications/new'>Nova publicação</a>, marque as redes e escolha: no próximo horário livre, "
             "numa data e hora, ou agora. Os horários padrão e o máximo por dia ficam em "
             "<a href='/settings#auto'>Configurações → Automação</a>."),
            ("Acompanhe a fila", "Em <a href='/publications'>Publicações</a> você vê o que está agendado, publicado, com erro ou "
             "<b>Aguardando você</b> (quando a rede não está conectada, o material fica pronto para você postar à mão)."),
            ("Cortes verticais", "Em <a href='/clip'>Cortes de vídeo</a>, transforme um trecho de um vídeo longo num corte 9:16 "
             "para Shorts, TikTok e Reels."),
        ],
        "tips": ["Instagram e Facebook aceitam MP4 ou MOV vertical (9:16), de 3 segundos a 15 minutos.",
                 "Falhas passageiras (internet, limite da rede) são tentadas de novo sozinhas. Erros de arquivo ou de conta "
                 "aparecem na publicação com a explicação."],
    },
    {
        "id": "crescer", "title": "Desempenho, Em alta e Comentários", "icon": "chart",
        "intro": "As abas do grupo Crescer ajudam a decidir o próximo vídeo.",
        "steps": [
            ("Desempenho", "Views, curtidas, comentários e gráficos por rede (YouTube, TikTok, Instagram e Facebook). Os números "
             "atualizam sozinhos a cada 6 horas; use <b>Atualizar agora</b> para puxar na hora."),
            ("Em alta", "Assuntos em alta no Brasil, vídeos que estão bombando no seu nicho e ideias geradas pela IA. Defina os "
             "temas do seu canal e clique em <b>Virar campanha</b> numa ideia para criar a campanha com um clique."),
            ("Comentários", "Comentários do YouTube, Instagram e Facebook num lugar só, com sugestão de resposta da IA. Responder "
             "na primeira hora ajuda o vídeo a ser mostrado para mais gente. Cada rede precisa ser ativada uma vez no topo da página."),
            ("Onde divulgar", "Comunidades e canais do seu nicho com nota de relevância e as regras de cada um. Nada é postado "
             "sem a sua aprovação."),
        ],
        "tips": ["No TikTok, os números aparecem depois de clicar em Desempenho → TikTok → Ativar e reconectar."],
    },
    {
        "id": "ia", "title": "Inteligência artificial", "icon": "bulb",
        "intro": "O AutoDivulga usa uma IA local e grátis (Ollama). Sem ela, o programa usa textos prontos simples.",
        "steps": [
            ("Instale o Ollama", "Baixe em <a href='https://ollama.com/download' target='_blank'>ollama.com</a> e instale. "
             "O AutoDivulga abre o Ollama sozinho ao iniciar."),
            ("Baixe um modelo", "Em <a href='/settings#ai'>Configurações → Inteligência artificial</a>, escolha um modelo e clique "
             "em baixar. Modelos menores (até 4B) rodam bem em computadores comuns; os maiores escrevem melhor, mas são mais lentos."),
            ("Modo", "<b>Híbrido</b> usa a IA quando ela está ligada e os textos prontos quando não está, assim nada trava."),
        ],
        "tips": ["Gerar ideias e roteiros pode levar alguns minutos no computador sem placa de vídeo dedicada. Pode continuar "
                 "usando o painel enquanto isso."],
    },
    {
        "id": "problemas", "title": "Problemas comuns", "icon": "search",
        "faq": [
            ("O painel não abre", "Confira se a janela preta do INICIAR.bat está aberta. Se fechou, dê dois cliques de novo. "
             "Se o navegador disser que a página não existe, espere 10 segundos e recarregue."),
            ("Mudei algo e não apareceu", "Use <a href='/settings'>Configurações → Reiniciar o painel</a>."),
            ("O YouTube desconecta toda semana", "O projeto do Google está em modo Teste. Na tela de consentimento do Google Cloud, "
             "clique em Publicar app (veja o passo a passo do YouTube)."),
            ("O Instagram não aparece em Contas", "O Instagram precisa ser profissional e ligado à Página (Instagram → Editar perfil "
             "→ Facebook/Página → Conectar). Se você ligou depois de conectar, clique em Trocar de conta e autorize de novo, "
             "marcando o Instagram."),
            ("“Falta permissão no app da Meta”", "No app da Meta, confira se as 11 permissões estão adicionadas e se a configuração "
             "do Login para Empresas tem todas elas. Depois reconecte."),
            ("O TikTok não publica direto", "É assim mesmo: sem a auditoria do TikTok, a API só manda rascunho. Abra o app do "
             "TikTok, toque na notificação, cole a legenda (o painel deixa pronta) e publique."),
            ("Publicação ficou “Aguardando você”", "A rede não está conectada ou o envio automático está desligado. Abra a "
             "publicação: o vídeo e o texto estão prontos para postar à mão. Depois cole o link para acompanhar os números."),
            ("Quero passar o programa para outra pessoa", "Em <a href='/settings#pacote'>Configurações → Compartilhar o "
             "AutoDivulga</a>, gere o pacote. Ele sai sem senhas, contas nem banco de dados; a pessoa conecta as contas dela."),
        ],
    },
]
