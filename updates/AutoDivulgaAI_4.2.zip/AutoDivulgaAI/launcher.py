"""Ponto de entrada da versao instalada (AutoDivulgaAI.exe).

- AutoDivulgaAI.exe            -> abre o painel e o navegador
- AutoDivulgaAI.exe --browse X -> so a janela "Abrir arquivo" (usada pelo painel)
"""
import sys


def browse(kind):
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True); root.update()
    types = [("Imagens", "*.jpg *.jpeg *.png *.webp")] if kind == "image" else \
            [("Vídeos", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v *.wmv")]
    path = filedialog.askopenfilename(parent=root, title="Escolha o arquivo", filetypes=types + [("Todos", "*.*")])
    sys.stdout.write(path or "")


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--browse":
        browse(sys.argv[2])
        sys.exit(0)
    import os, threading, webbrowser
    import app
    if app.port_in_use():
        webbrowser.open(f"http://127.0.0.1:{app.PORT}")
        sys.exit(0)
    if not os.environ.get("AUTODIVULGA_SILENT"):
        threading.Timer(2.0, lambda: webbrowser.open(f"http://127.0.0.1:{app.PORT}")).start()
    app.main()
