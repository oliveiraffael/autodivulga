; Instalador do AutoDivulga AI (Inno Setup 6). Gerado pelo GERAR_INSTALADOR.bat.
#define AppVersion GetEnv("AUTODIVULGA_VERSION")
#if AppVersion == ""
  #define AppVersion "4.2"
#endif
[Setup]
AppId={{7B3E1A52-4C2D-4F1E-9B7A-AD1A2D5C0F42}
AppName=AutoDivulga AI
AppVersion={#AppVersion}
AppPublisher=AutoDivulga AI
DefaultDirName={localappdata}\AutoDivulgaAI
DefaultGroupName=AutoDivulga AI
PrivilegesRequired=lowest
OutputDir=exports
OutputBaseFilename=AutoDivulgaAI_Setup_{#AppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
DisableProgramGroupPage=yes
UninstallDisplayName=AutoDivulga AI

[Languages]
Name: "pt"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na área de trabalho"; Flags: checkedonce

[Files]
Source: "dist\AutoDivulgaAI\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\AutoDivulga AI"; Filename: "{app}\AutoDivulgaAI.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\AutoDivulga AI"; Filename: "{app}\AutoDivulgaAI.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\AutoDivulgaAI.exe"; Description: "Abrir o AutoDivulga AI agora"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{app}\__pycache__"
