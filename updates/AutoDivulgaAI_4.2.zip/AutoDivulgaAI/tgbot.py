"""Aprovar pelo celular: o bot do Telegram manda as sugestoes de onde divulgar com botoes
Aprovar / Descartar e avisa quando uma publicacao precisa de voce.

Seguranca: o bot so obedece ao chat vinculado com o codigo que aparece no painel.
Usa o mesmo bot do aviso no canal (TG_BOT_TOKEN), por consulta periodica (sem servidor publico).
"""
import secrets

import requests

from core import db, log, now_iso, save_env, setting, _lock

TIMEOUT = 20
MAX_PER_BATCH = 5
MAX_PER_DAY = 15      # nao lotar o celular: so as melhores sugestoes
MIN_SCORE = 40
handlers = {}   # preenchido pelo app: {"approve": fn(plid) -> texto, "discard": fn(plid) -> texto}


def _api(method, **payload):
    token = setting("TG_BOT_TOKEN")
    if not token:
        return None
    try:
        r = requests.post(f"https://api.telegram.org/bot{token}/{method}", json=payload, timeout=TIMEOUT)
        data = r.json()
    except Exception:
        return None
    return data.get("result") if data.get("ok") else None


def is_linked():
    return bool(setting("TG_BOT_TOKEN") and setting("TG_ADMIN_CHAT"))


def enabled():
    return is_linked() and setting("TG_APPROVE") != "off"


def pairing_code():
    code = setting("TG_PAIR_CODE")
    if not code:
        code = str(secrets.randbelow(900000) + 100000)
        save_env({"TG_PAIR_CODE": code})
    return code


def bot_username():
    me = _api("getMe")
    return (me or {}).get("username", "")


def unlink():
    save_env({"TG_ADMIN_CHAT": "", "TG_PAIR_CODE": ""})


def send(text, buttons=None):
    payload = {"chat_id": setting("TG_ADMIN_CHAT"), "text": text, "disable_web_page_preview": True}
    if buttons:
        payload["reply_markup"] = {"inline_keyboard": buttons}
    return _api("sendMessage", **payload)


# ---------------- avisos ----------------
def init():
    with db() as con:
        cols = {r["name"] for r in con.execute("PRAGMA table_info(places)")}
        if "tg_sent" not in cols:
            con.execute("ALTER TABLE places ADD COLUMN tg_sent TEXT DEFAULT ''")
        cols = {r["name"] for r in con.execute("PRAGMA table_info(publications)")}
        if "tg_waiting_sent" not in cols:
            con.execute("ALTER TABLE publications ADD COLUMN tg_waiting_sent TEXT DEFAULT ''")
        if "tg_error_sent" not in cols:
            con.execute("ALTER TABLE publications ADD COLUMN tg_error_sent TEXT DEFAULT ''")


def push_suggestions():
    """Manda as melhores sugestoes novas (5 por vez, 15 por dia, nota 40+), cada uma com botoes."""
    with db() as con:
        today = con.execute("SELECT COUNT(*) FROM places WHERE tg_sent LIKE ?", (now_iso()[:10] + "%",)).fetchone()[0]
    limit = min(MAX_PER_BATCH, MAX_PER_DAY - today)
    if limit <= 0:
        return 0
    with db() as con:
        rows = con.execute("""SELECT p.id, p.source, p.name, p.members, p.score, p.reasons, p.promo_policy, p.url,
                              c.title FROM places p JOIN campaigns c ON c.id=p.campaign_id
                              WHERE p.status='Sugerido' AND (p.tg_sent IS NULL OR p.tg_sent='') AND p.score >= ?
                              ORDER BY p.score DESC LIMIT ?""", (MIN_SCORE, limit)).fetchall()
    sent = 0
    for r in rows:
        auto = " (posta sozinho ao aprovar)" if r["source"] == "Lemmy" and r["promo_policy"] != "proibe" else ""
        text = (f"🔎 Sugestão para \"{r['title']}\"\n\n{r['source']}: {r['name']}\n"
                f"Nota {r['score']}/100 · {r['members'] or 0} membros\n{r['reasons'][:200]}\n{r['url']}{auto}")
        ok = send(text, [[{"text": "✅ Aprovar", "callback_data": f"ap:{r['id']}"},
                          {"text": "✖ Descartar", "callback_data": f"dc:{r['id']}"}]])
        if ok is None:
            break
        sent += 1
        with _lock, db() as con:
            con.execute("UPDATE places SET tg_sent=? WHERE id=?", (now_iso(), r["id"]))
    return sent


def push_waiting():
    """Avisa uma vez cada publicacao que ficou 'Aguardando voce'."""
    with db() as con:
        rows = con.execute("""SELECT id, platform, title, message FROM publications WHERE status='Aguardando você'
                              AND (tg_waiting_sent IS NULL OR tg_waiting_sent='') LIMIT 3""").fetchall()
    for r in rows:
        if send(f"⏳ Publicação #{r['id']} ({r['platform']}) precisa de você:\n{r['title']}\n\n{(r['message'] or '')[:300]}") is None:
            break
        with _lock, db() as con:
            con.execute("UPDATE publications SET tg_waiting_sent=? WHERE id=?", (now_iso(), r["id"]))


def push_errors():
    """Avisa uma vez cada publicacao que terminou em erro (so as das ultimas 48 h)."""
    from datetime import datetime, timedelta
    since = (datetime.now() - timedelta(hours=48)).strftime("%Y-%m-%d %H:%M")
    with db() as con:
        rows = con.execute("""SELECT id, platform, title, message FROM publications WHERE status='Erro'
                              AND updated_at>=? AND (tg_error_sent IS NULL OR tg_error_sent='') LIMIT 3""",
                           (since,)).fetchall()
    for r in rows:
        if send(f"❌ A publicação #{r['id']} no {r['platform']} falhou:\n{r['title']}\n\n{(r['message'] or '')[:300]}"
                "\n\nAbra Publicações no painel para tentar de novo.") is None:
            break
        with _lock, db() as con:
            con.execute("UPDATE publications SET tg_error_sent=? WHERE id=?", (now_iso(), r["id"]))


def push_expiring():
    """Avisa 1x por dia quando o login da Meta esta perto de vencer (7 dias ou menos)."""
    from datetime import datetime
    try:
        import meta
        m = meta.summary()
    except Exception:
        return
    if not m.get("connected") or m.get("days_left", 99) > 7:
        return
    today = datetime.now().strftime("%Y-%m-%d")
    if setting("TG_META_WARNED") == today:
        return
    left = max(m["days_left"], 0)
    msg = (f"⚠️ O login da Meta (Instagram e Facebook) vence em {left} dia(s). No painel, vá em Contas → "
           "Instagram e Facebook → Trocar de conta e entre com a mesma conta para renovar por mais 60 dias."
           if left else "⚠️ O login da Meta venceu. Instagram e Facebook não publicam até você reconectar em Contas.")
    if send(msg) is not None:
        from core import save_env
        save_env({"TG_META_WARNED": today})


# ---------------- respostas do celular ----------------
def handle_updates():
    if not setting("TG_BOT_TOKEN"):
        return 0
    offset = int(setting("TG_UPDATE_OFFSET") or 0)
    updates = _api("getUpdates", offset=offset, timeout=0, allowed_updates=["message", "callback_query"]) or []
    admin = setting("TG_ADMIN_CHAT")
    for u in updates:
        offset = max(offset, u["update_id"] + 1)
        msg, cb = u.get("message"), u.get("callback_query")
        if msg:
            chat = str(msg["chat"]["id"])
            text = (msg.get("text") or "").strip()
            if not admin and setting("TG_PAIR_CODE") and setting("TG_PAIR_CODE") in text:
                save_env({"TG_ADMIN_CHAT": chat, "TG_PAIR_CODE": ""})
                admin = chat
                log("Celular vinculado ao bot do Telegram")
                _api("sendMessage", chat_id=chat, text="✅ Celular vinculado ao AutoDivulga. As sugestões vão chegar aqui.")
            elif chat == admin and text in ("/start", "/ajuda"):
                _api("sendMessage", chat_id=chat, text="Eu aviso quando há sugestões de onde divulgar e publicações esperando você.")
        elif cb:
            chat = str(cb.get("message", {}).get("chat", {}).get("id", ""))
            if chat != admin or not admin:
                _api("answerCallbackQuery", callback_query_id=cb["id"], text="Este celular não está vinculado.")
                continue
            action, _, plid = (cb.get("data") or "").partition(":")
            fn = handlers.get({"ap": "approve", "dc": "discard"}.get(action, ""))
            result = "Ação desconhecida."
            if fn and plid.isdigit():
                try:
                    result = fn(int(plid))
                except Exception as e:
                    result = f"Não deu certo: {e}"
            _api("answerCallbackQuery", callback_query_id=cb["id"], text=result[:180])
            m = cb.get("message") or {}
            if m.get("message_id"):
                _api("editMessageText", chat_id=chat, message_id=m["message_id"],
                     text=(m.get("text") or "") + f"\n\n→ {result}")
    if updates:
        save_env({"TG_UPDATE_OFFSET": str(offset)})
    return len(updates)


def run_due():
    """Chamado pelo agendador a cada 30 s."""
    if not setting("TG_BOT_TOKEN"):
        return
    handle_updates()
    if enabled():
        push_suggestions()
        push_waiting()
        push_errors()
        push_expiring()
