"""Etapa 5: pop-ups em sites parceiros, servidos por um Worker gratuito na Cloudflare.

O painel publica o Worker (cloudflare/worker.js) na conta do usuario pela API da Cloudflare,
cria o banco D1 das estatisticas e envia a lista de parceiros e videos. Os sites parceiros
so colam uma linha <script>.
"""
import hashlib, json, re, secrets, time
from datetime import datetime

import requests

from core import BASE, db, log, now_iso, save_env, setting, _lock

API = "https://api.cloudflare.com/client/v4"
SCRIPT_NAME = "autodivulga-popups"
D1_NAME = "autodivulga"
WORKER_FILE = BASE / "cloudflare" / "worker.js"
TIMEOUT = 30

POSITIONS = {"right": "Canto inferior direito", "left": "Canto inferior esquerdo"}


class CloudflareError(Exception):
    pass


# ---------------- banco local ----------------
def init():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS partners (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            site TEXT DEFAULT '',
            campaign_id INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1,
            created_at TEXT NOT NULL
        )""")


def list_partners():
    with db() as con:
        return con.execute("""SELECT p.*, c.title AS campaign_title FROM partners p
                              LEFT JOIN campaigns c ON c.id = p.campaign_id ORDER BY p.created_at""").fetchall()


def add_partner(name, site):
    pid = secrets.token_urlsafe(6).replace("-", "x").replace("_", "y")
    with _lock, db() as con:
        con.execute("INSERT INTO partners(id, name, site, created_at) VALUES (?,?,?,?)", (pid, name, site, now_iso()))
    return pid


def update_partner(pid, **fields):
    allowed = {k: v for k, v in fields.items() if k in ("name", "site", "campaign_id", "active")}
    if allowed:
        with _lock, db() as con:
            con.execute(f"UPDATE partners SET {', '.join(k + '=?' for k in allowed)} WHERE id=?",
                        (*allowed.values(), pid))


def delete_partner(pid):
    with _lock, db() as con:
        con.execute("DELETE FROM partners WHERE id=?", (pid,))


# ---------------- estado ----------------
def worker_url():
    return setting("POPUP_URL").rstrip("/")


def is_deployed():
    return bool(worker_url() and setting("POPUP_ADMIN_TOKEN"))


def has_token():
    return bool(setting("CF_API_TOKEN"))


def embed_code(pid):
    return f'<script src="{worker_url()}/widget.js?p={pid}" async></script>'


# ---------------- conteudo enviado ao Worker ----------------
YT_ID = re.compile(r"(?:youtu\.be/|v=|shorts/|embed/)([\w-]{11})")


def thumb_for(url):
    m = YT_ID.search(url or "")
    return f"https://i.ytimg.com/vi/{m.group(1)}/hqdefault.jpg" if m else ""


def short_text(caption):
    text = re.sub(r"#\w+", "", caption or "").strip()
    text = re.sub(r"\s+", " ", text)
    return text if len(text) <= 120 else text[:117].rsplit(" ", 1)[0] + "…"


def build_config():
    with db() as con:
        camps = con.execute("""SELECT id, title, caption, video_url, status FROM campaigns
                               WHERE video_url LIKE 'http%' ORDER BY id DESC""").fetchall()
    promos, latest = {}, ""
    for c in camps:
        key = f"c{c['id']}"
        promos[key] = {"title": c["title"][:90], "text": short_text(c["caption"]),
                       "thumb": thumb_for(c["video_url"]), "url": c["video_url"]}
        if not latest and c["status"] in ("Aprovada", "Publicada"):
            latest = key
    if not latest and camps:
        latest = f"c{camps[0]['id']}"
    partners = {p["id"]: {"name": p["name"], "active": bool(p["active"]),
                          "promo": f"c{p['campaign_id']}" if p["campaign_id"] else ""}
                for p in list_partners()}
    try:
        delay = max(0, min(120, int(setting("POPUP_DELAY") or 8)))
        cap = max(1, min(720, int(setting("POPUP_CAP_HOURS") or 24)))
    except ValueError:
        delay, cap = 8, 24
    return {"partners": partners, "promos": promos, "latest": latest,
            "settings": {"delay": delay, "cap_hours": cap, "position": setting("POPUP_POSITION") or "right"}}


# ---------------- API da Cloudflare ----------------
def _cf(method, path, token=None, **kw):
    token = token or setting("CF_API_TOKEN")
    try:
        r = requests.request(method, API + path, headers={"Authorization": f"Bearer {token}"},
                             timeout=TIMEOUT, **kw)
    except requests.RequestException as e:
        raise CloudflareError(f"não foi possível falar com a Cloudflare ({e.__class__.__name__})") from e
    try:
        data = r.json()
    except ValueError:
        raise CloudflareError(f"resposta inesperada da Cloudflare (HTTP {r.status_code})")
    if not data.get("success"):
        errs = data.get("errors") or [{}]
        msg = "; ".join(f"{e.get('message', '')} (código {e.get('code', '?')})" for e in errs)
        if r.status_code in (401, 403) or any(e.get("code") in (10000, 9109, 6003, 7403) for e in errs):
            msg += ". Confira se o token tem as permissões Workers Scripts: Edit e D1: Edit."
        raise CloudflareError(msg)
    return data.get("result")


def _account(token):
    accounts = _cf("GET", "/accounts", token) or []
    if not accounts:
        raise CloudflareError("o token não dá acesso a nenhuma conta. Em 'Account Resources', escolha a sua conta.")
    return accounts[0]["id"], accounts[0].get("name", "")


def _d1(token, acc):
    found = _cf("GET", f"/accounts/{acc}/d1/database", token, params={"name": D1_NAME}) or []
    for d in found:
        if d.get("name") == D1_NAME:
            return d["uuid"]
    return _cf("POST", f"/accounts/{acc}/d1/database", token, json={"name": D1_NAME})["uuid"]


def _subdomain(token, acc):
    try:
        sub = (_cf("GET", f"/accounts/{acc}/workers/subdomain", token) or {}).get("subdomain")
    except CloudflareError:
        sub = None
    if not sub:
        wanted = "autodivulga-" + secrets.token_hex(3)
        sub = _cf("PUT", f"/accounts/{acc}/workers/subdomain", token, json={"subdomain": wanted})["subdomain"]
    return sub


def deploy(token=None):
    """Publica (ou atualiza) o Worker na conta do usuario. Retorna a URL publica."""
    token = (token or setting("CF_API_TOKEN")).strip()
    if not token:
        raise CloudflareError("cole o token da API da Cloudflare primeiro")
    acc, acc_name = _account(token)
    db_id = _d1(token, acc)
    admin = setting("POPUP_ADMIN_TOKEN") or secrets.token_urlsafe(32)
    meta = {"main_module": "worker.js", "compatibility_date": "2025-01-01",
            "bindings": [{"type": "d1", "name": "DB", "id": db_id},
                         {"type": "secret_text", "name": "ADMIN_TOKEN", "text": admin}]}
    files = {"metadata": (None, json.dumps(meta), "application/json"),
             "worker.js": ("worker.js", WORKER_FILE.read_bytes(), "application/javascript+module")}
    _cf("PUT", f"/accounts/{acc}/workers/scripts/{SCRIPT_NAME}", token, files=files)
    sub = _subdomain(token, acc)
    _cf("POST", f"/accounts/{acc}/workers/scripts/{SCRIPT_NAME}/subdomain", token,
        json={"enabled": True, "previews_enabled": False})
    url = f"https://{SCRIPT_NAME}.{sub}.workers.dev"
    save_env({"CF_API_TOKEN": token, "CF_ACCOUNT_ID": acc, "POPUP_URL": url, "POPUP_ADMIN_TOKEN": admin,
              "POPUP_D1_ID": db_id, "POPUP_DEPLOYED_AT": now_iso(), "POPUP_WORKER_SHA": worker_sha()})
    log(f"Pop-ups publicados na Cloudflare ({acc_name}): {url}")
    return url


def _admin(method, path, **kw):
    if not is_deployed():
        raise CloudflareError("publique o script na Cloudflare primeiro")
    try:
        r = requests.request(method, worker_url() + path, timeout=TIMEOUT,
                             headers={"Authorization": f"Bearer {setting('POPUP_ADMIN_TOKEN')}"}, **kw)
    except requests.RequestException as e:
        raise CloudflareError(f"o script na Cloudflare não respondeu ({e.__class__.__name__}). "
                              "Logo depois de publicar ele pode levar 1 ou 2 minutos para ficar no ar.") from e
    if r.status_code == 401:
        raise CloudflareError("a senha interna não confere. Clique em 'Publicar de novo'.")
    if r.status_code >= 400:
        raise CloudflareError(f"o script respondeu com erro {r.status_code}")
    return r.json()


SCHEMA = ["CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT)",
          "CREATE TABLE IF NOT EXISTS stats (day TEXT NOT NULL, partner TEXT NOT NULL, promo TEXT NOT NULL, "
          "views INTEGER DEFAULT 0, clicks INTEGER DEFAULT 0, closes INTEGER DEFAULT 0, PRIMARY KEY (day, partner, promo))"]


def _d1_query(sql, params=None):
    """Consulta o banco D1 pela API oficial (funciona mesmo em redes que bloqueiam *.workers.dev)."""
    acc, dbid = setting("CF_ACCOUNT_ID"), setting("POPUP_D1_ID")
    if not (acc and dbid and has_token()):
        raise CloudflareError("publique o script na Cloudflare primeiro")
    res = _cf("POST", f"/accounts/{acc}/d1/database/{dbid}/query", json={"sql": sql, "params": params or []})
    return (res or [{}])[0].get("results", [])


def sync():
    """Envia parceiros, videos e preferencias ao banco que o Worker le (atualiza em ate 1 minuto)."""
    cfg = build_config()
    for sql in SCHEMA:
        _d1_query(sql)
    _d1_query("INSERT INTO config (key, value, updated_at) VALUES ('main', ?1, ?2) "
              "ON CONFLICT (key) DO UPDATE SET value = ?1, updated_at = ?2",
              [json.dumps(cfg, ensure_ascii=False), datetime.utcnow().isoformat()])
    save_env({"POPUP_SYNCED_AT": now_iso()})
    return {"ok": True, "partners": len(cfg["partners"])}


def wait_online(seconds=90):
    """Espera o endereco *.workers.dev ficar no ar depois de publicar."""
    end = time.time() + seconds
    while time.time() < end:
        try:
            if requests.get(worker_url() + "/health", timeout=10).ok:
                return True
        except requests.RequestException:
            pass
        time.sleep(5)
    return False


def stats(days=30):
    """Totais por parceiro e no geral (ultimos N dias)."""
    since = datetime.utcfromtimestamp(time.time() - days * 86400).strftime("%Y-%m-%d")
    try:
        rows = _d1_query("SELECT day, partner, promo, views, clicks, closes FROM stats "
                         "WHERE day >= ?1 AND partner NOT LIKE 'via:%'", [since])
    except CloudflareError as e:
        if "no such table" in str(e):
            rows = []
        else:
            raise
    per, total = {}, {"views": 0, "clicks": 0, "closes": 0}
    for r in rows:
        p = per.setdefault(r["partner"], {"views": 0, "clicks": 0, "closes": 0})
        for k in total:
            p[k] += r.get(k) or 0
            total[k] += r.get(k) or 0
    for d in [*per.values(), total]:
        d["ctr"] = round(100 * d["clicks"] / d["views"], 1) if d["views"] else 0
    return per, total


def link_stats(days=90, cid=None):
    """Cliques dos links rastreaveis: {origem: cliques} (de uma campanha ou de todas)."""
    since = datetime.utcfromtimestamp(time.time() - days * 86400).strftime("%Y-%m-%d")
    sql = "SELECT partner, SUM(clicks) n FROM stats WHERE day >= ?1 AND partner LIKE 'via:%'"
    params = [since]
    if cid:
        sql += " AND promo = ?2"
        params.append(f"c{cid}")
    try:
        rows = _d1_query(sql + " GROUP BY partner ORDER BY n DESC", params)
    except CloudflareError as e:
        if "no such table" in str(e):
            return {}
        raise
    return {r["partner"][4:]: r["n"] or 0 for r in rows}


def worker_sha():
    return hashlib.sha256(WORKER_FILE.read_bytes()).hexdigest()[:16]


def ensure_current():
    """Republica sozinho quando o AutoDivulga foi atualizado com um script novo."""
    if is_deployed() and has_token() and setting("POPUP_WORKER_SHA") != worker_sha():
        deploy()
        sync()
        return True
    return False


_last_auto = 0.0


def auto_hook():
    """Chamado pelo agendador: mantem o Worker com os videos mais recentes."""
    global _last_auto
    if not is_deployed() or time.time() - _last_auto < 3 * 3600:
        return 0
    _last_auto = time.time()
    try:
        if ensure_current():
            return 1
        sync()
        return 1
    except Exception as e:
        print("Falha ao sincronizar pop-ups:", e)
        return 0
