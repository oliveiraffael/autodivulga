"""Integracao com o TikTok (Login Kit para Desktop + Content Posting API, modo Upload/rascunho).

- Login OAuth 2.0 com PKCE (o TikTok exige code_challenge em hexadecimal do SHA256).
- Retorno do login em http://127.0.0.1:5055/tiktok/callback/ (registre exatamente esse endereco no app).
- O video vai para a CAIXA DE ENTRADA do TikTok como rascunho; voce termina de publicar no app.
- Token em tiktok_token.json, so neste computador.
"""
import hashlib, json, math, os, secrets, time
from pathlib import Path
from urllib.parse import urlencode

import requests

import publishers
from core import BASE, log, setting

TOKEN_FILE = BASE / "tiktok_token.json"
REDIRECT_URI = "http://127.0.0.1:5055/tiktok/callback/"
SCOPES = "user.info.basic,video.upload"
STATS_SCOPES = "user.info.stats,video.list"   # numeros do perfil e dos videos (pagina Desempenho)


def scopes():
    """Permissoes pedidas no login. As de numeros so entram se o usuario ativou em Desempenho → TikTok,
    porque o app do TikTok for Developers precisa ter essas permissoes liberadas antes."""
    return SCOPES + ("," + STATS_SCOPES if setting("TT_STATS") == "on" else "")
AUTH_URL = "https://www.tiktok.com/v2/auth/authorize/"
API = "https://open.tiktokapis.com/v2"
CHUNK = 10 * 1024 * 1024          # 10 MB (TikTok: min 5 MB, max 64 MB por parte)
SINGLE_LIMIT = 64 * 1024 * 1024   # ate 64 MB vai em uma parte so
MIME = {".mp4": "video/mp4", ".mov": "video/quicktime", ".webm": "video/webm"}

_pending = {}   # state -> code_verifier


# ---------- credenciais ----------
def client_key():
    return setting("TIKTOK_CLIENT_KEY").strip()


def client_secret():
    return setting("TIKTOK_CLIENT_SECRET").strip()


def has_credentials():
    return bool(client_key() and client_secret())


def _load():
    if not TOKEN_FILE.exists():
        return None
    try:
        return json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def _save(tok):
    now = time.time()
    tok["expires_at"] = now + int(tok.get("expires_in", 86400)) - 120
    tok["refresh_expires_at"] = now + int(tok.get("refresh_expires_in", 31536000)) - 3600
    TOKEN_FILE.write_text(json.dumps(tok), encoding="utf-8")
    return tok


def is_connected():
    return has_credentials() and TOKEN_FILE.exists()


def _api_error(resp):
    try:
        err = resp.json().get("error", {})
        return err.get("code", ""), err.get("message", "")
    except Exception:
        return str(resp.status_code), resp.text[:200]


def access_token():
    tok = _load()
    if not tok:
        raise publishers.PermanentError("Conta do TikTok não conectada.")
    if time.time() < tok.get("expires_at", 0):
        return tok["access_token"]
    if time.time() > tok.get("refresh_expires_at", 0):
        disconnect(revoke=False)
        raise publishers.PermanentError("A conexão com o TikTok expirou. Vá em Contas e conecte de novo.")
    try:
        r = requests.post(f"{API}/oauth/token/", timeout=30, data={
            "client_key": client_key(), "client_secret": client_secret(),
            "grant_type": "refresh_token", "refresh_token": tok["refresh_token"]})
    except requests.RequestException as e:
        raise publishers.TemporaryError(f"Sem conexão com o TikTok: {e}")
    data = r.json() if r.content else {}
    if r.status_code != 200 or "access_token" not in data:
        if r.status_code >= 500:
            raise publishers.TemporaryError("TikTok indisponível ao renovar o acesso.")
        disconnect(revoke=False)
        log("TikTok desconectado: não foi possível renovar o acesso. Conecte de novo.")
        raise publishers.PermanentError("A conexão com o TikTok expirou ou foi revogada. Conecte de novo em Contas.")
    return _save(data)["access_token"]


# ---------- login ----------
def start_login(switch=False):
    if not has_credentials():
        raise RuntimeError("Informe o Client Key e o Client Secret do seu app do TikTok primeiro.")
    verifier = secrets.token_urlsafe(48)[:64]
    challenge = hashlib.sha256(verifier.encode()).hexdigest()   # TikTok usa hex, nao base64
    state = secrets.token_urlsafe(16)
    _pending[state] = verifier
    return AUTH_URL + "?" + urlencode({
        "client_key": client_key(), "scope": scopes(), "response_type": "code",
        "redirect_uri": REDIRECT_URI, "state": state,
        "code_challenge": challenge, "code_challenge_method": "S256", **({"disable_auto_auth": 1} if switch else {})})


def finish_login(state, code):
    verifier = _pending.pop(state, None)
    if not verifier:
        raise RuntimeError("O login expirou ou o programa foi reiniciado no meio. Clique em Conectar de novo.")
    r = requests.post(f"{API}/oauth/token/", timeout=30, data={
        "client_key": client_key(), "client_secret": client_secret(), "code": code,
        "grant_type": "authorization_code", "redirect_uri": REDIRECT_URI, "code_verifier": verifier})
    data = r.json() if r.content else {}
    if r.status_code != 200 or "access_token" not in data:
        raise RuntimeError(data.get("error_description") or data.get("error") or f"erro {r.status_code}")
    granted = data.get("scope", "")
    _save(data)
    info = user_info(force=True)
    log(f"Conta do TikTok conectada: {info.get('display_name', '?')}")
    if "video.upload" not in granted:
        info["warning"] = "A permissão de enviar vídeos (video.upload) não foi concedida."
    return info


def disconnect(revoke=True):
    tok = _load()
    if revoke and tok and has_credentials():
        try:
            requests.post(f"{API}/oauth/revoke/", timeout=15, data={
                "client_key": client_key(), "client_secret": client_secret(), "token": tok.get("access_token", "")})
        except Exception:
            pass
    TOKEN_FILE.unlink(missing_ok=True)
    (BASE / "tiktok_user.json").unlink(missing_ok=True)


def user_info(force=False):
    cache = BASE / "tiktok_user.json"
    if cache.exists() and not force and time.time() - cache.stat().st_mtime < 86400:
        try:
            return json.loads(cache.read_text(encoding="utf-8"))
        except Exception:
            pass
    r = requests.get(f"{API}/user/info/", timeout=20,
                     params={"fields": "open_id,display_name,avatar_url"},
                     headers={"Authorization": f"Bearer {access_token()}"})
    info = r.json().get("data", {}).get("user", {}) if r.status_code == 200 else {}
    info = info or {"display_name": "(conta conectada)"}
    info["updated"] = time.strftime("%d/%m/%Y %H:%M")
    cache.write_text(json.dumps(info, ensure_ascii=False), encoding="utf-8")
    return info


# ---------- envio (rascunho na caixa de entrada) ----------
def chunk_plan(size):
    """Regras do TikTok: ate 64 MB numa parte; acima, partes de 10 MB e a ultima absorve o resto."""
    if size <= SINGLE_LIMIT:
        return size, 1
    count = size // CHUNK
    return CHUNK, min(count, 1000)


def _raise_for(resp, stage):
    code, msg = _api_error(resp)
    if resp.status_code == 429 or code in ("rate_limit_exceeded", "spam_risk_too_many_pending_share",
                                          "spam_risk_too_many_posts") or resp.status_code >= 500:
        raise publishers.TemporaryError(f"TikTok ocupado ou limite atingido ({code or resp.status_code})")
    if code in ("access_token_invalid", "scope_not_authorized"):
        raise publishers.PermanentError("Sem permissão para enviar ao TikTok. Conecte a conta de novo em Contas.")
    raise publishers.PermanentError(f"O TikTok recusou o envio na etapa {stage} ({code} {msg}).")


def upload_draft(video_path, wait_seconds=180):
    path = Path(video_path)
    size = path.stat().st_size
    chunk_size, count = chunk_plan(size)
    headers = {"Authorization": f"Bearer {access_token()}", "Content-Type": "application/json; charset=UTF-8"}
    try:
        r = requests.post(f"{API}/post/publish/inbox/video/init/", headers=headers, timeout=60, json={
            "source_info": {"source": "FILE_UPLOAD", "video_size": size,
                            "chunk_size": chunk_size, "total_chunk_count": count}})
    except requests.RequestException as e:
        raise publishers.TemporaryError(f"Sem conexão com o TikTok: {e}")
    if r.status_code != 200 or r.json().get("error", {}).get("code", "ok") != "ok":
        _raise_for(r, "init")
    data = r.json()["data"]
    publish_id, upload_url = data["publish_id"], data["upload_url"]
    mime = MIME.get(path.suffix.lower(), "video/mp4")
    with open(path, "rb") as f:
        for i in range(count):
            start = i * chunk_size
            end = size - 1 if i == count - 1 else start + chunk_size - 1
            f.seek(start)
            body = f.read(end - start + 1)
            for attempt in range(4):
                try:
                    up = requests.put(upload_url, data=body, timeout=300, headers={
                        "Content-Type": mime, "Content-Length": str(len(body)),
                        "Content-Range": f"bytes {start}-{end}/{size}"})
                except requests.RequestException:
                    up = None
                if up is not None and up.status_code in (200, 201, 206):
                    break
                if attempt == 3:
                    raise publishers.TemporaryError(f"Falha ao enviar a parte {i + 1}/{count} do vídeo.")
                time.sleep(2 ** attempt)
    # acompanha o processamento ate chegar na caixa de entrada
    deadline = time.time() + wait_seconds
    status = "PROCESSING_UPLOAD"
    while time.time() < deadline:
        s = requests.post(f"{API}/post/publish/status/fetch/", headers=headers, timeout=30,
                          json={"publish_id": publish_id})
        if s.status_code == 200:
            d = s.json().get("data", {})
            status = d.get("status", status)
            if status in ("SEND_TO_USER_INBOX", "PUBLISH_COMPLETE"):
                return publish_id, status
            if status == "FAILED":
                raise publishers.PermanentError(f"O TikTok não aceitou o vídeo ({d.get('fail_reason', 'motivo não informado')}).")
        time.sleep(5)
    return publish_id, status


class TikTokPublisher:
    name = "TikTok API (rascunho)"
    automatic = True

    def is_connected(self):
        return is_connected() and setting("TT_UPLOAD") != "off"

    def publish(self, pub):
        if not pub["video_path"] or not Path(pub["video_path"]).is_file():
            raise publishers.PermanentError("Arquivo do vídeo não encontrado. Informe o caminho na publicação.")
        ext = Path(pub["video_path"]).suffix.lower()
        if ext not in MIME:
            raise publishers.PermanentError("O TikTok aceita vídeos MP4, MOV ou WebM.")
        publish_id, status = upload_draft(pub["video_path"])
        if status in ("SEND_TO_USER_INBOX", "PUBLISH_COMPLETE"):
            msg = ("Rascunho enviado para a caixa de entrada do TikTok. Abra o app, toque na notificação "
                   "\"Seu vídeo está pronto\", cole a legenda abaixo e publique. Depois cole aqui o link.")
        else:
            msg = ("Vídeo enviado ao TikTok e ainda em processamento. Em alguns minutos a notificação de rascunho "
                   "aparece no app; publique por lá e cole aqui o link.")
        return publishers.PublishResult("Aguardando você", msg + f" (id {publish_id})")


publishers.register("TikTok", TikTokPublisher())


# ---------- numeros (pagina Desempenho) ----------
def granted_scopes():
    return set(((_load() or {}).get("scope") or "").replace(" ", "").split(","))


def has_stats():
    g = granted_scopes()
    return is_connected() and "video.list" in g


def _get_json(resp):
    try:
        return resp.json()
    except Exception:
        return {}


def user_stats():
    """Seguidores, curtidas totais e numero de videos (precisa de user.info.stats)."""
    r = requests.get(f"{API}/user/info/", timeout=20, headers={"Authorization": f"Bearer {access_token()}"},
                     params={"fields": "open_id,display_name,follower_count,following_count,likes_count,video_count"})
    data = _get_json(r)
    if r.status_code != 200 or data.get("error", {}).get("code", "ok") != "ok":
        return {}
    return data.get("data", {}).get("user", {})


def list_videos(max_pages=25):
    """Todos os videos publicados do perfil com views, curtidas, comentarios e compartilhamentos (video.list)."""
    fields = ("id,title,video_description,create_time,cover_image_url,share_url,duration,"
              "view_count,like_count,comment_count,share_count")
    out, cursor = [], None
    for _ in range(max_pages):
        body = {"max_count": 20}
        if cursor:
            body["cursor"] = cursor
        r = requests.post(f"{API}/video/list/", params={"fields": fields}, json=body, timeout=30,
                          headers={"Authorization": f"Bearer {access_token()}",
                                   "Content-Type": "application/json; charset=UTF-8"})
        data = _get_json(r)
        code = data.get("error", {}).get("code", "ok")
        if r.status_code != 200 or code != "ok":
            msg = data.get("error", {}).get("message", "") or r.status_code
            if code == "scope_not_authorized":
                raise RuntimeError("a conta foi conectada sem a permissão video.list")
            raise RuntimeError(f"o TikTok recusou a consulta ({code} {msg})")
        d = data.get("data", {})
        out += d.get("videos", [])
        if not d.get("has_more"):
            break
        cursor = d.get("cursor")
    return out
