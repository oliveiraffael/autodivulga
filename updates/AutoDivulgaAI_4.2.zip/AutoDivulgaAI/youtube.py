"""Integracao com o YouTube (YouTube Data API v3).

- Login OAuth com o client_secret.json do seu projeto do Google Cloud.
- O retorno do login usa o proprio painel (http://127.0.0.1:5055/), permitido para apps de computador.
- O token fica em youtube_token.json, so neste computador.
"""
import json, os, re, time
from pathlib import Path

import publishers
from core import BASE, log, setting

os.environ.setdefault("OAUTHLIB_INSECURE_TRANSPORT", "1")   # retorno local em http://127.0.0.1
os.environ.setdefault("OAUTHLIB_RELAX_TOKEN_SCOPE", "1")

CLIENT_FILE = BASE / "client_secret.json"
TOKEN_FILE = BASE / "youtube_token.json"
REDIRECT_URI = "http://127.0.0.1:5055/"
SCOPES = ["https://www.googleapis.com/auth/youtube.upload",
          "https://www.googleapis.com/auth/youtube.readonly"]
CATEGORIES = {"1": "Filmes e animação", "10": "Música", "15": "Animais", "17": "Esportes",
              "20": "Jogos", "22": "Pessoas e blogs", "23": "Comédia", "24": "Entretenimento",
              "26": "Guias e estilo", "27": "Educação", "28": "Ciência e tecnologia"}

REPLY_SCOPE = "https://www.googleapis.com/auth/youtube.force-ssl"   # responder comentarios


def login_scopes():
    """A permissao de comentar so e pedida depois que o usuario ativa em Comentarios."""
    return SCOPES + ([REPLY_SCOPE] if setting("YT_REPLY") == "on" else [])


def granted_scopes():
    try:
        return set(json.loads(TOKEN_FILE.read_text(encoding="utf-8")).get("scopes") or [])
    except Exception:
        return set()


def can_reply():
    return is_connected() and REPLY_SCOPE in granted_scopes()


_pending_flows = {}   # state -> Flow (guarda o PKCE entre o clique e o retorno)
_service = None


# ---------- arquivos e credenciais ----------
def client_file_status():
    """Retorna (ok, mensagem) sobre o client_secret.json."""
    if not CLIENT_FILE.exists():
        others = sorted(BASE.glob("client_secret*.json"))
        if others:
            return False, f"Encontrei {others[0].name}. Renomeie para client_secret.json."
        return False, "Arquivo client_secret.json não encontrado na pasta do programa."
    try:
        data = json.loads(CLIENT_FILE.read_text(encoding="utf-8"))
    except Exception:
        return False, "client_secret.json está corrompido. Baixe de novo no Google Cloud."
    if "installed" not in data:
        if "web" in data:
            return False, "Este cliente é do tipo 'Aplicativo da Web'. Crie um do tipo 'App para computador'."
        return False, "client_secret.json não parece um cliente OAuth do Google."
    return True, "client_secret.json encontrado (App para computador)."


def _credentials():
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request
    from google.auth.exceptions import RefreshError
    if not TOKEN_FILE.exists():
        return None
    creds = Credentials.from_authorized_user_file(str(TOKEN_FILE))
    if not creds.valid:
        if creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except RefreshError as e:
                disconnect(revoke=False)
                log("YouTube desconectado: a autorização expirou ou foi revogada. Conecte de novo.")
                raise publishers.PermanentError("A conexão com o YouTube expirou. Vá em Contas e conecte o canal de novo.") from e
            TOKEN_FILE.write_text(creds.to_json(), encoding="utf-8")
        else:
            return None
    return creds


def service():
    global _service
    from googleapiclient.discovery import build
    creds = _credentials()
    if not creds:
        raise publishers.PermanentError("Canal do YouTube não conectado.")
    _service = build("youtube", "v3", credentials=creds, cache_discovery=False)
    return _service


def is_connected():
    return CLIENT_FILE.exists() and TOKEN_FILE.exists()


# ---------- login ----------
def start_login(select_account=False):
    from google_auth_oauthlib.flow import Flow
    ok, msg = client_file_status()
    if not ok:
        raise RuntimeError(msg)
    flow = Flow.from_client_secrets_file(str(CLIENT_FILE), scopes=login_scopes(), redirect_uri=REDIRECT_URI,
                                         autogenerate_code_verifier=True)
    url, state = flow.authorization_url(access_type="offline", prompt="consent select_account" if select_account else "consent",
                                        include_granted_scopes="true")
    _pending_flows[state] = flow
    return url


def finish_login(state, full_url):
    flow = _pending_flows.pop(state, None)
    if not flow:
        raise RuntimeError("O login expirou ou o programa foi reiniciado no meio. Clique em Conectar de novo.")
    flow.fetch_token(authorization_response=full_url.replace("https://", "http://", 1)
                     if full_url.startswith("https://127.0.0.1") else full_url)
    creds = flow.credentials
    data = json.loads(creds.to_json())
    granted = getattr(creds, "granted_scopes", None)
    if granted:                      # o Google deixa a pessoa desmarcar permissoes: guarda so as concedidas
        data["scopes"] = list(granted)
    TOKEN_FILE.write_text(json.dumps(data), encoding="utf-8")
    info = channel_info(force=True)
    log(f"Canal do YouTube conectado: {info.get('title', '?')}")
    return info


def disconnect(revoke=True):
    if revoke and TOKEN_FILE.exists():
        try:
            import requests
            token = json.loads(TOKEN_FILE.read_text(encoding="utf-8")).get("refresh_token")
            if token:
                requests.post("https://oauth2.googleapis.com/revoke", params={"token": token}, timeout=10)
        except Exception:
            pass
    TOKEN_FILE.unlink(missing_ok=True)
    (BASE / "youtube_channel.json").unlink(missing_ok=True)


# ---------- canal e estatisticas ----------
def channel_info(force=False):
    cache = BASE / "youtube_channel.json"
    if cache.exists() and time.time() - cache.stat().st_mtime > 30 * 86400:
        cache.unlink()  # politica do YouTube: dados da API nao ficam mais de 30 dias sem atualizar
    if cache.exists() and not force:
        try:
            return json.loads(cache.read_text(encoding="utf-8"))
        except Exception:
            pass
    resp = service().channels().list(part="snippet,statistics", mine=True).execute()
    items = resp.get("items", [])
    if not items:
        info = {"title": "(conta sem canal)", "id": ""}
    else:
        it = items[0]
        st = it.get("statistics", {})
        info = {"id": it["id"], "title": it["snippet"]["title"],
                "thumb": it["snippet"].get("thumbnails", {}).get("default", {}).get("url", ""),
                "subscribers": st.get("subscriberCount", "?"), "views": st.get("viewCount", "0"),
                "videos": st.get("videoCount", "0"), "updated": time.strftime("%d/%m/%Y %H:%M")}
    cache.write_text(json.dumps(info, ensure_ascii=False), encoding="utf-8")
    return info


def video_id_from_url(url):
    m = re.search(r"(?:youtu\.be/|v=|/shorts/|/video/)([\w-]{11})", url or "")
    return m.group(1) if m else None


def fetch_stats(video_ids):
    """Retorna {id: {views, likes, comments, privacy}} (1 unidade de cota por 50 videos)."""
    out = {}
    ids = [v for v in video_ids if v]
    for i in range(0, len(ids), 50):
        resp = service().videos().list(part="statistics,status", id=",".join(ids[i:i + 50])).execute()
        for it in resp.get("items", []):
            st = it.get("statistics", {})
            out[it["id"]] = {"views": int(st.get("viewCount", 0)), "likes": int(st.get("likeCount", 0)),
                             "comments": int(st.get("commentCount", 0)),
                             "privacy": it.get("status", {}).get("privacyStatus", "")}
    return out


# ---------- envio ----------
def _clean_text(s, limit):
    return re.sub(r"[<>]", "", s or "").strip()[:limit]


def _tags(hashtags):
    tags, total = [], 0
    for t in re.findall(r"#?([\w]+)", hashtags or ""):
        if t.lower() not in [x.lower() for x in tags] and total + len(t) + 1 <= 450:
            tags.append(t); total += len(t) + 1
    return tags


def build_body(pub):
    description = pub["description"] or ""
    if pub["hashtags"] and pub["hashtags"] not in description:
        description = (description + "\n\n" + pub["hashtags"]).strip()
    return {
        "snippet": {"title": _clean_text(pub["title"], 100) or "Vídeo novo",
                    "description": _clean_text(description, 4900),
                    "tags": _tags(pub["hashtags"]),
                    "categoryId": setting("YT_CATEGORY") or "22",
                    "defaultLanguage": "pt-BR", "defaultAudioLanguage": "pt-BR"},
        "status": {"privacyStatus": pub["privacy"] or "private",
                   "selfDeclaredMadeForKids": setting("YT_MADE_FOR_KIDS") == "on",
                   "embeddable": True},
    }


def _http_error(e):
    from googleapiclient.errors import HttpError
    if not isinstance(e, HttpError):
        return publishers.TemporaryError(str(e))
    status = getattr(e.resp, "status", 0)
    try:
        reason = json.loads(e.content.decode())["error"]["errors"][0].get("reason", "")
    except Exception:
        reason = ""
    if reason in ("quotaExceeded", "uploadLimitExceeded", "rateLimitExceeded", "userRateLimitExceeded") \
            or status in (429, 500, 502, 503, 504):
        return publishers.TemporaryError(f"YouTube ocupado ou limite diário atingido ({reason or status})")
    if reason == "youtubeSignupRequired":
        return publishers.PermanentError("A conta conectada não tem canal no YouTube.")
    if status in (401, 403) and reason in ("forbidden", "insufficientPermissions", "authError"):
        return publishers.PermanentError("Sem permissão para enviar. Reconecte o canal em Contas.")
    return publishers.PermanentError(f"O YouTube recusou o envio ({status} {reason}).")


def api_upload_enabled():
    """Desde 02/11/2026 o YouTube nao trava mais em privado os envios de projetos nao auditados."""
    return setting("YT_API_UPLOAD") == "on"


class YouTubePublisher:
    name = "YouTube API"
    automatic = True

    def is_connected(self):
        return is_connected() and api_upload_enabled()

    def publish(self, pub):
        from googleapiclient.http import MediaFileUpload
        from googleapiclient.errors import HttpError
        path = Path(pub["video_path"] or "")
        if not pub["video_path"] or not path.is_file():
            raise publishers.PermanentError("Arquivo do vídeo não encontrado. Informe o caminho na publicação.")
        yt = service()
        media = MediaFileUpload(str(path), chunksize=8 * 1024 * 1024, resumable=True)
        request = yt.videos().insert(part="snippet,status", body=build_body(pub), media_body=media)
        response, retries = None, 0
        while response is None:
            try:
                _, response = request.next_chunk()
                retries = 0
            except HttpError as e:
                err = _http_error(e)
                if isinstance(err, publishers.TemporaryError) and getattr(e.resp, "status", 0) >= 500 and retries < 5:
                    retries += 1
                    time.sleep(2 ** retries)
                    continue
                raise err
            except (ConnectionError, TimeoutError, OSError) as e:
                if retries < 5:
                    retries += 1
                    time.sleep(2 ** retries)
                    continue
                raise publishers.TemporaryError(f"Falha de conexão durante o envio: {e}")
        vid = response["id"]
        notes = []
        thumb = Path(pub["thumbnail_path"] or "") if "thumbnail_path" in pub.keys() else None
        if thumb and pub["thumbnail_path"] and thumb.is_file():
            try:
                yt.thumbnails().set(videoId=vid, media_body=MediaFileUpload(str(thumb))).execute()
                notes.append("miniatura enviada")
            except HttpError:
                notes.append("miniatura recusada (o canal precisa estar verificado por telefone para miniaturas)")
        msg = "Vídeo enviado ao YouTube" + (" · " + "; ".join(notes) if notes else "") + "."
        return publishers.PublishResult("Publicada", msg, f"https://youtu.be/{vid}")


publishers.register("YouTube", YouTubePublisher())
