"""Desempenho do canal: estatisticas de todos os videos do canal do YouTube conectado,
historico diario (fotos de cada dia) e recomendacoes automaticas.

Politica da API do YouTube: dados vindos da API nao ficam guardados por mais de 30 dias
sem atualizacao. Por isso o historico diario guarda so os ultimos 30 dias.
"""
import re, statistics, threading, time
from datetime import datetime, timedelta, timezone

from core import db, log, now_iso, _lock

KEEP_DAYS = 30
SHORT_MAX_SECONDS = 180          # Shorts podem ter ate 3 minutos
REFRESH_MIN_GAP = 30 * 60        # nao consulta a API mais de 1x a cada 30 min
WEEKDAYS = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]

state = {"running": False, "error": "", "at": 0.0}
tt_state = {"running": False, "error": "", "at": 0.0}
youtube = None                   # o app injeta o modulo youtube (se instalado)
tiktok = None                    # e o modulo tiktok
NETS = {"yt": {"short_max": SHORT_MAX_SECONDS, "short": "Shorts (até 3 min)", "long": "Vídeos longos",
               "followers": "Inscritos", "where": "canal"},
        "tt": {"short_max": 30, "short": "Até 30 s", "long": "Mais de 30 s",
               "followers": "Seguidores", "where": "perfil"},
        "ig": {"short_max": 0, "short": "Reels", "long": "Fotos e carrosséis",
               "followers": "Seguidores", "where": "perfil"},
        "fb": {"short_max": 30, "short": "Até 30 s", "long": "Mais de 30 s",
               "followers": "Seguidores", "where": "Página"}}
meta = None                      # e o modulo meta (Instagram/Facebook)
meta_state = {"ig": {"running": False, "error": "", "at": 0.0}, "fb": {"running": False, "error": "", "at": 0.0}}


def init():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS yt_videos (
            video_id TEXT PRIMARY KEY, title TEXT DEFAULT '', published_at TEXT DEFAULT '',
            thumb TEXT DEFAULT '', duration_s INTEGER DEFAULT 0, privacy TEXT DEFAULT '',
            views INTEGER DEFAULT 0, likes INTEGER DEFAULT 0, comments INTEGER DEFAULT 0,
            updated_at TEXT DEFAULT '')""")
        con.execute("""CREATE TABLE IF NOT EXISTS yt_video_daily (
            video_id TEXT NOT NULL, day TEXT NOT NULL, views INTEGER, likes INTEGER, comments INTEGER,
            PRIMARY KEY (video_id, day))""")
        con.execute("""CREATE TABLE IF NOT EXISTS yt_channel_daily (
            day TEXT PRIMARY KEY, subscribers INTEGER, views INTEGER, videos INTEGER)""")
        for net in ("ig", "fb"):
            con.execute(f"""CREATE TABLE IF NOT EXISTS {net}_videos (
                video_id TEXT PRIMARY KEY, title TEXT DEFAULT '', published_at TEXT DEFAULT '',
                thumb TEXT DEFAULT '', duration_s INTEGER DEFAULT 0, privacy TEXT DEFAULT '',
                views INTEGER DEFAULT 0, likes INTEGER DEFAULT 0, comments INTEGER DEFAULT 0,
                updated_at TEXT DEFAULT '', shares INTEGER DEFAULT 0, url TEXT DEFAULT '')""")
            con.execute(f"""CREATE TABLE IF NOT EXISTS {net}_video_daily (
                video_id TEXT NOT NULL, day TEXT NOT NULL, views INTEGER, likes INTEGER, comments INTEGER,
                PRIMARY KEY (video_id, day))""")
            con.execute(f"""CREATE TABLE IF NOT EXISTS {net}_channel_daily (
                day TEXT PRIMARY KEY, subscribers INTEGER, views INTEGER, videos INTEGER)""")
        con.execute("""CREATE TABLE IF NOT EXISTS tt_videos (
            video_id TEXT PRIMARY KEY, title TEXT DEFAULT '', published_at TEXT DEFAULT '',
            thumb TEXT DEFAULT '', duration_s INTEGER DEFAULT 0, privacy TEXT DEFAULT '',
            views INTEGER DEFAULT 0, likes INTEGER DEFAULT 0, comments INTEGER DEFAULT 0,
            updated_at TEXT DEFAULT '', shares INTEGER DEFAULT 0, url TEXT DEFAULT '')""")
        con.execute("""CREATE TABLE IF NOT EXISTS tt_video_daily (
            video_id TEXT NOT NULL, day TEXT NOT NULL, views INTEGER, likes INTEGER, comments INTEGER,
            PRIMARY KEY (video_id, day))""")
        con.execute("""CREATE TABLE IF NOT EXISTS tt_channel_daily (
            day TEXT PRIMARY KEY, subscribers INTEGER, views INTEGER, videos INTEGER)""")


# ---------------- coleta ----------------
def _duration(iso):
    m = re.match(r"P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", iso or "")
    if not m:
        return 0
    d, h, mi, s = (int(x or 0) for x in m.groups())
    return d * 86400 + h * 3600 + mi * 60 + s


def _local(iso_utc):
    """'2026-11-10T15:00:00Z' -> '2026-11-10 12:00' no horario deste computador."""
    try:
        dt = datetime.fromisoformat(iso_utc.replace("Z", "+00:00"))
        return dt.astimezone().strftime("%Y-%m-%d %H:%M")
    except Exception:
        return ""


def refresh(force=False):
    """Busca todos os videos do canal e grava a foto do dia. Custa ~3 unidades de cota."""
    if not youtube or not youtube.is_connected():
        state["error"] = "Conecte o canal do YouTube em Contas para ver o desempenho."
        return 0
    if not force and time.time() - state["at"] < REFRESH_MIN_GAP:
        return 0
    state.update(running=True, error="")
    try:
        yt = youtube.service()
        ch = yt.channels().list(part="contentDetails,statistics", mine=True).execute().get("items", [])
        if not ch:
            state["error"] = "A conta conectada não tem canal no YouTube."
            return 0
        uploads = ch[0]["contentDetails"]["relatedPlaylists"]["uploads"]
        cst = ch[0].get("statistics", {})
        ids, token = [], None
        for _ in range(20):                       # ate 1000 videos
            resp = yt.playlistItems().list(part="contentDetails", playlistId=uploads, maxResults=50,
                                           pageToken=token).execute()
            ids += [it["contentDetails"]["videoId"] for it in resp.get("items", [])]
            token = resp.get("nextPageToken")
            if not token:
                break
        rows = []
        for i in range(0, len(ids), 50):
            resp = yt.videos().list(part="snippet,statistics,contentDetails,status",
                                    id=",".join(ids[i:i + 50])).execute()
            for it in resp.get("items", []):
                sn, st = it.get("snippet", {}), it.get("statistics", {})
                thumbs = sn.get("thumbnails", {})
                rows.append((it["id"], sn.get("title", ""), _local(sn.get("publishedAt", "")),
                             (thumbs.get("medium") or thumbs.get("default") or {}).get("url", ""),
                             _duration(it.get("contentDetails", {}).get("duration")),
                             it.get("status", {}).get("privacyStatus", ""),
                             int(st.get("viewCount", 0)), int(st.get("likeCount", 0)),
                             int(st.get("commentCount", 0)), now_iso()))
        today = datetime.now().strftime("%Y-%m-%d")
        oldest = (datetime.now() - timedelta(days=KEEP_DAYS)).strftime("%Y-%m-%d")
        with _lock, db() as con:
            con.execute("DELETE FROM yt_videos")
            con.executemany("INSERT INTO yt_videos VALUES (?,?,?,?,?,?,?,?,?,?)", rows)
            con.executemany("INSERT OR REPLACE INTO yt_video_daily VALUES (?,?,?,?,?)",
                            [(r[0], today, r[6], r[7], r[8]) for r in rows])
            con.execute("INSERT OR REPLACE INTO yt_channel_daily VALUES (?,?,?,?)",
                        (today, int(cst.get("subscriberCount", 0) or 0), int(cst.get("viewCount", 0) or 0),
                         int(cst.get("videoCount", 0) or 0)))
            con.execute("DELETE FROM yt_video_daily WHERE day<?", (oldest,))
            con.execute("DELETE FROM yt_channel_daily WHERE day<?", (oldest,))
        state["at"] = time.time()
        return len(rows)
    except Exception as e:
        state["error"] = f"Não foi possível atualizar o desempenho: {e}"
        return 0
    finally:
        state["running"] = False


def refresh_async(force=False):
    if state["running"]:
        return
    threading.Thread(target=refresh, kwargs={"force": force}, name="desempenho", daemon=True).start()


def stats_hook():
    return refresh(force=True)


# ---------------- TikTok ----------------
def refresh_tiktok(force=False):
    """Le os videos do perfil do TikTok (precisa das permissoes video.list e user.info.stats)."""
    if not tiktok or not tiktok.has_stats():
        tt_state["error"] = "Ative os números do TikTok nesta página para ver o desempenho."
        return 0
    if not force and time.time() - tt_state["at"] < REFRESH_MIN_GAP:
        return 0
    tt_state.update(running=True, error="")
    try:
        videos = tiktok.list_videos()
        user = tiktok.user_stats()
        now_s = now_iso()
        rows = []
        for v in videos:
            created = datetime.fromtimestamp(int(v.get("create_time", 0) or 0)).strftime("%Y-%m-%d %H:%M")
            title = (v.get("title") or v.get("video_description") or "(sem legenda)").strip()
            rows.append((str(v.get("id")), title[:200], created, v.get("cover_image_url", ""),
                         int(v.get("duration", 0) or 0), "public", int(v.get("view_count", 0) or 0),
                         int(v.get("like_count", 0) or 0), int(v.get("comment_count", 0) or 0), now_s,
                         int(v.get("share_count", 0) or 0), v.get("share_url", "")))
        today = datetime.now().strftime("%Y-%m-%d")
        oldest = (datetime.now() - timedelta(days=KEEP_DAYS)).strftime("%Y-%m-%d")
        with _lock, db() as con:
            con.execute("DELETE FROM tt_videos")
            con.executemany("INSERT INTO tt_videos VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            con.executemany("INSERT OR REPLACE INTO tt_video_daily VALUES (?,?,?,?,?)",
                            [(r[0], today, r[6], r[7], r[8]) for r in rows])
            con.execute("INSERT OR REPLACE INTO tt_channel_daily VALUES (?,?,?,?)",
                        (today, int(user.get("follower_count", 0) or 0), sum(r[6] for r in rows),
                         int(user.get("video_count", len(rows)) or len(rows))))
            con.execute("DELETE FROM tt_video_daily WHERE day<?", (oldest,))
            con.execute("DELETE FROM tt_channel_daily WHERE day<?", (oldest,))
        tt_state["at"] = time.time()
        return len(rows)
    except Exception as e:
        tt_state["error"] = f"Não foi possível ler os números do TikTok: {e}"
        return 0
    finally:
        tt_state["running"] = False


def refresh_tiktok_async(force=False):
    if tt_state["running"]:
        return
    threading.Thread(target=refresh_tiktok, kwargs={"force": force}, name="desempenho-tiktok", daemon=True).start()


# ---------------- Instagram e Facebook ----------------
def _iso_local(value):
    try:
        v = value.replace("Z", "+00:00")
        if len(v) > 5 and v[-5] in "+-" and v[-3] != ":":
            v = v[:-2] + ":" + v[-2:]          # 2026-11-20T10:00:00+0000 -> +00:00
        return datetime.fromisoformat(v).astimezone().strftime("%Y-%m-%d %H:%M")
    except Exception:
        return ""


def _store(net, rows, followers, total_videos=None):
    today = datetime.now().strftime("%Y-%m-%d")
    oldest = (datetime.now() - timedelta(days=KEEP_DAYS)).strftime("%Y-%m-%d")
    with _lock, db() as con:
        con.execute(f"DELETE FROM {net}_videos")
        con.executemany(f"INSERT INTO {net}_videos VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows)
        con.executemany(f"INSERT OR REPLACE INTO {net}_video_daily VALUES (?,?,?,?,?)",
                        [(r[0], today, r[6], r[7], r[8]) for r in rows])
        con.execute(f"INSERT OR REPLACE INTO {net}_channel_daily VALUES (?,?,?,?)",
                    (today, int(followers or 0), sum(r[6] for r in rows), int(total_videos or len(rows))))
        con.execute(f"DELETE FROM {net}_video_daily WHERE day<?", (oldest,))
        con.execute(f"DELETE FROM {net}_channel_daily WHERE day<?", (oldest,))


def refresh_meta(net, force=False):
    st = meta_state[net]
    ready = meta and (meta.ig_ready() if net == "ig" else meta.page_ready())
    if not ready:
        st["error"] = "Conecte o Instagram e o Facebook em Contas."
        return 0
    if not force and time.time() - st["at"] < REFRESH_MIN_GAP:
        return 0
    st.update(running=True, error="")
    try:
        data = meta.instagram_stats() if net == "ig" else meta.facebook_stats()
        now_s = now_iso()
        rows = []
        for v in data["items"]:
            if net == "ig":
                dur = 1 if v["video"] else 0      # no Instagram: Reels (video) x fotos/carrosseis
            else:
                dur = v.get("duration", 0)
            rows.append((str(v["id"]), v["title"], _iso_local(v["created"]), v.get("thumb", ""), dur, "public",
                         int(v["views"]), int(v["likes"]), int(v["comments"]), now_s, int(v.get("shares", 0)), v.get("url", "")))
        _store(net, rows, data.get("followers"), data.get("media_count"))
        st["at"] = time.time()
        return len(rows)
    except Exception as e:
        st["error"] = f"Não foi possível ler os números: {e}"
        return 0
    finally:
        st["running"] = False


def refresh_meta_async(net, force=False):
    if meta_state[net]["running"]:
        return
    meta_state[net]["running"] = True
    threading.Thread(target=refresh_meta, args=(net, force), name=f"desempenho-{net}", daemon=True).start()


def meta_stats_hook():
    n = 0
    for net in ("ig", "fb"):
        try:
            n += refresh_meta(net, force=True)
        except Exception:
            pass
    return n


def clear(net):
    """Apaga os numeros guardados de uma rede (ao trocar de conta, para nao misturar)."""
    if net not in ("yt", "tt", "ig", "fb"):
        return
    with _lock, db() as con:
        for t in ("videos", "video_daily", "channel_daily"):
            con.execute(f"DELETE FROM {net}_{t}")
    if net == "yt":
        state["at"] = 0.0
    elif net == "tt":
        tt_state["at"] = 0.0
    else:
        meta_state[net]["at"] = 0.0


def tiktok_stats_hook():
    return refresh_tiktok(force=True) if tiktok and tiktok.has_stats() else 0


# ---------------- analise ----------------
def _median(values):
    return statistics.median(values) if values else 0


def _fmt(n):
    n = n or 0
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f} mi".replace(".", ",")
    if n >= 10_000:
        return f"{n / 1000:.0f} mil"
    if n >= 1000:
        return f"{n / 1000:.1f} mil".replace(".", ",")
    return str(n)


def dashboard(net="yt"):
    net = net if net in NETS else "yt"
    cfg = NETS[net]
    with db() as con:
        vids = [dict(r) for r in con.execute(
            f"SELECT * FROM {net}_videos WHERE privacy!='private' OR privacy='' ORDER BY published_at DESC")]
        private = con.execute(f"SELECT COUNT(*) FROM {net}_videos WHERE privacy='private'").fetchone()[0]
        chan = [dict(r) for r in con.execute(f"SELECT * FROM {net}_channel_daily ORDER BY day")]
        daily = {}
        for r in con.execute(f"SELECT * FROM {net}_video_daily ORDER BY day"):
            daily.setdefault(r["video_id"], []).append(dict(r))
        tracked = {r["vid"]: r["platform"] for r in con.execute(
            "SELECT result_url AS vid, platform FROM publications WHERE result_url!=''")}
    if not vids:
        return None
    now = datetime.now()
    for v in vids:
        try:
            pub = datetime.strptime(v["published_at"], "%Y-%m-%d %H:%M")
        except ValueError:
            pub = now
        v["age_days"] = max((now - pub).total_seconds() / 86400, 0.04)
        v["per_day"] = round(v["views"] / max(v["age_days"], 1), 1)
        v["eng"] = round((v["likes"] + v["comments"]) * 100 / v["views"], 1) if v["views"] else 0
        v["short"] = (v["duration_s"] == 1) if net == "ig" else (0 < v["duration_s"] <= cfg["short_max"])
        v["weekday"] = pub.weekday()
        v["hour"] = pub.hour
        v["date_br"] = pub.strftime("%d/%m/%y")
        v["url"] = v.get("url") or f"https://youtu.be/{v['video_id']}"
        hist = daily.get(v["video_id"], [])
        week_ago = (now - timedelta(days=7)).strftime("%Y-%m-%d")
        base = next((h for h in hist if h["day"] >= week_ago), None)
        v["gain7"] = v["views"] - base["views"] if base and base["day"] < now.strftime("%Y-%m-%d") else None
        v["tracked"] = any(v["video_id"] in u for u in tracked)
        v["shares"] = v.get("shares") or 0

    total_views = sum(v["views"] for v in vids)
    total_likes = sum(v["likes"] for v in vids)
    total_comments = sum(v["comments"] for v in vids)
    med = _median([v["views"] for v in vids])

    # serie diaria do canal (historico local: comeca no dia em que o painel foi aberto)
    series = [{"day": c["day"][8:10] + "/" + c["day"][5:7], "views": c["views"], "subs": c["subscribers"]}
              for c in chan]
    for i, s in enumerate(series):
        s["new_views"] = s["views"] - series[i - 1]["views"] if i else None
    gains = [s["new_views"] for s in series if s["new_views"] is not None]
    subs_gain = (series[-1]["subs"] - series[0]["subs"]) if len(series) > 1 else None

    # por data de publicacao (mais antigo -> mais novo)
    timeline = [{"label": v["date_br"], "title": v["title"], "views": v["views"], "likes": v["likes"],
                 "comments": v["comments"], "short": v["short"]}
                for v in sorted(vids, key=lambda x: x["published_at"])]
    top = sorted(vids, key=lambda x: x["views"], reverse=True)[:10]

    by_wd = {}
    for v in vids:
        by_wd.setdefault(v["weekday"], []).append(v["views"])
    weekday = [{"label": WEEKDAYS[d], "views": round(_median(by_wd.get(d, [])) or 0), "n": len(by_wd.get(d, []))}
               for d in range(7)]
    buckets = [("Madrugada", 0, 6), ("Manhã", 6, 12), ("Tarde", 12, 18), ("Noite", 18, 24)]
    by_hour = [{"label": f"{n} ({a}h–{b}h)", "views": round(_median([v["views"] for v in vids if a <= v["hour"] < b]) or 0),
                "n": len([v for v in vids if a <= v["hour"] < b])} for n, a, b in buckets]

    shorts = [v for v in vids if v["short"]]
    longs = [v for v in vids if not v["short"]]
    fmt = {"shorts": {"n": len(shorts), "median": round(_median([v["views"] for v in shorts])),
                      "eng": round(_median([v["eng"] for v in shorts]), 1)},
           "longs": {"n": len(longs), "median": round(_median([v["views"] for v in longs])),
                     "eng": round(_median([v["eng"] for v in longs]), 1)}}

    totals = {"views": total_views, "likes": total_likes, "comments": total_comments, "videos": len(vids),
              "private": private, "median": med,
              "eng": round((total_likes + total_comments) * 100 / total_views, 2) if total_views else 0,
              "subs": chan[-1]["subscribers"] if chan else None,
              "views_7d": sum(gains[-7:]) if gains else None, "subs_gain": subs_gain,
              "days_hist": len(series)}
    totals["shares"] = sum(v["shares"] for v in vids)
    return {"videos": vids, "top": top, "timeline": timeline, "series": series, "weekday": weekday,
            "by_hour": by_hour, "format": fmt, "totals": totals, "net": net, "cfg": cfg,
            "tips": recommendations(vids, totals, fmt, weekday, by_hour, net)}


def recommendations(vids, totals, fmt, weekday, by_hour, net="yt"):
    tips = []
    now = datetime.now()
    newest = min(vids, key=lambda v: v["age_days"])
    days_idle = int(newest["age_days"])
    if days_idle >= 3:
        tips.append(("Ritmo", f"Seu último vídeo saiu há {days_idle} dias. Canal pequeno cresce com constância: "
                              + ("a meta no TikTok é de 1 vídeo por dia, sempre nos mesmos horários." if net == "tt" else
                                 "a meta é de 4 a 7 Reels por semana, sempre nos mesmos horários." if net in ("ig", "fb") else
                                 "a meta é de 3 a 5 Shorts por semana, sempre nos mesmos horários.")))
    else:
        tips.append(("Ritmo", "Boa constância: você publicou nos últimos dias. Mantenha a frequência por "
                              "pelo menos 4 semanas antes de julgar os resultados."))
    best = max(vids, key=lambda v: v["views"])
    if best["views"] > max(totals["median"] * 2, 50):
        tips.append(("Repita o que funcionou", f"“{best['title'][:70]}” tem {_fmt(best['views'])} visualizações, "
                     f"{round(best['views'] / max(totals['median'], 1))}x a mediana do canal. Faça uma parte 2, "
                     "uma reação aos comentários ou um corte novo do mesmo tema."))
    s, l = fmt["shorts"], fmt["longs"]
    if net == "ig":
        if s["n"] and l["n"] and s["median"] > l["median"] * 1.5:
            tips.append(("Formato", "No seu Instagram os Reels alcançam bem mais que fotos e carrosséis. "
                                    "Priorize Reels e use carrossel para bastidores e personagens."))
    if net in ("tt", "ig", "fb"):
        shares = totals.get("shares", 0)
        if totals["views"] and shares * 1000 / max(totals["views"], 1) < 2:
            tips.append(("Compartilhamentos", "Poucos compartilhamentos por visualização. Termine com uma "
                                              "reviravolta ou pergunta que faça a pessoa marcar um amigo."))
    if net == "tt":
        if s["n"] >= 2 and l["n"] >= 2:
            better = "curtos (até 30 s)" if s["median"] >= l["median"] else "mais longos (acima de 30 s)"
            tips.append(("Duração", f"No seu TikTok os vídeos {better} rendem mais na mediana. Corte as partes lentas "
                                    "e entre na ação já no primeiro segundo."))
    elif net == "yt" and s["n"] >= 2 and l["n"] >= 2:
        if s["median"] > l["median"] * 1.5:
            tips.append(("Formato", f"Seus Shorts têm mediana de {_fmt(s['median'])} visualizações contra "
                                    f"{_fmt(l['median'])} dos vídeos longos. Use Shorts como vitrine e coloque "
                                    "o link do episódio completo no comentário fixado."))
        elif l["median"] > s["median"] * 1.5:
            tips.append(("Formato", f"Os vídeos longos rendem mais ({_fmt(l['median'])} contra {_fmt(s['median'])} "
                                    "nos Shorts). Faça Shorts que terminem com gancho para o vídeo longo."))
    elif net == "yt" and s["n"] and not l["n"]:
        tips.append(("Formato", "Só há Shorts no canal. Um vídeo longo juntando 4 ou 5 episódios ("
                                "‘maratona’) aumenta o tempo de exibição e ajuda a converter inscritos."))
    good_wd = [w for w in weekday if w["n"] >= 2]
    if len(good_wd) >= 2:
        w = max(good_wd, key=lambda x: x["views"])
        h = max([b for b in by_hour if b["n"] >= 2] or by_hour, key=lambda x: x["views"])
        tips.append(("Melhor horário", f"Na sua amostra, {w['label']} e o período da {h['label'].split(' ')[0].lower()} "
                                       "trazem as maiores medianas. Ajuste os horários em Configurações → Automação "
                                       "e confirme depois de mais 10 vídeos."))
    if totals["eng"] and totals["eng"] < 4:
        tips.append(("Engajamento", f"A taxa de curtidas + comentários está em {format(totals['eng'], '.1f').replace('.', ',')}%. "
                                    "Feche cada vídeo com uma pergunta direta (\"o que você faria no lugar dele?\") "
                                    "e responda os primeiros comentários na primeira hora."))
    elif totals["eng"] >= 8:
        tips.append(("Engajamento", f"Ótima taxa de engajamento ({format(totals['eng'], '.1f').replace('.', ',')}%). "
                                    "O público gosta do conteúdo: o gargalo é alcance. Divulgue mais em comunidades "
                                    "(Onde divulgar) e teste títulos mais curiosos."))
    weak = [v for v in vids if v["age_days"] > 7 and v["views"] < totals["median"] * 0.3]
    if weak:
        tips.append(("Legendas e capas" if net != "yt" else "Títulos e miniaturas", f"{len(weak)} vídeo(s) com mais de 7 dias ficaram bem abaixo da "
                     f"mediana, por exemplo “{weak[0]['title'][:60]}”. Teste um título com pergunta ou "
                     "número e uma miniatura com rosto/expressão forte."))
    no_comments = [v for v in vids if v["views"] >= 100 and v["comments"] == 0]
    if no_comments:
        tips.append(("Comentários", f"{len(no_comments)} vídeo(s) com 100+ visualizações e nenhum comentário. "
                                    "Fixe um comentário seu com uma pergunta para puxar a conversa."))
    if totals["subs"] and totals["views"]:
        rate = totals["subs"] * 100 / totals["views"]
        if rate < 1:
            if net in ("tt", "ig", "fb"):
                tips.append(("Seguidores", "Poucas visualizações viram seguidores. Numere a série (\"Parte 1\", "
                                           "\"Parte 2\"), fixe as partes no perfil e termine com \"siga para ver a parte 2\"."))
            else:
                tips.append(("Inscritos", "Poucas visualizações viram inscrição. Peça a inscrição dentro da história "
                                          "(\"se inscreva para ver o que acontece no episódio 2\") e numere a série."))
    return tips[:7]
