"""Agendador em segundo plano: executa as publicacoes da fila na hora marcada."""
import threading, time, traceback
from datetime import datetime, timedelta

import publishers
from core import db, log, now_iso, setting, _lock

FMT = "%Y-%m-%d %H:%M"
MAX_ATTEMPTS = 3
CHECK_EVERY = 30  # segundos

_thread = None
last_run = {"at": "", "processed": 0}


def _update(pub_id, **fields):
    fields["updated_at"] = now_iso()
    cols = ", ".join(f"{k}=?" for k in fields)
    with _lock, db() as con:
        con.execute(f"UPDATE publications SET {cols} WHERE id=?", (*fields.values(), pub_id))


def execute(pub_id):
    """Executa uma publicacao agora (usado pelo agendador e pelo botao 'Publicar agora')."""
    with db() as con:
        pub = con.execute("SELECT * FROM publications WHERE id=?", (pub_id,)).fetchone()
    if not pub or pub["status"] in ("Publicada", "Cancelada", "Processando"):
        return
    _update(pub_id, status="Processando", attempts=pub["attempts"] + 1)
    publisher = publishers.get(pub["platform"])
    label = f"#{pub_id} ({pub['platform']}) {pub['title'][:40]}"
    try:
        result = publisher.publish(pub)
        fields = {"status": result.status, "message": result.message, "next_try_at": ""}
        if result.url:
            fields["result_url"] = result.url
        if result.status == "Publicada":
            fields["published_at"] = now_iso()
            log(f"Publicação {label} enviada via {publisher.name}")
        else:
            log(f"Publicação {label} pronta, aguardando você")
        _update(pub_id, **fields)
    except publishers.TemporaryError as e:
        attempts = pub["attempts"] + 1
        if attempts >= MAX_ATTEMPTS:
            _update(pub_id, status="Erro", message=f"Falhou {attempts} vezes: {e}")
            log(f"Publicação {label} falhou de vez: {e}")
        else:
            retry = (datetime.now() + timedelta(minutes=10 * attempts)).strftime(FMT)
            _update(pub_id, status="Agendada", next_try_at=retry,
                    message=f"Tentativa {attempts} falhou ({e}). Nova tentativa às {retry[-5:]}.")
            log(f"Publicação {label}: nova tentativa às {retry[-5:]}")
    except publishers.PermanentError as e:
        _update(pub_id, status="Erro", message=str(e))
        log(f"Publicação {label} com erro: {e}")
    except Exception as e:
        _update(pub_id, status="Erro", message=f"Erro inesperado: {e}")
        log(f"Publicação {label} com erro: {e}")
        traceback.print_exc()


def run_due():
    """Processa tudo que ja passou do horario. Retorna quantas publicacoes foram processadas."""
    if setting("AUTOPILOT") != "on":
        return 0
    t = now_iso()
    with db() as con:
        due = con.execute("""SELECT id FROM publications WHERE status='Agendada' AND scheduled_at<=?
                             AND (next_try_at='' OR next_try_at<=?) ORDER BY scheduled_at LIMIT 10""",
                          (t, t)).fetchall()
    for row in due:
        execute(row["id"])
    last_run.update(at=t, processed=len(due))
    return len(due)


STATS_EVERY = 6 * 3600
_last_stats = 0.0
stats_hooks = []   # funcoes chamadas periodicamente (ex.: estatisticas do YouTube)


def run_stats():
    global _last_stats
    _last_stats = time.time()
    total = 0
    for hook in stats_hooks:
        try:
            total += hook() or 0
        except Exception as e:
            print("Falha ao atualizar estatisticas:", e)
    return total


due_hooks = []   # funcoes chamadas a cada verificacao (ex.: posts automaticos no Lemmy)


def _loop():
    while True:
        try:
            run_due()
            for hook in due_hooks:
                try:
                    hook()
                except Exception:
                    traceback.print_exc()
            if time.time() - _last_stats > STATS_EVERY:
                run_stats()
        except Exception:
            traceback.print_exc()
        time.sleep(CHECK_EVERY)


def start():
    global _thread
    if _thread is None or not _thread.is_alive():
        # publicacoes presas em "Processando" (programa fechado no meio) voltam para a fila
        with _lock, db() as con:
            con.execute("UPDATE publications SET status='Agendada' WHERE status='Processando'")
        _thread = threading.Thread(target=_loop, name="agendador", daemon=True)
        _thread.start()


def post_times():
    times = []
    for t in setting("POST_TIMES").split(","):
        try:
            times.append(datetime.strptime(t.strip(), "%H:%M").time())
        except ValueError:
            pass
    return sorted(times) or [datetime.strptime("18:00", "%H:%M").time()]


def next_free_slot(platform, after=None):
    """Proximo horario livre em POST_TIMES respeitando MAX_PER_DAY por plataforma."""
    after = after or (datetime.now() + timedelta(minutes=15))
    try:
        max_day = max(1, int(setting("MAX_PER_DAY")))
    except ValueError:
        max_day = 2
    with db() as con:
        rows = con.execute("""SELECT scheduled_at FROM publications WHERE platform=?
                              AND status NOT IN ('Cancelada','Erro')""", (platform,)).fetchall()
    taken = {r["scheduled_at"] for r in rows}
    per_day = {}
    for s in taken:
        per_day[s[:10]] = per_day.get(s[:10], 0) + 1
    day = after.date()
    try:
        import besttime
        times = besttime.times_for(platform) or post_times()
    except Exception:
        times = post_times()
    for _ in range(366):
        for t in times:
            slot = datetime.combine(day, t)
            key = slot.strftime(FMT)
            if slot >= after and key not in taken and per_day.get(key[:10], 0) < max_day:
                return key
        day += timedelta(days=1)
    return after.strftime(FMT)
