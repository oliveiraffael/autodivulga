from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import os, re, subprocess, shutil, sys, socket
from datetime import datetime
from pathlib import Path

from core import (VERSION, BASE, EXPORTS, MEDIA, STATUSES, PLATFORMS, PUB_STATUSES, PUB_PLATFORMS,
                  load_env, save_env, setting, secret_key, db, now, now_iso, iso_to_br, log, init_db, backup_db)

SETTING_KEYS = ["AI_MODE", "OLLAMA_MODEL", "OPENAI_API_KEY", "OPENAI_MODEL", "OPENAI_BASE_URL"]
PORT = 5055

load_env()
import ai_writer
from ai_writer import generate_campaign_copy, generate_place_post, ollama_status  # depois do .env
import publishers, scheduler, discovery, partners, lemmy, telegram, links, social, tgbot
import insights, trends, comments, report, meta
try:
    import youtube
    YT_ERROR = ""
except ImportError as e:  # bibliotecas do Google ainda nao instaladas
    youtube = None
    YT_ERROR = f"Bibliotecas do Google não instaladas ({e.name}). Feche e abra o INICIAR.bat para instalar."
try:
    import tiktok
    TT_ERROR = ""
except ImportError as e:
    tiktok = None
    TT_ERROR = f"Biblioteca não instalada ({e.name}). Feche e abra o INICIAR.bat para instalar."

from core import RES, FROZEN
app = Flask(__name__, template_folder=str(RES / "templates"), static_folder=str(RES / "static"))
app.secret_key = os.environ.get("AUTODIVULGA_SECRET") or secret_key()
app.jinja_env.filters["br"] = iso_to_br
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 ** 3   # ate 8 GB por arquivo arrastado


LOCAL_HOSTS = {f"127.0.0.1:{5055}", f"localhost:{5055}"}
LOCAL_ORIGIN = re.compile(r"^http://(127\.0\.0\.1|localhost):5055(/|$)")


@app.before_request
def only_this_computer():
    """Seguranca: o painel so aceita comandos vindos dele mesmo.
    Sem isso, qualquer site aberto no navegador poderia enviar formularios para 127.0.0.1:5055
    (apagar campanhas, trocar chaves, etc.) ou usar um dominio falso apontando para este PC."""
    if request.host not in LOCAL_HOSTS:
        return "Acesso permitido só pelo endereço http://127.0.0.1:5055", 403
    if request.method == "POST":
        origin = request.headers.get("Origin") or request.headers.get("Referer") or ""
        if origin and not LOCAL_ORIGIN.match(origin):
            log(f"Bloqueado um comando vindo de outro site ({origin[:60]})")
            return "Bloqueado: este comando não veio do painel do AutoDivulga.", 403


# ---------- utilidades ----------
def valid_url(url):
    return bool(re.match(r"^https?://\S+$", url))


VIDEO_EXT = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v", ".wmv", ".flv", ".mpeg", ".mpg"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp"}


def clean_path(value):
    """Limpa o caminho e corrige a falta de extensao (o Windows esconde '.mp4' por padrao)."""
    value = (value or "").strip().strip('"').strip("'")
    if not value:
        return ""
    p = Path(value)
    if p.is_file():
        return str(p)
    try:
        if p.parent.is_dir():
            matches = [m for m in p.parent.glob(p.name + ".*")
                       if m.is_file() and m.suffix.lower() in VIDEO_EXT | IMAGE_EXT]
            if matches:
                return str(sorted(matches, key=lambda m: m.suffix.lower() not in VIDEO_EXT)[0])
    except OSError:
        pass
    return value


def unique_media_name(filename, allowed):
    from werkzeug.utils import secure_filename
    ext = Path(filename).suffix.lower()
    if ext not in allowed:
        return None
    stem = secure_filename(Path(filename).stem) or "arquivo"
    MEDIA.mkdir(exist_ok=True)
    out, n = MEDIA / f"{stem}{ext}", 2
    while out.exists():
        out = MEDIA / f"{stem}_{n}{ext}"; n += 1
    return out


def get_campaign(cid):
    with db() as con:
        return con.execute("SELECT * FROM campaigns WHERE id=?", (cid,)).fetchone()


def get_pub(pid):
    with db() as con:
        return con.execute("""SELECT p.*, c.title AS campaign_title FROM publications p
                              LEFT JOIN campaigns c ON c.id=p.campaign_id WHERE p.id=?""", (pid,)).fetchone()


_ai_cache = {"t": 0, "off": False}


def ai_offline():
    """True quando a IA nao tem como funcionar (verificado no maximo 1x por minuto)."""
    import time
    if time.time() - _ai_cache["t"] > 60:
        mode = setting("AI_MODE")
        online, models = ollama_status()
        has_api = bool(os.getenv("OPENAI_API_KEY"))
        ok = mode == "offline" or (mode in ("hybrid", "ollama") and online and models) or \
            (mode in ("hybrid", "api") and has_api)
        _ai_cache.update(t=time.time(), off=not ok)
    return _ai_cache["off"]


@app.context_processor
def globals_for_templates():
    with db() as con:
        waiting = con.execute("SELECT COUNT(*) FROM publications WHERE status='Aguardando você'").fetchone()[0]
        suggested = con.execute("SELECT COUNT(*) FROM places WHERE status='Sugerido'").fetchone()[0]
    return {"pub_platforms": PUB_PLATFORMS, "ig_connected": bool(meta.ig_ready()), "fb_connected": bool(meta.page_ready()),
            "suggested_count": suggested, "ai_offline": ai_offline(), "comments_new": comments.counts().get("novo", 0),
            "yt_connected": bool(youtube and youtube.is_connected()),
            "tt_connected": bool(tiktok and tiktok.is_connected()), "ffmpeg_ok": bool(shutil.which("ffmpeg")), "is_windows": sys.platform.startswith("win"),
            "waiting_count": waiting, "autopilot": setting("AUTOPILOT") == "on", "version": VERSION}


# ---------- painel ----------
@app.route("/")
def index():
    if request.args.get("state") and (request.args.get("code") or request.args.get("error")):
        return youtube_callback()
    status = request.args.get("status", "")
    q = request.args.get("q", "").strip()
    sql, args = "SELECT * FROM campaigns WHERE 1=1", []
    if status in STATUSES:
        sql += " AND status=?"; args.append(status)
    if q:
        sql += " AND (title LIKE ? OR topic LIKE ?)"; args += [f"%{q}%", f"%{q}%"]
    with db() as con:
        campaigns = con.execute(sql + " ORDER BY id DESC", args).fetchall()
        counts = {s: 0 for s in STATUSES}
        for r in con.execute("SELECT status, COUNT(*) n FROM campaigns GROUP BY status"):
            counts[r["status"]] = r["n"]
        upcoming = con.execute("""SELECT p.*, c.title AS campaign_title FROM publications p
                                  LEFT JOIN campaigns c ON c.id=p.campaign_id
                                  WHERE p.status IN ('Agendada','Aguardando você')
                                  ORDER BY p.status='Aguardando você' DESC, p.scheduled_at LIMIT 5""").fetchall()
        activity = con.execute("SELECT * FROM activity ORDER BY id DESC LIMIT 8").fetchall()
    return render_template("index.html", onboarding=onboarding(), campaigns=campaigns, activity=activity, counts=counts,
                           total=sum(counts.values()), statuses=STATUSES, cur_status=status, q=q,
                           upcoming=upcoming)


# ---------- campanhas ----------
@app.route("/campaign/new", methods=["GET", "POST"])
def new_campaign():
    form = request.form
    if request.method == "POST":
        title = form.get("title", "").strip()
        url = form.get("video_url", "").strip()
        platform = form.get("platform") if form.get("platform") in PLATFORMS else "YouTube"
        topic, audience = form.get("topic", "").strip(), form.get("audience", "").strip()
        video_path = clean_path(form.get("video_path"))
        if not title:
            flash("Informe o título do vídeo.", "error")
            return render_template("new_campaign.html", form=form, platforms=PLATFORMS)
        if url and not valid_url(url):
            flash("O link precisa começar com http:// ou https://", "error")
            return render_template("new_campaign.html", form=form, platforms=PLATFORMS)
        if not url and not video_path:
            flash("Informe o link do vídeo ou o arquivo no computador.", "error")
            return render_template("new_campaign.html", form=form, platforms=PLATFORMS)
        caption, hashtags, source = generate_campaign_copy(title, topic, audience, platform)
        with db() as con:
            cur = con.execute("""INSERT INTO campaigns(title,video_url,platform,topic,audience,status,
                                 caption,hashtags,created_at,ai_source,updated_at,video_path)
                                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                              (title, url, platform, topic, audience, "Rascunho", caption, hashtags,
                               now(), source, now(), video_path))
            cid = cur.lastrowid
        log(f"Campanha criada: {title} ({platform}) · texto via {source}")
        if len(platforms_of(platform)) > 1:
            if form.get("autoschedule"):        # agenda ja com o texto pronto de cada rede; a IA melhora depois
                pernet.save(cid, pernet._fallback(get_campaign(cid), platforms_of(platform)))
        if form.get("autoschedule"):
            created = auto_schedule(cid)
            flash(f"Campanha criada e {len(created)} publicação(ões) agendada(s) automaticamente.", "success")
        else:
            flash(f"Campanha criada (texto gerado via {source}). Revise antes de publicar.", "success")
        if len(platforms_of(platform)) > 1:
            pernet.generate_async(cid, platforms_of(platform))   # depois de agendar, para atualizar as publicacoes
        return redirect(url_for("edit_campaign", cid=cid))
    return render_template("new_campaign.html", form={}, platforms=PLATFORMS)


@app.route("/campaign/<int:cid>", methods=["GET", "POST"])
def edit_campaign(cid):
    c = get_campaign(cid)
    if not c:
        flash("Campanha não encontrada.", "error")
        return redirect(url_for("index"))
    if request.method == "POST":
        f = request.form
        url = f.get("video_url", "").strip()
        if url and not valid_url(url):
            flash("O link precisa começar com http:// ou https://", "error")
            return redirect(url_for("edit_campaign", cid=cid))
        platform = f.get("platform") if f.get("platform") in PLATFORMS else c["platform"]
        with db() as con:
            con.execute("""UPDATE campaigns SET title=?, video_url=?, platform=?, topic=?, audience=?,
                           caption=?, hashtags=?, video_path=?, updated_at=? WHERE id=?""",
                        (f.get("title", "").strip() or c["title"], url, platform,
                         f.get("topic", "").strip(), f.get("audience", "").strip(),
                         f.get("caption", "").strip(), f.get("hashtags", "").strip(),
                         clean_path(f.get("video_path")), now(), cid))
        log(f"Campanha #{cid} editada")
        flash("Alterações salvas.", "success")
        return redirect(url_for("edit_campaign", cid=cid))
    with db() as con:
        pubs = con.execute("SELECT * FROM publications WHERE campaign_id=? ORDER BY scheduled_at DESC",
                           (cid,)).fetchall()
    share_buttons, share_copies = links.share_kit(c)
    try:
        clicks = links.stats(cid)
    except Exception:
        clicks = None
    return render_template("copy.html", c=c, platforms=PLATFORMS, statuses=STATUSES, pubs=pubs,
                           video_exists=bool(c["video_path"]) and Path(c["video_path"]).is_file(),
                           share_buttons=share_buttons, share_copies=share_copies, clicks=clicks,
                           tracked=partners.is_deployed(), is_video=social.is_video_link(c["video_url"]),
                           networks={social.NETWORKS[k]: v for k, v in social.configured().items()},
                           announced=social.history(cid), share_text=links.share_text(c, 400),
                           script_state=trends.script_state.get(cid, ""),
                           per_net=pernet.get(c), net_list=platforms_of(c["platform"]),
                           pernet_state=pernet.state.get(cid, ""))


@app.route("/campaign/<int:cid>/announce", methods=["POST"])
def campaign_announce(cid):
    if not get_campaign(cid):
        return redirect(url_for("index"))
    try:
        done, failed = social.announce_all(cid)
    except social.SocialError as e:
        done, failed = [], [str(e)]
    if done:
        flash("Anunciado em: " + ", ".join(done) + ".", "success")
    if failed:
        flash("Não foi possível: " + "; ".join(failed), "error")
    if not done and not failed:
        flash("Nenhuma rede nova para anunciar. Conecte Bluesky, Mastodon ou Telegram em Contas.", "error")
    return redirect(url_for("edit_campaign", cid=cid) + "#compartilhar")


@app.route("/campaign/<int:cid>/copy")
def copy_campaign(cid):
    return redirect(url_for("edit_campaign", cid=cid))


@app.route("/campaign/<int:cid>/regenerate", methods=["POST"])
def regenerate_campaign(cid):
    c = get_campaign(cid)
    if not c:
        return redirect(url_for("index"))
    caption, hashtags, source = generate_campaign_copy(c["title"], c["topic"], c["audience"], c["platform"])
    with db() as con:
        con.execute("UPDATE campaigns SET caption=?, hashtags=?, ai_source=?, updated_at=? WHERE id=?",
                    (caption, hashtags, source, now(), cid))
    log(f"Texto da campanha #{cid} gerado novamente via {source}")
    flash(f"Novo texto gerado via {source}.", "success")
    return redirect(url_for("edit_campaign", cid=cid))


@app.route("/campaign/<int:cid>/duplicate", methods=["POST"])
def duplicate_campaign(cid):
    c = get_campaign(cid)
    if not c:
        return redirect(url_for("index"))
    with db() as con:
        cur = con.execute("""INSERT INTO campaigns(title,video_url,platform,topic,audience,status,
                             caption,hashtags,created_at,ai_source,updated_at,video_path)
                             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                          (c["title"] + " (cópia)", c["video_url"], c["platform"], c["topic"], c["audience"],
                           "Rascunho", c["caption"], c["hashtags"], now(), c["ai_source"], now(), c["video_path"]))
        new_id = cur.lastrowid
    log(f"Campanha #{cid} duplicada como #{new_id}")
    flash("Campanha duplicada.", "success")
    return redirect(url_for("edit_campaign", cid=new_id))


@app.route("/campaign/<int:cid>/status", methods=["POST"])
def status_campaign(cid):
    status = request.form.get("status", "Rascunho")
    status = status if status in STATUSES else "Rascunho"
    with db() as con:
        con.execute("UPDATE campaigns SET status=?, updated_at=? WHERE id=?", (status, now(), cid))
    log(f"Status da campanha #{cid} alterado para {status}")
    flash("Status atualizado.", "success")
    return redirect(request.referrer or url_for("index"))


@app.route("/campaign/<int:cid>/delete", methods=["GET", "POST"])
def delete_campaign(cid):
    """Pergunta o que fazer com as publicacoes antes de apagar (antes ficavam soltas, sem campanha)."""
    c = get_campaign(cid)
    if not c:
        flash("Campanha não encontrada.", "error")
        return redirect(url_for("index"))
    with db() as con:
        pubs = con.execute("SELECT id, platform, status, title, result_url FROM publications WHERE campaign_id=?",
                           (cid,)).fetchall()
    published = [p for p in pubs if p["status"] == "Publicada"]
    pending = [p for p in pubs if p["status"] != "Publicada"]
    if request.method == "GET":
        return render_template("delete_campaign.html", c=c, published=published, pending=pending)
    mode = request.form.get("mode", "keep")
    with db() as con:
        if mode == "all":
            con.execute("DELETE FROM publications WHERE campaign_id=?", (cid,))
        else:
            # publicadas ficam (com historico e estatisticas); o resto nao faz sentido sem a campanha
            con.execute("DELETE FROM publications WHERE campaign_id=? AND status!='Publicada'", (cid,))
            con.execute("""UPDATE publications SET title=COALESCE(NULLIF(title,''), ?), campaign_id=NULL
                           WHERE campaign_id=? AND status='Publicada'""", (c["title"], cid))
        con.execute("DELETE FROM places WHERE campaign_id=?", (cid,))
        con.execute("DELETE FROM campaigns WHERE id=?", (cid,))
    n_del = len(pubs) if mode == "all" else len(pending)
    log(f"Campanha #{cid} excluída ({n_del} publicação(ões) apagada(s)"
        + ("" if mode == "all" else f", {len(published)} publicada(s) mantida(s)") + ")")
    flash("Campanha excluída." + (f" {len(published)} publicação(ões) já publicada(s) continuam em Publicações."
                                  if mode != "all" and published else ""), "success")
    return redirect(url_for("index"))


def platforms_of(campaign_platform):
    """Redes de uma campanha. "Ambas" (versoes antigas) = YouTube + TikTok."""
    groups = {"Ambas": ["YouTube", "TikTok"], "Instagram + Facebook": ["Instagram", "Facebook"],
              "Todas as redes": list(PUB_PLATFORMS)}
    if campaign_platform in groups:
        return groups[campaign_platform]
    return [campaign_platform] if campaign_platform in PUB_PLATFORMS else ["YouTube"]


def pub_texts(c, platform):
    """Titulo e descricao padrao de cada plataforma a partir da campanha (usa o texto proprio da rede, se houver)."""
    own = pernet.texts_for(c, platform)
    if own:
        return (own[0] if platform == "YouTube" else own[1][:150]), own[1]
    if platform == "YouTube":
        return c["title"][:100], c["caption"]
    return c["caption"][:150], c["caption"]


def create_pub(c, platform, scheduled_at, privacy=None, title=None, description=None,
               hashtags=None, video_path=None):
    if privacy not in ("private", "unlisted", "public"):
        privacy = setting("YT_PRIVACY") if setting("YT_PRIVACY") in ("private", "unlisted", "public") else "public"
    dt, dd = pub_texts(c, platform) if c else ("", "")
    with db() as con:
        cur = con.execute("""INSERT INTO publications(campaign_id, platform, title, description, hashtags,
                             video_path, privacy, scheduled_at, status, created_at, updated_at)
                             VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                          (c["id"] if c else None, platform, title if title is not None else dt,
                           description if description is not None else dd,
                           hashtags if hashtags is not None else (
                               ((pernet.texts_for(c, platform) or (0, 0, c["hashtags"]))[2]) if c else ""),
                           video_path if video_path is not None else (c["video_path"] if c else ""),
                           privacy, scheduled_at, "Agendada", now_iso(), now_iso()))
        return cur.lastrowid


def auto_schedule(cid):
    c = get_campaign(cid)
    created = []
    for platform in platforms_of(c["platform"]):
        slot = scheduler.next_free_slot(platform)
        created.append(create_pub(c, platform, slot))
        log(f"Publicação no {platform} agendada para {iso_to_br(slot)} (campanha #{cid})")
    with db() as con:
        con.execute("UPDATE campaigns SET status='Aprovada', updated_at=? WHERE id=? AND status='Rascunho'",
                    (now(), cid))
    return created


@app.route("/campaign/<int:cid>/autoschedule", methods=["POST"])
def autoschedule_campaign(cid):
    c = get_campaign(cid)
    if not c:
        return redirect(url_for("index"))
    if not (c["video_path"] or c["video_url"]):
        flash("Adicione o vídeo (arquivo no computador ou link) antes de agendar. Sem ele não há o que publicar.", "error")
        return redirect(url_for("edit_campaign", cid=cid))
    created = auto_schedule(cid)
    flash(f"{len(created)} publicação(ões) agendada(s) nos próximos horários livres.", "success")
    return redirect(url_for("edit_campaign", cid=cid))


@app.route("/publications")
def publications():
    status = request.args.get("status", "")
    platform = request.args.get("platform", "")
    sql = """SELECT p.*, c.title AS campaign_title FROM publications p
             LEFT JOIN campaigns c ON c.id=p.campaign_id WHERE 1=1"""
    args = []
    if status in PUB_STATUSES:
        sql += " AND p.status=?"; args.append(status)
    if platform in PUB_PLATFORMS:
        sql += " AND p.platform=?"; args.append(platform)
    order = " ORDER BY p.scheduled_at DESC" if status in ("Publicada", "Cancelada") else \
            " ORDER BY p.status='Aguardando você' DESC, p.status IN ('Publicada','Cancelada'), p.scheduled_at"
    with db() as con:
        pubs = con.execute(sql + order + " LIMIT 300", args).fetchall()
        counts = {s: 0 for s in PUB_STATUSES}
        for r in con.execute("SELECT status, COUNT(*) n FROM publications GROUP BY status"):
            counts[r["status"]] = r["n"]
    # agenda dos proximos 7 dias
    days = []
    today = datetime.now().date()
    with db() as con:
        for i in range(7):
            d = today.toordinal() + i
            day = datetime.fromordinal(d).date()
            items = con.execute("""SELECT p.id, p.platform, p.status, substr(p.scheduled_at,12,5) hora, p.title
                                   FROM publications p WHERE substr(p.scheduled_at,1,10)=?
                                   AND p.status!='Cancelada' ORDER BY p.scheduled_at""",
                                (day.isoformat(),)).fetchall()
            days.append((day, items))
    return render_template("publications.html", pubs=pubs, counts=counts, statuses=PUB_STATUSES,
                           platforms=PUB_PLATFORMS, cur_status=status, cur_platform=platform, days=days,
                           connected=publishers.status_by_platform(), last_run=scheduler.last_run)


@app.route("/publications/new", methods=["GET", "POST"])
def new_publication():
    with db() as con:
        campaigns = con.execute("SELECT id, title, platform FROM campaigns ORDER BY id DESC").fetchall()
    if request.method == "POST":
        f = request.form
        c = get_campaign(int(f.get("campaign_id") or 0))
        if not c:
            flash("Escolha uma campanha.", "error")
            return redirect(url_for("new_publication"))
        chosen = [p for p in PUB_PLATFORMS if f.get("p_" + p)]
        if not chosen:
            flash("Marque pelo menos uma plataforma.", "error")
            return redirect(url_for("new_publication", campaign=c["id"]))
        mode = f.get("when", "auto")
        privacy = f.get("privacy") if f.get("privacy") in ("private", "unlisted", "public") else None
        ids = []
        for platform in chosen:
            if mode == "now":
                slot = now_iso()
            elif mode == "date":
                try:
                    slot = datetime.strptime(f.get("scheduled_at", ""), "%Y-%m-%dT%H:%M").strftime("%Y-%m-%d %H:%M")
                except ValueError:
                    flash("Data e hora inválidas.", "error")
                    return redirect(url_for("new_publication", campaign=c["id"]))
            else:
                slot = scheduler.next_free_slot(platform)
            ids.append(create_pub(c, platform, slot, privacy=privacy))
            log(f"Publicação no {platform} agendada para {iso_to_br(slot)} (campanha #{c['id']})")
        if mode == "now":
            for pid in ids:
                scheduler.execute(pid)
        flash(f"{len(ids)} publicação(ões) criada(s).", "success")
        return redirect(url_for("view_publication", pid=ids[0]) if len(ids) == 1 else url_for("publications"))
    pre = request.args.get("campaign", type=int)
    c = get_campaign(pre) if pre else None
    return render_template("new_publication.html", campaigns=campaigns, pre=c,
                           pre_platforms=platforms_of(c["platform"]) if c else ["YouTube"],
                           default_dt=datetime.now().strftime("%Y-%m-%dT%H:%M"))


@app.route("/publications/<int:pid>", methods=["GET", "POST"])
def view_publication(pid):
    p = get_pub(pid)
    if not p:
        flash("Publicação não encontrada.", "error")
        return redirect(url_for("publications"))
    if request.method == "POST":
        if p["status"] in ("Publicada", "Processando"):
            flash("Esta publicação não pode mais ser editada.", "error")
            return redirect(url_for("view_publication", pid=pid))
        f = request.form
        try:
            slot = datetime.strptime(f.get("scheduled_at", ""), "%Y-%m-%dT%H:%M").strftime("%Y-%m-%d %H:%M")
        except ValueError:
            slot = p["scheduled_at"]
        privacy = f.get("privacy") if f.get("privacy") in ("private", "unlisted", "public") else p["privacy"]
        with db() as con:
            con.execute("""UPDATE publications SET title=?, description=?, hashtags=?, video_path=?,
                           thumbnail_path=?, privacy=?, scheduled_at=?, updated_at=? WHERE id=?""",
                        (f.get("title", "").strip(), f.get("description", "").strip(),
                         f.get("hashtags", "").strip(), clean_path(f.get("video_path")),
                         clean_path(f.get("thumbnail_path")), privacy, slot, now_iso(), pid))
        log(f"Publicação #{pid} editada")
        flash("Publicação salva.", "success")
        return redirect(url_for("view_publication", pid=pid))
    return render_template("publication.html", p=p, upload_page=publishers.UPLOAD_PAGES.get(p["platform"]),
                           video_exists=bool(p["video_path"]) and Path(p["video_path"]).is_file(),
                           thumb_exists=bool(p["thumbnail_path"]) and Path(p["thumbnail_path"]).is_file(),
                           publisher=publishers.get(p["platform"]).name)


@app.route("/publications/<int:pid>/<action>", methods=["POST"])
def publication_action(pid, action):
    p = get_pub(pid)
    if not p:
        return redirect(url_for("publications"))
    if action == "run":
        with db() as con:
            con.execute("UPDATE publications SET status='Agendada', next_try_at='' WHERE id=? AND status IN ('Erro','Agendada','Aguardando você')", (pid,))
        scheduler.execute(pid)
        flash("Publicação processada. Veja o resultado abaixo.", "success")
    elif action == "cancel":
        with db() as con:
            con.execute("UPDATE publications SET status='Cancelada', updated_at=? WHERE id=?", (now_iso(), pid))
        log(f"Publicação #{pid} cancelada")
        flash("Publicação cancelada.", "success")
    elif action == "reschedule":
        slot = scheduler.next_free_slot(p["platform"])
        with db() as con:
            con.execute("""UPDATE publications SET status='Agendada', scheduled_at=?, attempts=0, next_try_at='',
                           message='', updated_at=? WHERE id=?""", (slot, now_iso(), pid))
        log(f"Publicação #{pid} reagendada para {iso_to_br(slot)}")
        flash(f"Reagendada para {iso_to_br(slot)}.", "success")
    elif action == "done":
        url = request.form.get("result_url", "").strip()
        with db() as con:
            con.execute("""UPDATE publications SET status='Publicada', result_url=?, published_at=?,
                           message='Confirmada manualmente', updated_at=? WHERE id=?""",
                        (url if valid_url(url) else "", now_iso(), now_iso(), pid))
            if p["campaign_id"]:
                con.execute("UPDATE campaigns SET status='Publicada', updated_at=? WHERE id=?", (now(), p["campaign_id"]))
        log(f"Publicação #{pid} ({p['platform']}) marcada como publicada")
        flash("Marcada como publicada.", "success")
    elif action == "delete":
        with db() as con:
            con.execute("DELETE FROM publications WHERE id=?", (pid,))
        log(f"Publicação #{pid} excluída")
        flash("Publicação excluída.", "success")
        return redirect(url_for("publications"))
    elif action == "openfolder":
        folder = Path(p["video_path"]).parent if p["video_path"] else EXPORTS
        if sys.platform.startswith("win") and folder.is_dir():
            os.startfile(folder)
        else:
            flash(f"Pasta: {folder}", "success")
    return redirect(url_for("view_publication", pid=pid))


# ---------- contas (YouTube) ----------
def update_youtube_stats():
    """Atualiza visualizacoes/curtidas das publicacoes do YouTube com link. Chamado a cada 6 h."""
    if not youtube or not youtube.is_connected():
        return 0
    with db() as con:
        rows = con.execute("""SELECT id, result_url FROM publications WHERE platform='YouTube'
                              AND status='Publicada' AND result_url!=''""").fetchall()
    ids = {r["id"]: youtube.video_id_from_url(r["result_url"]) for r in rows}
    stats = youtube.fetch_stats(list(set(v for v in ids.values() if v)))
    with db() as con:
        for pid, vid in ids.items():
            if vid in stats:
                st = stats[vid]
                con.execute("UPDATE publications SET views=?, likes=?, comments=?, stats_at=? WHERE id=?",
                            (st["views"], st["likes"], st["comments"], now_iso(), pid))
    try:
        youtube.channel_info(force=True)
    except Exception:
        pass
    return len(stats)


scheduler.stats_hooks.append(update_youtube_stats)


@app.route("/accounts", methods=["GET", "POST"])
def accounts():
    section = request.form.get("section") if request.method == "POST" else ""
    if section == "lemmy":
        f = request.form
        if f.get("password"):
            try:
                name = lemmy.login(f.get("instance", ""), f.get("user", ""), f.get("password"))
                flash(f"Lemmy conectado como {name}.", "success")
            except lemmy.LemmyError as e:
                flash(f"Não foi possível entrar no Lemmy: {e}", "error")
        gap = f.get("LEMMY_GAP_MIN", "45")
        save_env({"LEMMY_AUTO": "on" if f.get("LEMMY_AUTO") else "off",
                  "LEMMY_GAP_MIN": gap if gap.isdigit() else "45"})
        if not f.get("password"):
            flash("Preferências do Lemmy salvas.", "success")
        return redirect(url_for("accounts") + "#lemmy")
    if section == "lemmy_off":
        lemmy.disconnect()
        flash("Lemmy desconectado.", "success")
        return redirect(url_for("accounts") + "#lemmy")
    if section == "bluesky":
        f = request.form
        handle, pw = f.get("handle", "").strip().lstrip("@"), f.get("app_password", "").strip()
        if handle and pw:
            try:
                social.bsky_session(handle, pw)
                first = not social.bluesky_on()
                save_env({"BSKY_HANDLE": handle, "BSKY_APP_PASSWORD": pw})
                if first:
                    social.mark_existing("bluesky")
                flash(f"Bluesky conectado como @{handle}.", "success")
            except social.SocialError as e:
                flash(str(e), "error")
        save_env({"BSKY_AUTO": "on" if f.get("BSKY_AUTO") else "off"})
        return redirect(url_for("accounts") + "#bluesky")
    if section == "bluesky_off":
        save_env({"BSKY_HANDLE": "", "BSKY_APP_PASSWORD": ""})
        flash("Bluesky desconectado. Apague também a senha de app no Bluesky, em Configurações → Senhas de app.", "success")
        return redirect(url_for("accounts") + "#bluesky")
    if section == "mastodon":
        f = request.form
        inst, token = f.get("instance", "").strip(), f.get("token", "").strip()
        if inst and token:
            try:
                acct, inst = social.mastodon_verify(inst, token)
                first = not social.mastodon_on()
                save_env({"MASTO_INSTANCE": inst, "MASTO_TOKEN": token, "MASTO_ACCT": acct})
                if first:
                    social.mark_existing("mastodon")
                flash(f"Mastodon conectado como @{acct}.", "success")
            except social.SocialError as e:
                flash(str(e), "error")
        save_env({"MASTO_AUTO": "on" if f.get("MASTO_AUTO") else "off"})
        return redirect(url_for("accounts") + "#mastodon")
    if section == "mastodon_off":
        save_env({"MASTO_INSTANCE": "", "MASTO_TOKEN": "", "MASTO_ACCT": ""})
        flash("Mastodon desconectado.", "success")
        return redirect(url_for("accounts") + "#mastodon")
    if section == "phone":
        save_env({"TG_APPROVE": "on" if request.form.get("TG_APPROVE") else "off"})
        if request.form.get("unlink"):
            tgbot.unlink()
            flash("Celular desvinculado.", "success")
        else:
            flash("Preferências do celular salvas.", "success")
        return redirect(url_for("accounts") + "#celular")
    if section == "telegram":
        f = request.form
        token, chat = f.get("TG_BOT_TOKEN", "").strip(), f.get("TG_CHAT_ID", "").strip()
        updates = {"TG_AUTO": "on" if f.get("TG_AUTO") else "off"}
        if token:
            updates["TG_BOT_TOKEN"] = token
        if chat:
            updates["TG_CHAT_ID"] = chat if chat.startswith("@") or chat.lstrip("-").isdigit() else "@" + chat
        first_time = not telegram.is_configured()
        save_env(updates)
        if telegram.is_configured():
            if first_time:
                social.mark_existing("telegram")
            try:
                if f.get("test"):
                    telegram.send("✅ AutoDivulga conectado. Os próximos vídeos publicados vão aparecer aqui.")
                    flash("Mensagem de teste enviada ao Telegram.", "success")
                else:
                    flash("Telegram salvo.", "success")
            except telegram.TelegramError as e:
                flash(f"Telegram: {e}", "error")
        elif setting("TG_BOT_TOKEN"):
            flash("Bot salvo. Agora vincule o celular logo abaixo (o canal é opcional).", "success")
            return redirect(url_for("accounts") + "#celular")
        return redirect(url_for("accounts") + "#telegram")
    if request.method == "POST" and request.form.get("section") == "tiktok":
        f = request.form
        updates = {"TT_UPLOAD": "on" if f.get("TT_UPLOAD") else "off"}
        if f.get("TIKTOK_CLIENT_KEY", "").strip():
            updates["TIKTOK_CLIENT_KEY"] = f.get("TIKTOK_CLIENT_KEY").strip()
        if f.get("TIKTOK_CLIENT_SECRET", "").strip():
            updates["TIKTOK_CLIENT_SECRET"] = f.get("TIKTOK_CLIENT_SECRET").strip()
        save_env(updates)
        log("Configurações do TikTok atualizadas")
        flash("Configurações do TikTok salvas.", "success")
        return redirect(url_for("accounts") + "#tiktok")
    if request.method == "POST":
        f = request.form
        save_env({"YT_CATEGORY": f.get("YT_CATEGORY") if youtube and f.get("YT_CATEGORY") in youtube.CATEGORIES else "22",
                  "YT_MADE_FOR_KIDS": "on" if f.get("YT_MADE_FOR_KIDS") else "off",
                  "YT_API_UPLOAD": "on" if f.get("YT_API_UPLOAD") else "off",
                  "YT_PRIVACY": f.get("YT_PRIVACY") if f.get("YT_PRIVACY") in ("private", "unlisted", "public") else "public"})
        log("Configurações do YouTube atualizadas")
        flash("Configurações do YouTube salvas.", "success")
        return redirect(url_for("accounts"))
    yt = {"lib_error": YT_ERROR, "file_ok": False, "file_msg": "", "connected": False, "channel": None, "error": ""}
    if youtube:
        yt["file_ok"], yt["file_msg"] = youtube.client_file_status()
        yt["connected"] = youtube.is_connected()
        if yt["connected"]:
            try:
                yt["channel"] = youtube.channel_info()
            except Exception as e:
                yt["error"] = str(e)
                yt["connected"] = youtube.is_connected()
    with db() as con:
        totals = con.execute("""SELECT COUNT(*) n, COALESCE(SUM(views),0) v, COALESCE(SUM(likes),0) l
                                FROM publications WHERE platform='YouTube' AND status='Publicada'""").fetchone()
    tt = {"lib_error": TT_ERROR, "has_creds": False, "connected": False, "user": None, "error": "",
          "key_hint": "", "redirect": tiktok.REDIRECT_URI if tiktok else ""}
    if tiktok:
        tt["has_creds"] = tiktok.has_credentials()
        tt["key_hint"] = (tiktok.client_key()[:4] + "…") if tiktok.client_key() else ""
        tt["connected"] = tiktok.is_connected()
        if tt["connected"]:
            try:
                tt["user"] = tiktok.user_info()
            except Exception as e:
                tt["error"] = str(e)
                tt["connected"] = tiktok.is_connected()
    return render_template("accounts.html", yt=yt, tt=tt, tt_upload=setting("TT_UPLOAD") != "off", categories=youtube.CATEGORIES if youtube else {},
                           cfg={k: setting(k) for k in ("YT_CATEGORY", "YT_MADE_FOR_KIDS", "YT_API_UPLOAD", "YT_AUDITED", "YT_PRIVACY")},
                           totals=totals, lemmy_on=lemmy.is_connected(), lemmy_user=setting("LEMMY_USER"),
                           lemmy_inst=lemmy.instance(), lemmy_auto=setting("LEMMY_AUTO") != "off",
                           lemmy_gap=lemmy.gap_minutes(), tg_on=telegram.is_configured(),
                           tg_chat=setting("TG_CHAT_ID"), tg_auto=setting("TG_AUTO") != "off",
                           has_bot=bool(setting("TG_BOT_TOKEN")), bsky_on=social.bluesky_on(),
                           bsky_handle=setting("BSKY_HANDLE"), bsky_auto=setting("BSKY_AUTO") != "off",
                           masto_on=social.mastodon_on(), masto_acct=setting("MASTO_ACCT"),
                           masto_inst=setting("MASTO_INSTANCE"), masto_auto=setting("MASTO_AUTO") != "off",
                           phone_linked=tgbot.is_linked(), phone_on=setting("TG_APPROVE") != "off",
                           pair_code=tgbot.pairing_code() if setting("TG_BOT_TOKEN") and not tgbot.is_linked() else "",
                           bot_name=tgbot.bot_username() if setting("TG_BOT_TOKEN") and not tgbot.is_linked() else "")


@app.route("/accounts/youtube/connect", methods=["POST"])
def youtube_connect():
    if not youtube:
        flash(YT_ERROR, "error")
        return redirect(url_for("accounts"))
    try:
        return redirect(youtube.start_login())
    except Exception as e:
        flash(str(e), "error")
        return redirect(url_for("accounts"))


def youtube_callback():
    if request.args.get("error"):
        flash("Login cancelado no Google." if request.args.get("error") == "access_denied"
              else f"O Google recusou o login: {request.args.get('error')}", "error")
        return redirect(url_for("accounts"))
    try:
        info = youtube.finish_login(request.args["state"], request.url)
        flash(f"Canal conectado: {info.get('title')}.", "success")
        import accounts_store
        accounts_store.stash("youtube")
        if setting("YT_REPLY") == "on":
            if youtube.can_reply():
                flash("Comentários ativados: agora dá para ler e responder pelo painel.", "success")
                comments.refresh_async()
            else:
                save_env({"YT_REPLY": "off"})
                flash("A permissão de gerenciar comentários não foi concedida. O resto continua funcionando.", "error")
            return redirect(url_for("comments_page"))
    except Exception as e:
        msg = str(e)
        if "access_denied" in msg or "403" in msg:
            msg += " Confira se o seu e-mail está em Usuários de teste no Google Cloud."
        flash(f"Não foi possível conectar: {msg}", "error")
    return redirect(url_for("accounts"))


@app.route("/accounts/youtube/disconnect", methods=["POST"])
def youtube_disconnect():
    if youtube:
        youtube.disconnect()
        log("Canal do YouTube desconectado")
        flash("Canal desconectado.", "success")
    return redirect(url_for("accounts"))


@app.route("/accounts/youtube/stats", methods=["POST"])
def youtube_stats():
    try:
        n = update_youtube_stats()
        flash(f"Estatísticas atualizadas ({n} vídeo(s)).", "success")
    except Exception as e:
        flash(f"Não foi possível atualizar: {e}", "error")
    return redirect(request.referrer or url_for("accounts"))


# ---------- arquivos (arrastar ou procurar) ----------
@app.route("/files/upload", methods=["POST"])
def files_upload():
    f = request.files.get("file")
    kind = request.args.get("kind", "video")
    allowed = IMAGE_EXT if kind == "image" else VIDEO_EXT
    if not f or not f.filename:
        return jsonify({"ok": False, "error": "Nenhum arquivo recebido."}), 400
    out = unique_media_name(f.filename, allowed)
    if not out:
        return jsonify({"ok": False, "error": "Formato não aceito. Use: " + ", ".join(sorted(allowed))}), 400
    f.save(out)
    log(f"Arquivo adicionado ao painel: {out.name}")
    return jsonify({"ok": True, "path": str(out), "name": out.name,
                    "size": f"{out.stat().st_size / 1_048_576:.1f} MB"})


BROWSE_SCRIPT = r"""
import sys, tkinter as tk
from tkinter import filedialog
root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True); root.update()
kind = sys.argv[1]
types = [('Imagens', '*.jpg *.jpeg *.png *.webp')] if kind == 'image' else \
        [('Vídeos', '*.mp4 *.mov *.mkv *.avi *.webm *.m4v *.wmv')]
path = filedialog.askopenfilename(parent=root, title='Escolha o arquivo', filetypes=types + [('Todos', '*.*')])
sys.stdout.write(path or '')
"""


@app.route("/files/browse", methods=["POST"])
def files_browse():
    """Abre a janela 'Abrir arquivo' do Windows e devolve o caminho completo (nada e copiado)."""
    kind = "image" if request.args.get("kind") == "image" else "video"
    try:
        cmd = [sys.executable, "--browse", kind] if FROZEN else [sys.executable, "-c", BROWSE_SCRIPT, kind]
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=900)
    except Exception as e:
        return jsonify({"ok": False, "error": f"Não foi possível abrir a janela de arquivos: {e}"}), 500
    if r.returncode != 0:
        return jsonify({"ok": False, "error": "Janela de arquivos indisponível. Use arrastar e soltar."}), 500
    path = r.stdout.strip()
    if not path:
        return jsonify({"ok": False, "cancelled": True})
    return jsonify({"ok": True, "path": str(Path(path)), "name": Path(path).name})


@app.route("/files/check")
def files_check():
    fixed = clean_path(request.args.get("path"))
    return jsonify({"exists": bool(fixed) and Path(fixed).is_file(), "path": fixed})


# ---------- contas (TikTok) ----------
@app.route("/accounts/tiktok/connect", methods=["POST"])
def tiktok_connect():
    if not tiktok:
        flash(TT_ERROR, "error")
        return redirect(url_for("accounts"))
    try:
        return redirect(tiktok.start_login())
    except Exception as e:
        flash(str(e), "error")
        return redirect(url_for("accounts") + "#tiktok")


@app.route("/tiktok/callback/")
def tiktok_callback():
    if request.args.get("error") and setting("TT_STATS") == "on" and not tiktok.has_stats():
        save_env({"TT_STATS": "off"})   # o app do TikTok ainda nao tem as permissoes de numeros
        flash("O TikTok recusou as permissões de números (video.list e user.info.stats). Libere essas permissões "
              "no seu app do TikTok for Developers e tente de novo. A conexão de envio continua funcionando.", "error")
        return redirect(url_for("performance", net="tt"))
    if request.args.get("error"):
        flash("Login no TikTok cancelado." if request.args.get("error") == "access_denied"
              else f"O TikTok recusou o login: {request.args.get('error_description') or request.args.get('error')}", "error")
        return redirect(url_for("accounts") + "#tiktok")
    try:
        info = tiktok.finish_login(request.args.get("state", ""), request.args.get("code", ""))
        import accounts_store
        accounts_store.stash("tiktok")
        flash(f"TikTok conectado: {info.get('display_name')}." + (" " + info["warning"] if info.get("warning") else ""),
              "error" if info.get("warning") else "success")
        if setting("TT_STATS") == "on":
            if tiktok.has_stats():
                insights.refresh_tiktok(force=True)
                return redirect(url_for("performance", net="tt"))
            save_env({"TT_STATS": "off"})
    except Exception as e:
        flash(f"Não foi possível conectar o TikTok: {e}. Confira se a sua conta está em Sandbox → Target users "
              "e se o Redirect URI está igual ao mostrado em Contas.", "error")
    return redirect(url_for("accounts") + "#tiktok")


@app.route("/accounts/tiktok/disconnect", methods=["POST"])
def tiktok_disconnect():
    if tiktok:
        tiktok.disconnect()
        log("Conta do TikTok desconectada")
        flash("TikTok desconectado.", "success")
    return redirect(url_for("accounts") + "#tiktok")


# ---------- cortes ----------
def parse_time(value):
    """Aceita segundos (90, 12.5) ou mm:ss / hh:mm:ss."""
    value = (value or "0").strip().replace(",", ".")
    parts = value.split(":")
    if len(parts) > 3:
        raise ValueError
    total = 0.0
    for p in parts:
        total = total * 60 + float(p)
    if total < 0:
        raise ValueError
    return total


def safe_output_name(name):
    stem = re.sub(r"[^\w\- ]", "_", Path(name or "corte_vertical").stem).strip() or "corte_vertical"
    out = EXPORTS / f"{stem}.mp4"
    n = 2
    while out.exists():
        out = EXPORTS / f"{stem}_{n}.mp4"; n += 1
    return out


@app.route("/clip", methods=["GET", "POST"])
def clip():
    result, error_detail = None, None
    form = request.form if request.method == "POST" else {}
    if request.method == "POST":
        source = clean_path(form.get("source"))
        mode = form.get("mode", "crop")
        if not shutil.which("ffmpeg"):
            flash("FFmpeg não encontrado. Instale-o e reinicie o AutoDivulga AI.", "error")
        elif not Path(source).is_file():
            flash("Arquivo de vídeo não encontrado. Use o caminho completo de um arquivo local.", "error")
        else:
            try:
                start = parse_time(form.get("start"))
                dur = parse_time(form.get("duration") or "30")
                if dur <= 0 or dur > 180:
                    raise ValueError
            except ValueError:
                flash("Início ou duração inválidos. Use segundos (ex.: 90) ou mm:ss (ex.: 1:30). Duração máxima: 180 s.", "error")
            else:
                EXPORTS.mkdir(exist_ok=True)
                outpath = safe_output_name(form.get("output"))
                if mode == "blur":
                    vf = ("split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,"
                          "boxblur=20:2[bg];[b]scale=1080:1920:force_original_aspect_ratio=decrease[fg];"
                          "[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1")
                    vargs = ["-filter_complex", vf]
                else:
                    vargs = ["-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1"]
                cmd = ["ffmpeg", "-y", "-ss", str(start), "-i", source, "-t", str(dur), *vargs,
                       "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p",
                       "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(outpath)]
                try:
                    subprocess.run(cmd, check=True, capture_output=True, text=True,
                                   encoding="utf-8", errors="replace", timeout=900)
                    result = str(outpath)
                    log(f"Corte de vídeo exportado: {outpath.name}")
                    flash("Corte gerado com sucesso!", "success")
                except subprocess.CalledProcessError as e:
                    error_detail = "\n".join((e.stderr or "").strip().splitlines()[-8:])
                    flash("O FFmpeg não conseguiu gerar o corte. Veja os detalhes abaixo.", "error")
                except subprocess.TimeoutExpired:
                    flash("O corte demorou demais e foi cancelado.", "error")
    exports = sorted(EXPORTS.glob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True)[:10] if EXPORTS.exists() else []
    import autocut
    return render_template("clip.html", result=result, error_detail=error_detail, form=form, auto=autocut.state,
                           exports=[(p.name, f"{p.stat().st_size / 1_048_576:.1f} MB") for p in exports])


@app.route("/clip/auto", methods=["POST"])
def clip_auto():
    import autocut
    f = request.form
    source = clean_path(f.get("source"))
    if not autocut.ffmpeg_ok():
        flash("FFmpeg não encontrado. Instale-o (veja o aviso nesta página) e reinicie o AutoDivulga AI.", "error")
    elif not Path(source).is_file():
        flash("Arquivo de vídeo não encontrado. Use o caminho completo de um arquivo do computador.", "error")
    else:
        try:
            length = int(f.get("length", "30"))
            count = int(f.get("count", "3"))
        except ValueError:
            length, count = 30, 3
        prefix = re.sub(r"[^\w-]+", "_", Path(source).stem)[:40] + "_corte"
        if autocut.start(source, max(5, min(length, 180)), max(1, min(count, 6)), bool(f.get("make_all")),
                         "blur" if f.get("mode") == "blur" else "crop", f.get("title", "")[:90], prefix):
            flash("Analisando o vídeo. Vídeos longos levam alguns minutos; a página atualiza sozinha.", "success")
        else:
            flash("Já há uma análise em andamento. Espere terminar.", "error")
    return redirect(url_for("clip") + "#auto")


@app.route("/clip/auto/make/<int:i>", methods=["POST"])
def clip_auto_make(i):
    import autocut
    if not autocut.make_one_async(i):
        flash("Espere a tarefa atual terminar.", "error")
    return redirect(url_for("clip") + "#auto")


@app.route("/clip/auto/status")
def clip_auto_status():
    import autocut
    s = autocut.state
    return jsonify(running=s["running"], step=s["step"], error=s["error"], made=len(s["made"]))


@app.route("/exports/open", methods=["POST"])
def open_exports():
    EXPORTS.mkdir(exist_ok=True)
    if sys.platform.startswith("win"):
        os.startfile(EXPORTS)
    else:
        flash(f"Pasta de cortes: {EXPORTS}", "success")
    return redirect(url_for("clip"))


# ---------- configuracoes ----------
def launch_target():
    """O que abrir para iniciar o programa: o .exe na versao instalada, o INICIAR.bat na versao de pasta."""
    return Path(sys.executable) if FROZEN else BASE / "INICIAR.bat"


def startup_file():
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    return Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / "AutoDivulgaAI.cmd"


# ---------- etapa 4: locais de divulgacao ----------
scheduler.stats_hooks.append(discovery.auto_hook)


def get_place(plid):
    with db() as con:
        pl = con.execute("SELECT * FROM places WHERE id=?", (plid,)).fetchone()
    if not pl:
        flash("Local não encontrado.", "error")
    return pl


@app.route("/discover")
def discover_page():
    with db() as con:
        campaigns = con.execute("SELECT id, title, discovered_at FROM campaigns ORDER BY id DESC").fetchall()
    if not campaigns:
        return render_template("discover.html", campaigns=[], c=None)
    cid = request.args.get("campaign", type=int) or campaigns[0]["id"]
    c = get_campaign(cid) or get_campaign(campaigns[0]["id"])
    status = request.args.get("status") or "Sugerido"
    if status not in discovery.PLACE_STATUSES:
        status = "Sugerido"
    source = request.args.get("source", "")
    with db() as con:
        counts = {s: 0 for s in discovery.PLACE_STATUSES}
        for r in con.execute("SELECT status, COUNT(*) n FROM places WHERE campaign_id=? GROUP BY status", (c["id"],)):
            counts[r["status"]] = r["n"]
        q, args = "SELECT * FROM places WHERE campaign_id=? AND status=?", [c["id"], status]
        if source in discovery.SOURCES:
            q += " AND source=?"
            args.append(source)
        places = con.execute(q + " ORDER BY score DESC, members DESC LIMIT 100", args).fetchall()
    return render_template("discover.html", campaigns=campaigns, c=c, places=places, counts=counts,
                           cur_status=status, cur_source=source, sources=discovery.SOURCES,
                           running=discovery.running.get(c["id"]), last=discovery.last_result.get(c["id"]),
                           policy_label=discovery.POLICY_LABEL, fmt_members=discovery.fmt_members,
                           sources_on=discovery.enabled_sources(), shortcuts=discovery.search_shortcuts(c),
                           lemmy_auto=lemmy.auto_on(),
                           yt_ok=bool(youtube and youtube.is_connected()))


@app.route("/discover/<int:cid>/run", methods=["POST"])
def discover_run(cid):
    if not get_campaign(cid):
        return redirect(url_for("discover_page"))
    if discovery.start(cid):
        flash("Busca iniciada. Leva de 1 a 3 minutos; esta página se atualiza sozinha.", "success")
    else:
        flash("Já existe uma busca em andamento para esta campanha.", "error")
    return redirect(url_for("discover_page", campaign=cid))


@app.route("/discover/<int:cid>/status")
def discover_status(cid):
    return jsonify(running=discovery.running.get(cid), last=discovery.last_result.get(cid))


@app.route("/discover/<int:cid>/add", methods=["POST"])
def discover_add(cid):
    c = get_campaign(cid)
    url = request.form.get("url", "").strip()
    name = request.form.get("name", "").strip()
    if not c or not valid_url(url):
        flash("Informe um link válido (começando com https://).", "error")
        return redirect(url_for("discover_page", campaign=cid))
    t = now_iso()
    with db() as con:
        con.execute("""INSERT OR IGNORE INTO places(campaign_id, source, name, url, reasons, status, score, created_at, updated_at)
                       VALUES (?,?,?,?,?,'Aprovado',?,?,?)""",
                    (cid, "Manual", name or re.sub(r"^https?://(www\.)?", "", url)[:60], url,
                     "adicionado por você", 100, t, t))
    flash("Local adicionado aos aprovados.", "success")
    return redirect(url_for("discover_page", campaign=cid, status="Aprovado"))


def approve_place(plid):
    """Aprova um local (pelo painel ou pelo celular) e devolve a mensagem para mostrar."""
    pl = get_place(plid)
    if not pl:
        return "Local não encontrado."
    if pl["status"] != "Sugerido":
        return f"{pl['name']} já estava como {pl['status']}."
    fields = {"status": "Aprovado", "updated_at": now_iso()}
    if not pl["post_text"]:
        title, text, src = generate_place_post(get_campaign(pl["campaign_id"]), pl)
        fields.update(post_title=title, post_text=text)
    with db() as con:
        con.execute(f"UPDATE places SET {', '.join(k + '=?' for k in fields)} WHERE id=?", (*fields.values(), plid))
    if lemmy.can_auto(pl):
        slot = lemmy.schedule(plid)
        return (f"{pl['name']} aprovado. Post automático no Lemmy às {iso_to_br(slot)[-5:]} "
                "(dá para editar o texto até lá na aba Aprovados).")
    return f"{pl['name']} aprovado. O texto sugerido está na aba Aprovados."


def discard_place(plid):
    pl = get_place(plid)
    if not pl:
        return "Local não encontrado."
    with db() as con:
        con.execute("UPDATE places SET status='Descartado', auto_at='', updated_at=? WHERE id=?", (now_iso(), plid))
    return f"{pl['name']} descartado."


tgbot.handlers.update(approve=approve_place, discard=discard_place)


@app.route("/places/<int:plid>/<action>", methods=["POST"])
def place_action(plid, action):
    pl = get_place(plid)
    if not pl:
        return redirect(url_for("discover_page"))
    back = request.form.get("back") or url_for("discover_page", campaign=pl["campaign_id"], status=pl["status"])
    fields = {}
    if action == "approve":
        flash(approve_place(plid), "success")
        return redirect(back)
    elif action == "discard":
        fields.update(status="Descartado", auto_at="")
    elif action == "restore":
        fields.update(status="Sugerido", auto_at="")
    elif action == "autopost":
        try:
            url = lemmy.post_place(plid)
            flash("Post publicado no Lemmy.", "success")
        except lemmy.LemmyError as e:
            flash(f"Não foi possível postar: {e}", "error")
        return redirect(back)
    elif action == "autocancel":
        lemmy.unschedule(plid)
        flash("Post automático cancelado. Você pode postar manualmente ou reagendar.", "success")
        return redirect(back)
    elif action == "autoschedule":
        if lemmy.can_auto(pl):
            flash(f"Post automático agendado para {iso_to_br(lemmy.schedule(plid))[-5:]}.", "success")
        else:
            flash("Conecte o Lemmy em Contas para postar automaticamente.", "error")
        return redirect(back)
    elif action == "regenerate":
        title, text, src = generate_place_post(get_campaign(pl["campaign_id"]), pl)
        fields.update(post_title=title, post_text=text)
        flash(f"Novo texto gerado ({src}).", "success")
    elif action == "save":
        fields.update(post_title=request.form.get("post_title", "")[:300],
                      post_text=request.form.get("post_text", "")[:5000])
        flash("Texto salvo.", "success")
    elif action == "done":
        link = request.form.get("posted_url", "").strip()
        fields.update(status="Divulgado", posted_url=link if valid_url(link) else "")
        log(f"Divulgado em {pl['name']} ({pl['source']})")
        flash("Marcado como divulgado.", "success")
    elif action == "delete":
        with db() as con:
            con.execute("DELETE FROM places WHERE id=?", (plid,))
        return redirect(back)
    else:
        return redirect(back)
    fields["updated_at"] = now_iso()
    with db() as con:
        con.execute(f"UPDATE places SET {', '.join(k + '=?' for k in fields)} WHERE id=?", (*fields.values(), plid))
    return redirect(back)


@app.route("/discover/<int:cid>/bulk", methods=["POST"])
def discover_bulk(cid):
    ids = [int(i) for i in request.form.getlist("ids") if i.isdigit()]
    action = request.form.get("action")
    if ids and action == "discard":
        with db() as con:
            con.executemany("UPDATE places SET status='Descartado', updated_at=? WHERE id=? AND campaign_id=?",
                            [(now_iso(), i, cid) for i in ids])
        flash(f"{len(ids)} local(is) descartado(s).", "success")
    elif action == "clear":
        with db() as con:
            n = con.execute("DELETE FROM places WHERE campaign_id=? AND status='Sugerido'", (cid,)).rowcount
        flash(f"{n} sugestão(ões) apagada(s). Busque de novo para recomeçar.", "success")
    return redirect(url_for("discover_page", campaign=cid))


# ---------- etapa 5: pop-ups em sites parceiros ----------
scheduler.stats_hooks.append(partners.auto_hook)
popup_state = {"busy": False, "step": "", "error": "", "ok": ""}


def sync_in_background(wait=False):
    import threading
    def job():
        popup_state.update(busy=True, error="", ok="")
        try:
            popup_state["step"] = "enviando parceiros e vídeos…"
            partners.sync()
            popup_state["ok"] = "Pop-ups atualizados na Cloudflare."
        except Exception as e:
            popup_state["error"] = str(e)
        finally:
            popup_state.update(busy=False, step="")
    if partners.is_deployed() and not popup_state["busy"]:
        threading.Thread(target=job, daemon=True).start()


@app.route("/partners")
def partners_page():
    per, total, stats_error = {}, None, ""
    if partners.is_deployed():
        try:
            per, total = partners.stats(30)
        except Exception as e:
            stats_error = str(e)
    with db() as con:
        campaigns = con.execute("SELECT id, title, video_url FROM campaigns ORDER BY id DESC").fetchall()
    cfg = partners.build_config()
    latest = cfg["promos"].get(cfg["latest"], {})
    return render_template("partners.html", deployed=partners.is_deployed(), has_token=partners.has_token(),
                           url=partners.worker_url(), plist=partners.list_partners(), campaigns=campaigns,
                           per=per, total=total, stats_error=stats_error, state=popup_state,
                           embed=partners.embed_code, latest=latest, positions=partners.POSITIONS,
                           delay=setting("POPUP_DELAY") or "8", cap=setting("POPUP_CAP_HOURS") or "24",
                           position=setting("POPUP_POSITION") or "right", synced=setting("POPUP_SYNCED_AT"),
                           no_url=[c for c in campaigns if not (c["video_url"] or "").startswith("http")])


@app.route("/partners/status")
def partners_status():
    return jsonify(popup_state)


@app.route("/partners/deploy", methods=["POST"])
def partners_deploy():
    token = request.form.get("token", "").strip()
    try:
        url = partners.deploy(token or None)
        flash(f"Script publicado em {url}. Na primeira vez, o endereço pode levar alguns minutos para responder.", "success")
        sync_in_background(wait=True)
    except partners.CloudflareError as e:
        flash(f"Não foi possível publicar: {e}", "error")
    return redirect(url_for("partners_page"))


@app.route("/partners/settings", methods=["POST"])
def partners_settings():
    f = request.form
    delay, cap = f.get("POPUP_DELAY", "8"), f.get("POPUP_CAP_HOURS", "24")
    save_env({"POPUP_DELAY": delay if delay.isdigit() else "8",
              "POPUP_CAP_HOURS": cap if cap.isdigit() and int(cap) > 0 else "24",
              "POPUP_POSITION": f.get("POPUP_POSITION") if f.get("POPUP_POSITION") in partners.POSITIONS else "right"})
    sync_in_background()
    flash("Preferências salvas e enviadas para os pop-ups.", "success")
    return redirect(url_for("partners_page"))


@app.route("/partners/add", methods=["POST"])
def partners_add():
    name = request.form.get("name", "").strip()[:80]
    site = request.form.get("site", "").strip()[:200]
    if not name:
        flash("Dê um nome ao parceiro (ex.: o nome do site).", "error")
    else:
        partners.add_partner(name, site if valid_url(site) else "")
        sync_in_background()
        flash(f"{name} adicionado. Copie o código e envie para o dono do site.", "success")
    return redirect(url_for("partners_page"))


@app.route("/partners/<pid>/<action>", methods=["POST"])
def partners_action(pid, action):
    if action == "update":
        cid = request.form.get("campaign_id", "0")
        partners.update_partner(pid, campaign_id=int(cid) if cid.isdigit() else 0,
                                active=1 if request.form.get("active") else 0)
        flash("Parceiro atualizado.", "success")
    elif action == "delete":
        partners.delete_partner(pid)
        flash("Parceiro removido. O código no site dele para de mostrar o pop-up.", "success")
    sync_in_background()
    return redirect(url_for("partners_page"))


@app.route("/partners/sync", methods=["POST"])
def partners_sync():
    try:
        partners.sync()
        flash("Pop-ups atualizados na Cloudflare.", "success")
    except partners.CloudflareError as e:
        flash(f"Não foi possível sincronizar: {e}", "error")
    return redirect(url_for("partners_page"))


@app.route("/settings", methods=["GET", "POST"])
def settings():
    if request.method == "POST":
        f = request.form
        section = f.get("section", "ai")
        if section == "auto":
            times = []
            for t in re.split(r"[,\s;]+", f.get("POST_TIMES", "")):
                try:
                    times.append(datetime.strptime(t, "%H:%M").strftime("%H:%M"))
                except ValueError:
                    pass
            max_day = f.get("MAX_PER_DAY", "2")
            save_env({"AUTOPILOT": "on" if f.get("AUTOPILOT") else "off",
                      "SMART_TIMES": "on" if f.get("SMART_TIMES") else "off",
                      "POST_TIMES": ",".join(sorted(set(times))) or "18:00",
                      "MAX_PER_DAY": max_day if max_day.isdigit() and int(max_day) > 0 else "2"})
            log("Configurações de automação atualizadas")
        elif section == "discovery":
            chosen = [src for src in discovery.SOURCES if f.get("src_" + src)]
            save_env({"DISCOVERY_AUTO": "on" if f.get("DISCOVERY_AUTO") else "off",
                      "DISCOVERY_SOURCES": ",".join(chosen) or "Reddit"})
            log("Configurações de divulgação atualizadas")
        elif section == "startup":
            sf = startup_file()
            if not sf:
                flash("O início automático só funciona no Windows.", "error")
                return redirect(url_for("settings"))
            if f.get("enable"):
                sf.write_text('@echo off\r\nset "AUTODIVULGA_SILENT=1"\r\n'
                              f'start "AutoDivulga AI" /min "{launch_target()}"\r\n', encoding="utf-8")
                log("Início automático com o Windows ativado")
            elif sf.exists():
                sf.unlink()
                log("Início automático com o Windows desativado")
        else:
            updates = {
                "AI_MODE": f.get("AI_MODE") if f.get("AI_MODE") in ("hybrid", "ollama", "api", "offline") else "hybrid",
                "OLLAMA_MODEL": f.get("OLLAMA_MODEL", "").strip() or "llama3.2",
                "OPENAI_MODEL": f.get("OPENAI_MODEL", "").strip(),
                "OPENAI_BASE_URL": f.get("OPENAI_BASE_URL", "").strip(),
            }
            key = f.get("OPENAI_API_KEY", "").strip()
            if f.get("clear_key"):
                updates["OPENAI_API_KEY"] = ""
            elif key:
                updates["OPENAI_API_KEY"] = key
            save_env(updates)
            log("Configurações de IA atualizadas")
        flash("Configurações salvas.", "success")
        return redirect(url_for("settings"))
    if request.args.get("test"):
        caption, tags, source = generate_campaign_copy("Teste do AutoDivulga", "animação, histórias dark",
                                                       "fãs de animação", "TikTok")
        st = ai_writer.last_status
        if source == "Offline":
            flash(f"A IA não respondeu ({st['error'] or 'sem detalhes'}). Usado o texto offline: {caption}", "error")
        else:
            flash(f"IA funcionando via {source} em {st['seconds']} s: {caption} {tags}", "success")
        _ai_cache["t"] = 0
        return redirect(url_for("settings") + "#ai")
    online, models = ollama_status()
    if not online:
        import threading
        threading.Thread(target=ai_writer.ensure_ollama, daemon=True).start()
    cfg = {k: os.getenv(k, "") for k in SETTING_KEYS}
    has_key = bool(cfg.pop("OPENAI_API_KEY"))
    sf = startup_file()
    return render_template("settings.html", cfg=cfg, has_key=has_key, ollama_online=online, models=models,
                           post_times=setting("POST_TIMES").replace(",", ", "), max_per_day=setting("MAX_PER_DAY"),
                           smart_on=setting("SMART_TIMES") != "off", learned=__import__("besttime").summary(),
                           startup_on=bool(sf and sf.exists()), startup_possible=bool(sf),
                           config_report_on=report.enabled(), report_last=report.state["last"],
                           backups_full=maintenance.list_backups(), upd=maintenance.update_state,
                           has_update=maintenance.has_update(), is_frozen=FROZEN, update_repo=maintenance.repo(),
                           report_error=report.state["error"], tg_linked=tgbot.is_linked(),
                           next_slot=iso_to_br(scheduler.next_free_slot("YouTube")),
                           discovery_auto=setting("DISCOVERY_AUTO") == "on", sources=discovery.SOURCES,
                           sources_on=discovery.enabled_sources(),
                           recommended=ai_writer.RECOMMENDED, ollama_installed=bool(ai_writer.ollama_exe()) or online,
                           ps=ai_writer.ollama_ps(), ai_last=ai_writer.last_status, pull=ai_writer.pull_state)


@app.route("/ai/pull", methods=["POST"])
def ai_pull():
    import threading
    model = request.form.get("model", "").strip()
    if not re.match(r"^[\w.\-/]+(:[\w.\-]+)?$", model):
        flash("Nome de modelo inválido.", "error")
    elif not ai_writer.pull_state["done"]:
        flash("Já existe um download em andamento.", "error")
    elif not ollama_status()[0] and not ai_writer.ensure_ollama():
        flash("O Ollama não está aberto. Instale em ollama.com e tente de novo.", "error")
    else:
        threading.Thread(target=ai_writer.pull_model, args=(model,), daemon=True).start()
        save_env({"OLLAMA_MODEL": model})
        log(f"Download do modelo de IA {model} iniciado")
        flash(f"Baixando {model}. Pode continuar usando o programa.", "success")
    return redirect(url_for("settings") + "#ai")


@app.route("/ai/status")
def ai_status():
    online, models = ollama_status()
    return jsonify(online=online, models=models, pull=ai_writer.pull_state, ps=ai_writer.ollama_ps(),
                   last=ai_writer.last_status)


@app.route("/health")
def health():
    online, _ = ollama_status()
    return jsonify({"status": "ok", "app": "AutoDivulga AI", "version": VERSION,
                    "ffmpeg": bool(shutil.which("ffmpeg")), "ollama": online,
                    "autopilot": setting("AUTOPILOT"), "scheduler_last_run": scheduler.last_run,
                    "python": sys.version.split()[0]})


# ---------- relatorio semanal ----------
@app.route("/report/<action>", methods=["POST"])
def report_action(action):
    if action == "send":
        if not tgbot.is_linked():
            flash("Vincule o celular em Contas → Aprovar pelo celular primeiro.", "error")
        elif report.send_async():
            flash("Montando o relatório e enviando no Telegram (pode levar até 3 minutos por causa das ideias).", "success")
    elif action in ("on", "off"):
        save_env({"REPORT_WEEKLY": action})
        flash("Relatório semanal " + ("ligado." if action == "on" else "desligado."), "success")
    return redirect(url_for("settings") + "#relatorio")


# ---------- reiniciar ----------
RESTART_PAGE = """<!doctype html><meta charset="utf-8"><title>Reiniciando · AutoDivulga AI</title>
<link rel="stylesheet" href="/static/style.css"><body style="display:grid;place-items:center;min-height:100vh">
<div class="errpage card"><div class="big">↻</div><h2>Reiniciando o AutoDivulga…</h2>
<p class="muted">A janela preta fecha e abre de novo. Esta página volta sozinha quando o painel estiver no ar.</p></div>
<script>setTimeout(function p(){fetch('/health',{cache:'no-store'}).then(r=>r.ok?location.href='/settings':setTimeout(p,1500)).catch(()=>setTimeout(p,1500))},4000)</script>"""


def find_console_cmd(pid, depth=4):
    """Sobe pelos processos pais ate achar o cmd.exe da janela preta (no meio pode haver o
    lancador do Python ou do venv). Nunca mexe em nada que nao seja cmd.exe."""
    for _ in range(depth):
        try:
            out = subprocess.run(["powershell", "-NoProfile", "-Command",
                                  f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={pid}';"
                                  "if($p){$p.Name+'|'+$p.ParentProcessId}"],
                                 capture_output=True, text=True, timeout=15).stdout.strip()
        except Exception:
            return None
        if "|" not in out:
            return None
        name, parent_pid = out.split("|", 1)
        if name.lower() == "cmd.exe":
            return pid
        pid = int(parent_pid or 0)
        if pid <= 4:
            return None
    return None


@app.route("/system/restart", methods=["POST"])
def system_restart():
    """Abre o INICIAR.bat de novo (com uma pequena espera) e encerra este processo e a janela antiga."""
    if not sys.platform.startswith("win"):
        flash("Disponível apenas no Windows.", "error")
        return redirect(url_for("settings"))
    import threading
    bat = launch_target()
    target = None if FROZEN else find_console_cmd(os.getppid())      # janela preta antiga (calculado antes de abrir a nova)
    flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    subprocess.Popen(f'cmd /c timeout /t 5 /nobreak >nul & start "" /min "{bat}"', shell=True,
                     cwd=str(BASE), creationflags=flags, close_fds=True,
                     env={**os.environ, "AUTODIVULGA_SILENT": "1"})
    log("Painel reiniciado pelo botão em Configurações")

    def bye():
        try:   # fecha a janela preta antiga (so o cmd.exe que abriu o painel, sem /T)
            if target:
                subprocess.run(["taskkill", "/PID", str(target), "/F"], capture_output=True, timeout=10)
        except Exception:
            pass
        os._exit(0)
    threading.Timer(1.5, bye).start()
    return RESTART_PAGE


# ---------- paginas de erro no visual do painel ----------
@app.errorhandler(404)
def page_not_found(e):
    return render_template("error.html", code=404, title="Página não encontrada",
                           message="Esse endereço não existe no painel. Use o menu ao lado."), 404


@app.errorhandler(500)
def server_error(e):
    return render_template("error.html", code=500, title="Algo deu errado",
                           message="O AutoDivulga encontrou um erro. Os detalhes ficam no arquivo iniciar.log; "
                                   "envie esse arquivo se precisar de ajuda."), 500


# ---------- Instagram e Facebook (Meta) ----------
app.jinja_env.globals.update(meta_summary=meta.summary, meta_has_creds=meta.has_credentials,
                             meta_app_hint=lambda: (meta.app_id()[:4] + "…") if meta.app_id() else "",
                             meta_config_hint=lambda: setting("META_CONFIG_ID") and (setting("META_CONFIG_ID") + " (digite - para apagar)"))


@app.context_processor
def meta_flags():
    return {"ig_upload_on": setting("IG_UPLOAD") != "off", "fb_upload_on": setting("FB_UPLOAD") != "off"}


@app.route("/accounts/meta/keys", methods=["POST"])
def meta_keys():
    upd = {}
    if request.form.get("META_CONFIG_ID", None) is not None and request.form.get("META_CONFIG_ID").strip() == "-":
        upd["META_CONFIG_ID"] = ""          # "-" apaga o ID da configuracao
    for k in ("META_APP_ID", "META_APP_SECRET", "META_CONFIG_ID"):
        v = request.form.get(k, "").strip()
        if v and v != "-":
            upd[k] = v
    if upd.get("META_APP_ID") and not upd["META_APP_ID"].isdigit():
        flash("O App ID da Meta tem só números. Confira em Meta for Developers → Configurações do app → Básico.", "error")
        return redirect(url_for("accounts") + "#meta")
    if upd:
        save_env(upd)
        flash("Chaves da Meta salvas.", "success")
    return redirect(url_for("accounts") + "#meta")


@app.route("/accounts/meta/connect", methods=["POST"])
def meta_connect():
    try:
        return redirect(meta.start_login())
    except Exception as e:
        flash(str(e), "error")
        return redirect(url_for("accounts") + "#meta")


@app.route("/accounts/meta/switch", methods=["POST"])
def meta_switch():
    return accounts_switch("meta", "add")


@app.route("/meta/callback/")
def meta_callback():
    if request.args.get("error"):
        flash("Login na Meta cancelado." if request.args.get("error_reason") == "user_denied"
              else f"A Meta recusou o login: {request.args.get('error_description') or request.args.get('error')}", "error")
        return redirect(url_for("accounts") + "#meta")
    try:
        data = meta.finish_login(request.args.get("state", ""), request.args.get("code", ""))
        import accounts_store
        accounts_store.stash("meta")
        msg = f"Meta conectada: {data['user_name']}."
        if data.get("page_id"):
            msg += f" Página: {data.get('page_name')}" + (f", Instagram @{data['ig_username']}." if data.get("ig_username") else ".")
        elif data.get("pages"):
            msg += " Escolha abaixo a Página que vai receber os Reels."
        flash(msg, "success")
    except Exception as e:
        flash(f"Não foi possível conectar a Meta: {e}", "error")
    return redirect(url_for("accounts") + "#meta")


@app.route("/accounts/meta/<action>", methods=["POST"])
def meta_action(action):
    try:
        if action == "page":
            meta.choose_page(request.form.get("page_id", ""))
            insights.clear("ig"); insights.clear("fb")
            flash("Página escolhida.", "success")
        elif action == "refresh":
            meta.refresh_pages()
            flash("Lista de Páginas atualizada.", "success")
        elif action == "settings":
            save_env({"IG_UPLOAD": "on" if request.form.get("IG_UPLOAD") else "off",
                      "FB_UPLOAD": "on" if request.form.get("FB_UPLOAD") else "off"})
            flash("Preferências salvas.", "success")
        elif action == "disconnect":
            meta.disconnect()
            insights.clear("ig"); insights.clear("fb")
            log("Instagram e Facebook desconectados")
            flash("Instagram e Facebook desconectados.", "success")
    except Exception as e:
        flash(str(e), "error")
    return redirect(url_for("accounts") + "#meta")


# ---------- guias, primeiros passos e pacote ----------
import guides, release


@app.route("/guide/<key>")
def guide_page(key):
    g = guides.GUIDES.get(key)
    if not g:
        return redirect(url_for("accounts"))
    return render_template("guide.html", g=g, key=key)


@app.route("/accounts/youtube/client-secret", methods=["POST"])
def youtube_client_secret():
    """Cada pessoa envia o client_secret.json do proprio projeto do Google Cloud."""
    import json as _json
    f = request.files.get("file")
    try:
        data = _json.loads(f.read().decode("utf-8")) if f else {}
    except Exception:
        data = {}
    if "installed" not in data:
        flash("Esse arquivo não é um client_secret.json do tipo “App para computador”. Veja o passo a passo.", "error")
        return redirect(url_for("accounts"))
    (BASE / "client_secret.json").write_text(_json.dumps(data), encoding="utf-8")
    log("Arquivo client_secret.json do Google atualizado pelo painel")
    flash("client_secret.json salvo. Agora clique em Conectar canal.", "success")
    return redirect(url_for("accounts"))


def onboarding():
    if setting("ONBOARDING_HIDE") == "on":
        return None
    with db() as con:
        has_campaign = con.execute("SELECT COUNT(*) FROM campaigns").fetchone()[0] > 0
    items = [("Conectar o YouTube", bool(youtube and youtube.is_connected()), "/accounts"),
             ("Conectar o TikTok", bool(tiktok and tiktok.is_connected()), "/accounts#tiktok"),
             ("Conectar Instagram e Facebook", meta.is_connected(), "/accounts#meta"),
             ("Ligar a IA local (Ollama)", not ai_offline(), "/settings#ai"),
             ("Definir os temas do seu canal", bool(setting("TREND_NICHES")), "/trends#nicho"),
             ("Criar a primeira campanha", has_campaign, "/campaign/new")]
    return None if all(done for _, done, _ in items) else items


@app.route("/ajuda")
def help_page():
    import ajuda
    with db() as con:
        has_campaign = con.execute("SELECT COUNT(*) FROM campaigns").fetchone()[0] > 0
    status = [("YouTube conectado", bool(youtube and youtube.is_connected()), "/accounts"),
              ("TikTok conectado", bool(tiktok and tiktok.is_connected()), "/accounts#tiktok"),
              ("Instagram ligado", bool(meta.ig_ready()), "/accounts#meta"),
              ("Página do Facebook escolhida", bool(meta.page_ready()), "/accounts#meta"),
              ("Telegram configurado", bool(setting("TG_BOT_TOKEN")), "/accounts#telegram"),
              ("IA local ligada (Ollama)", not ai_offline(), "/settings#ai"),
              ("Piloto automático ligado", setting("AUTOPILOT") == "on", "/settings#auto"),
              ("Primeira campanha criada", has_campaign, "/campaign/new")]
    return render_template("help.html", sections=ajuda.SECTIONS, status=status)


@app.route("/onboarding/hide", methods=["POST"])
def onboarding_hide():
    save_env({"ONBOARDING_HIDE": "on"})
    return redirect(url_for("index"))


@app.route("/system/package", methods=["POST"])
def system_package():
    try:
        out, n = release.build()
        log(f"Pacote para distribuir gerado: {out.name} ({n} arquivos, sem dados pessoais)")
        flash(f"Pacote gerado: {out.name} ({n} arquivos, sem senhas, contas ou banco). Está na pasta exports.", "success")
        if sys.platform.startswith("win"):
            try:
                os.startfile(out.parent)
            except Exception:
                pass
    except Exception as e:
        flash(f"Não foi possível gerar o pacote: {e}", "error")
    return redirect(url_for("settings") + "#pacote")


# ---------- varias contas ----------
import accounts_store
app.jinja_env.globals["accounts_listing"] = accounts_store.listing
SWITCH_NETS = {"youtube": ("yt",), "tiktok": ("tt",), "meta": ("ig", "fb")}


def _after_switch(platform):
    for net in SWITCH_NETS[platform]:
        insights.clear(net)
    if platform == "youtube":
        with db() as con:
            con.execute("DELETE FROM yt_comments")
        comments.state["at"] = 0.0
        (BASE / "youtube_channel.json").exists() or None


@app.route("/accounts/switch/<platform>/<action>", methods=["POST"])
@app.route("/accounts/switch/<platform>/<action>/<ident>", methods=["POST"])
def accounts_switch(platform, action, ident=""):
    anchor = {"youtube": "", "tiktok": "#tiktok", "meta": "#meta"}.get(platform)
    if anchor is None:
        return redirect(url_for("accounts"))
    try:
        if action == "add":
            accounts_store.detach(platform)
            _after_switch(platform)
            if platform == "youtube":
                return redirect(youtube.start_login(select_account=True))
            if platform == "tiktok":
                return redirect(tiktok.start_login(switch=True))
            return redirect(meta.start_login(switch=True))
        if action == "use":
            label = accounts_store.switch(platform, ident)
            _after_switch(platform)
            flash(f"Conta ativa agora: {label}. Os números desta rede serão carregados de novo.", "success")
        elif action == "forget":
            accounts_store.forget(platform, ident)
            flash("Conta removida da lista deste computador.", "success")
    except Exception as e:
        flash(str(e), "error")
    return redirect(url_for("accounts") + anchor)


# ---------- comentarios ----------
@app.route("/comments")
def comments_page():
    status = request.args.get("status", "novo")
    if status not in ("novo", "respondido", "ignorado", "todos"):
        status = "novo"
    net = request.args.get("net", "")
    connected = bool(youtube and youtube.is_connected())
    meta_ok = comments.meta_ready()
    if (connected and youtube.can_reply() or meta_ok) and not comments.state["at"] and not comments.state["running"]:
        comments.refresh_async()
    rows = comments.listing(status, net)
    groups = {}
    for r in rows:
        groups.setdefault((r["video_id"], r["video_title"]), []).append(r)
    return render_template("comments.html", groups=groups, status=status, counts=comments.counts(),
                           connected=connected, can_reply=bool(youtube and youtube.can_reply()),
                           st=comments.state, total=len(rows), net=net, meta_ok=meta_ok,
                           meta_connected=meta.is_connected(), net_names=comments.NET_NAMES)


@app.route("/comments/refresh", methods=["POST"])
def comments_refresh():
    comments.state["error"] = ""
    n = comments.refresh_all()
    flash(comments.state["error"] or f"Comentários atualizados ({n} conversa(s) lida(s)).",
          "error" if comments.state["error"] else "success")
    return redirect(url_for("comments_page", status=request.form.get("status", "novo")))


@app.route("/comments/status")
def comments_status():
    return jsonify(running=comments.state["running"], error=comments.state["error"])


@app.route("/comments/enable", methods=["POST"])
def comments_enable():
    if not youtube or not youtube.is_connected():
        flash("Conecte o YouTube em Contas primeiro.", "error")
        return redirect(url_for("accounts"))
    save_env({"YT_REPLY": "on"})
    try:
        return redirect(youtube.start_login())
    except Exception as e:
        save_env({"YT_REPLY": "off"})
        flash(str(e), "error")
        return redirect(url_for("comments_page"))


@app.route("/comments/<cid>/suggest", methods=["POST"])
def comments_suggest(cid):
    text = comments.suggest(cid)
    if not text:
        return jsonify(ok=False, error="A IA não respondeu. Confira se o Ollama está ligado."), 200
    return jsonify(ok=True, text=text)


@app.route("/comments/<cid>/<action>", methods=["POST"])
def comments_action(cid, action):
    back = (url_for("comments_page", status=request.form.get("status", "novo"), net=request.form.get("net", ""))
            + "#c-" + cid.replace(":", "-"))
    if action == "reply":
        try:
            comments.reply(cid, request.form.get("text", ""))
            flash(f"Resposta publicada no {comments.NET_NAMES.get(cid[:2] if ':' in cid else 'yt', 'YouTube')}.", "success")
        except Exception as e:
            msg = str(e)
            if "insufficientPermissions" in msg or "403" in msg:
                msg = "O YouTube recusou: falta a permissão de comentar. Clique em Ativar respostas."
            elif "quota" in msg.lower():
                msg = "Limite diário da API do YouTube atingido. Tente amanhã ou responda pelo YouTube."
            flash(f"Não foi possível responder: {msg}", "error")
    elif action in ("ignore", "unignore"):
        comments.set_status(cid, "ignorado" if action == "ignore" else "novo")
    return redirect(back)


# ---------- desempenho ----------
@app.route("/performance")
def performance():
    net = request.args.get("net") if request.args.get("net") in ("tt", "ig", "fb") else "yt"
    channel, tt_ready = {}, bool(tiktok and tiktok.has_stats())
    meta_ready = {"ig": meta.ig_ready(), "fb": meta.page_ready()}
    if net in ("ig", "fb"):
        data = insights.dashboard(net) if meta_ready[net] else None
        st_net = insights.meta_state[net]
        if meta_ready[net] and (data is None or not st_net["at"]) and not st_net["running"]:
            insights.refresh_meta_async(net)
        m = meta.summary()
        channel = {"title": ("@" + m["ig_username"]) if net == "ig" and m["ig_username"] else m["page_name"]}
    elif net == "yt":
        data = insights.dashboard("yt")
        if (data is None or not insights.state["at"]) and youtube and youtube.is_connected():
            insights.refresh_async()
        if youtube and youtube.is_connected():
            try:
                channel = youtube.channel_info()
            except Exception:
                channel = {}
    else:
        data = insights.dashboard("tt") if tt_ready else None
        if tt_ready and (data is None or not insights.tt_state["at"]):
            insights.refresh_tiktok_async()
        if tiktok and tiktok.is_connected():
            try:
                channel = {"title": tiktok.user_info().get("display_name", "")}
            except Exception:
                channel = {}
    import json as _json
    charts = _json.dumps({k: data[k] for k in ("timeline", "series", "weekday", "by_hour")} if data else {},
                         ensure_ascii=False)
    st = {"yt": insights.state, "tt": insights.tt_state}.get(net) or insights.meta_state[net]
    return render_template("performance.html", d=data, st=st, channel=channel, charts=charts, yt_error=YT_ERROR,
                           net=net, tt_ready=tt_ready, meta_ready=meta_ready, tt_stats_on=setting("TT_STATS") == "on")


def perf_extra(net):
    import besttime
    plat = {v: k for k, v in besttime.NET_OF.items()}.get(net, "YouTube")
    return {"compare": besttime.compare(net), "times": besttime.learned_times(plat), "plat": plat,
            "smart": besttime.smart_on()}


app.jinja_env.globals["perf_extra"] = perf_extra


@app.route("/performance/tiktok/enable", methods=["POST"])
def performance_tiktok_enable():
    if not tiktok or not tiktok.is_connected():
        flash("Conecte o TikTok em Contas primeiro.", "error")
        return redirect(url_for("accounts") + "#tiktok")
    save_env({"TT_STATS": "on"})
    try:
        return redirect(tiktok.start_login())
    except Exception as e:
        save_env({"TT_STATS": "off"})
        flash(str(e), "error")
        return redirect(url_for("performance", net="tt"))


@app.route("/performance/refresh", methods=["POST"])
def performance_refresh():
    net = request.form.get("net") if request.form.get("net") in ("tt", "ig", "fb") else "yt"
    if net == "yt":
        n, st = insights.refresh(force=True), insights.state
    elif net == "tt":
        n, st = insights.refresh_tiktok(force=True), insights.tt_state
    else:
        n, st = insights.refresh_meta(net, force=True), insights.meta_state[net]
    if st["error"]:
        flash(st["error"], "error")
    else:
        flash(f"Desempenho atualizado: {n} vídeo(s).", "success")
    return redirect(url_for("performance", net=net))


@app.route("/performance/status")
def performance_status():
    net = request.args.get("net", "yt")
    st = {"yt": insights.state, "tt": insights.tt_state}.get(net) or insights.meta_state.get(net, insights.state)
    return jsonify(running=st["running"], error=st["error"])


# ---------- em alta ----------
@app.route("/trends")
def trends_page():
    cat = request.args.get("cat", "")
    if cat not in [c for c, _ in trends.YT_CATEGORIES]:
        cat = ""
    niche = request.args.get("niche", "")
    niche_data = {n: trends.cached_niche(n) for n in trends.niches()}
    return render_template("trends.html", gt=trends.google_trends(), yt=trends.youtube_popular(cat), cat=cat,
                           cats=trends.YT_CATEGORIES, niches=trends.niches(), niche_data=niche_data,
                           niche=niche, ideas=trends.load_ideas(), ideas_state=trends.ideas_state,
                           tt_note=trends.tiktok_note(), ig_tags=trends.ig_tags(),
                           ig_sel=request.args.get("ig", ""), ig_data={k: trends.cached_ig(k) for k in trends.ig_tags()},
                           ig_on=meta.ig_ready(),
                           ig_data_fresh=trends.cached_ig(request.args.get("ig", "")) if request.args.get("ig") else None)


@app.route("/trends/ideas", methods=["POST"])
def trends_ideas():
    if trends.generate_ideas_async(request.form.get("platform", "ambos")):
        flash("Gerando ideias com a IA local. Leva de 1 a 3 minutos; a página atualiza sozinha.", "success")
    return redirect(url_for("trends_page") + "#ideias")


@app.route("/trends/ideas/status")
def trends_ideas_status():
    return jsonify(running=trends.ideas_state["running"], error=trends.ideas_state["error"])


@app.route("/trends/niche", methods=["POST"])
def trends_niche():
    kw = request.form.get("keyword", "").strip()[:60]
    if kw:
        res = trends.niche_videos(kw)
        if res.get("error"):
            flash(res["error"], "error")
    return redirect(url_for("trends_page", niche=kw) + "#nicho")


@app.route("/trends/niches", methods=["POST"])
def trends_niches():
    trends.set_niches(request.form.get("niches", ""))
    flash("Nichos salvos.", "success")
    return redirect(url_for("trends_page") + "#nicho")


@app.route("/trends/idea/<int:idx>/campaign", methods=["POST"])
def trends_idea_campaign(idx):
    """Ideia -> campanha (rascunho) com roteiro cena a cena escrito pela IA em segundo plano."""
    data = trends.load_ideas()
    ideas = data.get("ideas", [])
    if idx < 0 or idx >= len(ideas):
        flash("Ideia não encontrada. Gere as ideias de novo.", "error")
        return redirect(url_for("trends_page") + "#ideias")
    i = ideas[idx]
    platform = {"tiktok": "TikTok", "shorts": "YouTube"}.get(data.get("platform"), "Ambas")
    script = f"GANCHO: {i.get('gancho','')}\n\nRESUMO: {i.get('roteiro','')}\n\n(A IA está escrevendo o roteiro cena a cena…)"
    with db() as con:
        cur = con.execute("""INSERT INTO campaigns(title, video_url, platform, topic, audience, status, caption,
                             hashtags, created_at, ai_source, updated_at, video_path, script)
                             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                          (i.get("titulo", "Nova ideia")[:120], "", platform,
                           (i.get("tendencia") or ", ".join(trends.niches()))[:200], "", "Rascunho",
                           i.get("gancho", ""), i.get("hashtags", ""), now(), "Ideia (Em alta)", now(), "", script))
        cid = cur.lastrowid
    log(f"Campanha #{cid} criada a partir de uma ideia: {i.get('titulo','')[:60]}")
    trends.expand_script_async(cid, i)
    flash("Campanha criada a partir da ideia. A IA está escrevendo o roteiro cena a cena (1 a 3 minutos).", "success")
    return redirect(url_for("edit_campaign", cid=cid) + "#roteiro")


@app.route("/campaign/<int:cid>/script", methods=["POST"])
def campaign_script(cid):
    c = get_campaign(cid)
    if not c:
        return redirect(url_for("index"))
    if request.form.get("action") == "generate":
        idea = {"titulo": c["title"], "gancho": c["caption"][:200], "roteiro": (c["script"] or c["topic"])[:600],
                "hashtags": c["hashtags"]}
        trends.expand_script_async(cid, idea)
        flash("A IA está escrevendo o roteiro (1 a 3 minutos). A página atualiza sozinha.", "success")
    else:
        with db() as con:
            con.execute("UPDATE campaigns SET script=?, updated_at=? WHERE id=?",
                        (request.form.get("script", "")[:8000], now(), cid))
        flash("Roteiro salvo.", "success")
    return redirect(url_for("edit_campaign", cid=cid) + "#roteiro")


@app.route("/campaign/<int:cid>/pernet", methods=["POST"])
def campaign_pernet(cid):
    c = get_campaign(cid)
    if not c:
        return redirect(url_for("index"))
    nets = platforms_of(c["platform"])
    if request.form.get("action") == "generate":
        pernet.generate_async(cid, nets)
        flash("A IA está escrevendo um texto para cada rede. A página atualiza sozinha.", "success")
    else:
        data = pernet.get(c)
        for n in nets:
            key = n.lower()
            data[n] = {"titulo": request.form.get(f"{key}_titulo", c["title"]).strip()[:100] or c["title"][:100],
                       "legenda": request.form.get(f"{key}_legenda", "").strip()[:2200],
                       "hashtags": pernet._tags(request.form.get(f"{key}_hashtags", ""))}
        pernet.save(cid, data)
        flash("Textos de cada rede salvos. As próximas publicações usam esses textos.", "success")
    return redirect(url_for("edit_campaign", cid=cid) + "#por-rede")


@app.route("/campaign/<int:cid>/pernet/status")
def campaign_pernet_status(cid):
    return jsonify(state=pernet.state.get(cid, ""))


@app.route("/campaign/<int:cid>/script/status")
def campaign_script_status(cid):
    return jsonify(state=trends.script_state.get(cid, ""))


@app.route("/trends/ig", methods=["POST"])
def trends_ig():
    tag = request.form.get("tag", "").strip().lstrip("#")[:40]
    if tag:
        res = trends.ig_hashtag(tag)
        if res.get("error"):
            flash(f"Instagram: {res['error']}", "error")
    return redirect(url_for("trends_page", ig=tag) + "#instagram")


@app.route("/trends/tiktok", methods=["POST"])
def trends_tiktok_note():
    trends.set_tiktok_note(request.form.get("note", ""))
    flash("Anotações do TikTok salvas. A IA vai usar nas próximas ideias.", "success")
    return redirect(url_for("trends_page") + "#tiktok")


@app.route("/trends/refresh", methods=["POST"])
def trends_refresh():
    trends.clear_cache()
    return redirect(url_for("trends_page", cat=request.form.get("cat", "")))


init_db()
partners.init()
lemmy.init()
telegram.init()
social.init()
tgbot.init()


def relink_orphans():
    """Publicacoes cuja campanha foi apagada (versoes antigas) voltam para a campanha do mesmo video."""
    vid = lambda u: (re.search(r"(?:youtu\.be/|v=|/shorts/|/video/)([\w-]{6,})", u or "") or [None, None])[1]
    with db() as con:
        camps = {vid(r["video_url"]): r["id"] for r in con.execute("SELECT id, video_url FROM campaigns")}
        orphans = con.execute("""SELECT id, result_url FROM publications WHERE campaign_id IS NOT NULL
                                 AND campaign_id NOT IN (SELECT id FROM campaigns)""").fetchall()
        done = []
        for p in orphans:
            target = camps.get(vid(p["result_url"]))
            if target and vid(p["result_url"]):
                con.execute("UPDATE publications SET campaign_id=? WHERE id=?", (target, p["id"]))
                done.append((p["id"], target))
    for pid, target in done:      # registra so depois de fechar o banco (senao ele fica travado)
        log(f"Publicação #{pid} religada à campanha #{target} (mesmo vídeo)")


relink_orphans()
for _p in ("youtube", "tiktok", "meta"):      # contas ja conectadas entram na lista de contas
    try:
        accounts_store.stash(_p)
    except Exception:
        pass
insights.init()
comments.init()
import pernet
pernet.init()
comments.youtube = youtube
comments.meta = meta
insights.youtube = youtube
insights.meta = meta
insights.tiktok = tiktok
trends.youtube = youtube
trends.meta = meta
scheduler.stats_hooks += [insights.stats_hook, insights.tiktok_stats_hook, insights.meta_stats_hook, comments.stats_hook, backup_db]
import maintenance
scheduler.stats_hooks += [maintenance.weekly_hook, lambda: (maintenance.check_update(), 0)[1]]


@app.context_processor
def update_flags():
    return {"update_ready": maintenance.has_update(), "update_version": maintenance.update_state["latest"]}


@app.route("/system/backup", methods=["POST"])
def system_backup():
    try:
        out = maintenance.make_backup()
        flash(f"Backup completo criado: {out.name}. Ele tem senhas e chaves: guarde em lugar seguro.", "success")
        if sys.platform.startswith("win"):
            try:
                os.startfile(out.parent)
            except Exception:
                pass
    except Exception as e:
        flash(f"Não foi possível criar o backup: {e}", "error")
    return redirect(url_for("settings") + "#backup")


@app.route("/system/restore", methods=["POST"])
def system_restore():
    f = request.files.get("file")
    if not f or not f.filename:
        flash("Escolha o arquivo .zip do backup.", "error")
        return redirect(url_for("settings") + "#backup")
    try:
        n, safety = maintenance.restore(f.stream)
        flash(f"Backup restaurado ({n} arquivos). O estado anterior foi guardado em {safety}. "
              "Clique em Reiniciar agora para carregar as contas e configurações.", "success")
    except Exception as e:
        flash(f"Não foi possível restaurar: {e}", "error")
    return redirect(url_for("settings") + "#backup")


@app.route("/system/update/<action>", methods=["POST"])
def system_update(action):
    if action == "check":
        v = maintenance.check_update()
        if maintenance.update_state["error"]:
            flash(maintenance.update_state["error"], "error")
        elif maintenance.has_update():
            flash(f"Versão {v} disponível.", "success")
        else:
            flash(f"Você já está na versão mais nova ({VERSION}).", "success")
    elif action == "apply":
        try:
            n = maintenance.apply_update()
            flash(f"Atualização baixada ({n} arquivos). Reiniciando para terminar…", "success")
            return redirect(url_for("settings") + "#reiniciar")
        except Exception as e:
            flash(f"Não foi possível atualizar: {e}", "error")
    return redirect(url_for("settings") + "#backup")
scheduler.due_hooks += [lemmy.run_due, social.run_due, tgbot.run_due, report.run_due]


def port_in_use():
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", PORT)) == 0


def main():
    scheduler.start()
    import threading
    threading.Thread(target=ai_writer.ensure_ollama, name="abrir-ollama", daemon=True).start()
    threading.Thread(target=lambda: partners.ensure_current() if partners.is_deployed() else None,
                     name="atualizar-popups", daemon=True).start()
    print(f"AutoDivulga AI {VERSION} rodando em http://127.0.0.1:{PORT} (piloto automatico: {setting('AUTOPILOT')})")
    app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True)


if __name__ == "__main__":
    if port_in_use():
        print("O AutoDivulga AI ja esta aberto em http://127.0.0.1:5055")
        sys.exit(0)
    main()
