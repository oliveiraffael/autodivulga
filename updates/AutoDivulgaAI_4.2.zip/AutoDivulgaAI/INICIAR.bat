@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title AutoDivulga AI - Windows 10 e 11
set "LOG=%~dp0iniciar.log"
set "PY_EXE="
set "PY_ARGS="

echo =============================================== > "%LOG%"
echo AutoDivulga AI - Registro de inicializacao v2 >> "%LOG%"
echo Data: %date% %time% >> "%LOG%"
echo Pasta: %cd% >> "%LOG%"
echo =============================================== >> "%LOG%"

echo.
echo Procurando Python instalado...
echo.

REM 1) Comando python no PATH (ignora o atalho falso da Microsoft Store)
for /f "delims=" %%P in ('where python 2^>nul') do (
  if not defined PY_EXE (
    echo %%P | find /i "WindowsApps" >nul
    if errorlevel 1 (
      "%%P" --version >> "%LOG%" 2>&1
      if not errorlevel 1 set "PY_EXE=%%P"
    ) else (
      echo Ignorado atalho da Store: %%P >> "%LOG%"
    )
  )
)

REM 2) Inicializador py
if not defined PY_EXE (
  where py >nul 2>&1
  if not errorlevel 1 (
    py -3 --version >> "%LOG%" 2>&1
    if not errorlevel 1 (
      set "PY_EXE=py"
      set "PY_ARGS=-3"
    )
  )
)

REM 3) Pastas de instalacao (qualquer versao 3.x, da mais nova para a mais antiga)
if not defined PY_EXE call :procurar "%LocalAppData%\Programs\Python"
if not defined PY_EXE call :procurar "%ProgramFiles%"
if not defined PY_EXE call :procurar "%ProgramFiles(x86)%"
if not defined PY_EXE call :procurar "C:"

if not defined PY_EXE (
  echo ERRO: Python nao foi encontrado. >> "%LOG%"
  echo Nao consegui localizar o Python.
  echo.
  echo Abra o "Prompt de Comando", digite:  where python
  echo e envie o resultado. Ou reinstale o Python marcando
  echo "Add python.exe to PATH" na primeira tela do instalador.
  goto erro
)

echo Python encontrado: "%PY_EXE%" %PY_ARGS%
echo Python encontrado: "%PY_EXE%" %PY_ARGS% >> "%LOG%"
"%PY_EXE%" %PY_ARGS% --version >> "%LOG%" 2>&1

if not exist ".venv\Scripts\python.exe" (
  echo Criando ambiente virtual...
  if exist ".venv" rmdir /s /q ".venv"
  "%PY_EXE%" %PY_ARGS% -m venv .venv >> "%LOG%" 2>&1
  if errorlevel 1 (
    echo ERRO: falha ao criar ambiente virtual. >> "%LOG%"
    goto erro
  )
)

set "VPY=%~dp0.venv\Scripts\python.exe"

echo Instalando/verificando dependencias (pode demorar na primeira vez)...
"%VPY%" -m pip install --upgrade pip >> "%LOG%" 2>&1
if errorlevel 1 (
  echo ERRO: falha ao atualizar pip. >> "%LOG%"
  goto erro
)
"%VPY%" -m pip install -r requirements.txt >> "%LOG%" 2>&1
if errorlevel 1 (
  echo ERRO: falha ao instalar dependencias. >> "%LOG%"
  goto erro
)

echo.
echo Abrindo painel em http://127.0.0.1:5055
echo Deixe esta janela aberta enquanto usa o programa.
echo Para encerrar, pressione CTRL+C.
echo.
if not defined AUTODIVULGA_SILENT start "" http://127.0.0.1:5055
"%VPY%" app.py >> "%LOG%" 2>&1
echo O servidor foi encerrado. Consulte iniciar.log.
goto fim

:procurar
if not exist "%~1\" exit /b
for /f "delims=" %%D in ('dir /b /ad /o-n "%~1\Python3*" 2^>nul') do (
  if not defined PY_EXE if exist "%~1\%%D\python.exe" (
    "%~1\%%D\python.exe" --version >> "%LOG%" 2>&1
    if not errorlevel 1 set "PY_EXE=%~1\%%D\python.exe"
  )
)
exit /b

:erro
echo.
echo A inicializacao encontrou um erro.
echo Consulte iniciar.log nesta pasta.
echo.

:fim
pause
endlocal
