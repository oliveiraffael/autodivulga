"""Gera o pacote para distribuir o AutoDivulga para outras pessoas, SEM nenhum dado pessoal.

Lista branca: so entram o programa (codigo, telas, estilos) e os textos de ajuda. Ficam de fora
.env, tokens, client_secret, banco de dados, contas guardadas, midias, backups, logs e pastas de teste.
"""
import zipfile
from datetime import datetime

from core import BASE, EXPORTS, VERSION

INCLUDE_FILES = ["INICIAR.bat", "requirements.txt", "README.md", "config.env.example", "GERAR_INSTALADOR.bat",
                 "instalador.iss"]
INCLUDE_DIRS = ["templates", "static", "cloudflare"]
NEVER = {".env", ".secret", "autodivulga.db", "client_secret.json", "iniciar.log", "ideias.json"}
NEVER_SUFFIX = ("_token.json", "_channel.json", "_user.json")

FIRST_STEPS = """AUTODIVULGA AI {v} - PRIMEIROS PASSOS
=====================================

1. Instale o Python 3.11 ou mais novo em python.org (marque "Add Python to PATH").
2. Extraia esta pasta em um lugar fixo, por exemplo C:\\AutoDivulgaAI (evite a pasta do OneDrive).
3. De dois cliques em INICIAR.bat. Na primeira vez ele instala o que precisa e abre o painel.
4. No painel, o cartao "Primeiros passos" mostra o que falta. Em Contas, cada rede tem
   um "Passo a passo" para criar a sua propria chave gratis (Google, TikTok e Meta).
5. IA local (opcional, gratis): instale o Ollama em ollama.com e baixe um modelo em
   Configuracoes -> Inteligencia artificial.

Seus dados e senhas ficam so no seu computador. Nada e enviado para o criador do programa.
"""


def _skip(path):
    name = path.name
    return (name in NEVER or name.endswith(NEVER_SUFFIX) or name.startswith("client_secret")
            or "__pycache__" in path.parts or name.endswith((".pyc", ".log", ".db")))


def build():
    EXPORTS.mkdir(exist_ok=True)
    out = EXPORTS / f"AutoDivulgaAI_{VERSION}_{datetime.now():%Y-%m-%d}.zip"
    root = "AutoDivulgaAI"
    n = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(BASE.glob("*.py")):
            if f.name.startswith("test"):
                continue
            z.write(f, f"{root}/{f.name}"); n += 1
        for name in INCLUDE_FILES:
            f = BASE / name
            if f.exists():
                z.write(f, f"{root}/{name}"); n += 1
        for d in INCLUDE_DIRS:
            for f in sorted((BASE / d).rglob("*")):
                if f.is_file() and not _skip(f):
                    z.write(f, f"{root}/{f.relative_to(BASE).as_posix()}"); n += 1
        z.writestr(f"{root}/PRIMEIROS_PASSOS.txt", FIRST_STEPS.format(v=VERSION).replace("\n", "\r\n"))
    return out, n
