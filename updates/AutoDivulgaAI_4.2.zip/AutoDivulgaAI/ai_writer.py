"""Geracao de legendas e hashtags: Ollama local -> API compativel -> fallback offline."""
import os, json, re, urllib.request, urllib.error

SYSTEM = ("Você é especialista em divulgação ética de vídeos para redes sociais. "
          "Escreva em português brasileiro, de forma natural, sem prometer resultados, "
          "sem clickbait enganoso e sem pedir engajamento artificial.")

PLATFORM_HINTS = {
    "YouTube": "YouTube (descrição com 2 a 3 frases, pode citar o que a pessoa vai ver no vídeo)",
    "TikTok": "TikTok (legenda curta e direta, até 150 caracteres, com gancho no início)",
    "Ambas": "YouTube e TikTok (legenda curta que funcione nas duas plataformas)",
    "Instagram": "Instagram Reels (legenda com gancho na primeira linha, 1 a 3 frases e pergunta no fim)",
    "Facebook": "Facebook Reels (legenda curta, conversa direta com o público e pergunta no fim)",
    "Instagram + Facebook": "Instagram e Facebook Reels (legenda com gancho na primeira linha e pergunta no fim)",
    "Todas as redes": "YouTube Shorts, TikTok, Instagram e Facebook Reels (legenda curta que funcione em todas)",
}


def _post_json(url, payload, headers=None, timeout=60):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json", **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


OLLAMA = "http://localhost:11434"
RECOMMENDED = [("qwen3.5:4b", "Qwen 3.5 4B · ~3,4 GB · ótimo em português (recomendado)"),
               ("gemma3:4b", "Gemma 3 4B · ~3,3 GB · bom em português"),
               ("gemma3:1b", "Gemma 3 1B · ~0,8 GB · para PCs fracos, sem placa de vídeo"),
               ("llama3.2", "Llama 3.2 3B · ~2 GB · rápido, português mais fraco")]
last_status = {"source": "", "error": "", "seconds": 0, "at": ""}
pull_state = {"model": "", "status": "", "percent": 0, "error": "", "done": True}


def _get_json(url, timeout=3):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def ollama_status():
    """Retorna (online, lista_de_modelos)."""
    try:
        data = _get_json(f"{OLLAMA}/api/tags", timeout=2)
        return True, [m.get("name", "") for m in data.get("models", [])]
    except Exception:
        return False, []


def ollama_ps():
    """Modelos carregados agora e quanto deles esta na placa de video."""
    try:
        out = []
        for m in _get_json(f"{OLLAMA}/api/ps").get("models", []):
            size, vram = m.get("size") or 0, m.get("size_vram") or 0
            out.append({"name": m.get("name", ""), "gb": round(size / 1024 ** 3, 1),
                        "gpu": round(100 * vram / size) if size else 0})
        return out
    except Exception:
        return []


def chosen_model():
    model = os.getenv("OLLAMA_MODEL", "").strip() or "qwen3.5:4b"
    online, models = ollama_status()
    if models and model not in models and model + ":latest" not in models:
        return models[0]          # modelo configurado nao existe: usa o primeiro baixado
    return model


def _ollama(prompt):
    payload = {"model": chosen_model(), "system": SYSTEM, "prompt": prompt, "stream": False,
               "format": "json", "think": False, "keep_alive": "30m",
               "options": {"temperature": 0.7, "num_ctx": 4096}}
    try:
        data = _post_json(f"{OLLAMA}/api/generate", payload, timeout=180)
    except urllib.error.HTTPError as e:
        if e.code != 400:
            raise
        payload.pop("think")       # modelos sem modo de raciocinio podem recusar o parametro
        data = _post_json(f"{OLLAMA}/api/generate", payload, timeout=180)
    if data.get("error"):
        raise RuntimeError(data["error"])
    return data.get("response", "").strip()


def ollama_exe():
    """Caminho do Ollama no Windows (ou None)."""
    import shutil
    from pathlib import Path
    local = Path(os.getenv("LOCALAPPDATA", "")) / "Programs" / "Ollama"
    for c in (local / "ollama app.exe", local / "ollama.exe"):
        if c.exists():
            return str(c)
    return shutil.which("ollama")


def ensure_ollama():
    """Abre o Ollama se estiver instalado e fechado. Retorna True se ficou online."""
    import subprocess, sys, time
    if ollama_status()[0]:
        return True
    if os.getenv("AI_MODE", "hybrid") in ("offline", "api"):
        return False
    exe = ollama_exe()
    if not exe:
        return False
    try:
        flags = 0x08000000 if sys.platform.startswith("win") else 0   # sem janela preta
        args = [exe] if exe.lower().endswith("app.exe") else [exe, "serve"]
        subprocess.Popen(args, creationflags=flags, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        return False
    for _ in range(20):
        time.sleep(1)
        if ollama_status()[0]:
            return True
    return False


def pull_model(model):
    """Baixa um modelo no Ollama (rodar em segundo plano; progresso em pull_state)."""
    pull_state.update(model=model, status="iniciando", percent=0, error="", done=False)
    try:
        req = urllib.request.Request(f"{OLLAMA}/api/pull", data=json.dumps({"model": model}).encode(),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=60) as r:
            for line in r:
                if not line.strip():
                    continue
                ev = json.loads(line)
                if ev.get("error"):
                    raise RuntimeError(ev["error"])
                pull_state["status"] = ev.get("status", "")
                if ev.get("total"):
                    pull_state["percent"] = int(100 * (ev.get("completed") or 0) / ev["total"])
        pull_state.update(status="concluído", percent=100)
    except Exception as e:
        pull_state["error"] = str(e)[:200]
    finally:
        pull_state["done"] = True


def _record(source, started, error=""):
    import time
    from datetime import datetime
    last_status.update(source=source, error=error, seconds=round(time.time() - started, 1),
                       at=datetime.now().strftime("%d/%m %H:%M"))


def _friendly(e):
    msg = str(e)
    if "timed out" in msg.lower():
        return "a IA demorou demais para responder (mais de 3 minutos)"
    if "refused" in msg.lower() or "10061" in msg:
        return "o Ollama não está aberto"
    if "not found" in msg.lower():
        return "modelo não encontrado no Ollama (baixe em Configurações)"
    return msg[:200]


def _openai_compatible(prompt):
    key = os.getenv("OPENAI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("OPENAI_API_KEY não configurada")
    endpoint = os.getenv("OPENAI_BASE_URL", "").strip() or "https://api.openai.com/v1/chat/completions"
    model = os.getenv("OPENAI_MODEL", "").strip() or "gpt-4o-mini"
    data = _post_json(endpoint, {"model": model, "messages": [
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": prompt}]},
        headers={"Authorization": f"Bearer {key}"})
    return data["choices"][0]["message"]["content"].strip()


def _normalize_tags(tags):
    if isinstance(tags, str):
        tags = re.split(r"[\s,;]+", tags)
    out = []
    for t in tags or []:
        t = re.sub(r"[^\w]", "", str(t).strip().lstrip("#"))
        if t and ("#" + t).lower() not in [x.lower() for x in out]:
            out.append("#" + t)
    return " ".join(out[:8])


def _parse(text):
    """Aceita JSON {"legenda":..., "hashtags":[...]} ou texto livre com hashtags no meio."""
    m = re.search(r"\{.*\}", text, re.S)
    if m:
        try:
            obj = json.loads(m.group(0))
            caption = str(obj.get("legenda") or obj.get("caption") or "").strip()
            tags = _normalize_tags(obj.get("hashtags") or obj.get("tags") or [])
            if caption:
                return caption, tags
        except Exception:
            pass
    tags = _normalize_tags(re.findall(r"#\w+", text))
    caption = re.sub(r"#\w+", "", text).strip()
    return caption, tags


def _fallback(title, topic, platform):
    parts = [re.sub(r"[^\w]", "", t.strip().title()) for t in re.split(r"[,;/]", topic or "") if t.strip()]
    if platform == "YouTube":
        caption = f"Vídeo novo no canal: {title}! Assista até o final e me conte nos comentários o que achou."
        tags = ["#VideoNovo", "#YouTube", "#YouTubeBrasil"]
    elif platform == "TikTok":
        caption = f"{title} 👀 Você precisa ver isso!"
        tags = ["#TikTokBrasil", "#ParaVoce", "#fyp"]
    elif platform in ("Instagram", "Facebook", "Instagram + Facebook"):
        caption = f"{title} 👀 Assista até o final e me conta nos comentários o que achou!"
        tags = ["#Reels", "#ReelsBrasil", "#Viral"]
    else:
        caption = f"Vídeo novo: {title}! Assista e me conte o que achou."
        tags = ["#VideoNovo", "#Viral", "#Brasil"]
    for base in reversed(parts[:4]):
        if base:
            tags.insert(0, "#" + base)
    return caption, " ".join(tags[:8])


def generate_campaign_copy(title, topic, audience, platform):
    """Retorna (legenda, hashtags, fonte)."""
    prompt = f"""Crie o texto de divulgação de um vídeo para {PLATFORM_HINTS.get(platform, platform)}.
Título: {title}
Tema: {topic or 'não informado'}
Público: {audience or 'público geral'}

Responda SOMENTE com um JSON neste formato:
{{"legenda": "texto da legenda (máx. 400 caracteres, sem hashtags)", "hashtags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"]}}
Use de 4 a 7 hashtags relevantes ao tema, em português quando fizer sentido."""
    mode = os.getenv("AI_MODE", "hybrid").lower()
    attempts = []
    if mode in ("hybrid", "ollama"):
        attempts.append(("Ollama", _ollama))
    if mode in ("hybrid", "api"):
        attempts.append(("API", _openai_compatible))
    import time
    errors = []
    for name, fn in attempts:
        started = time.time()
        try:
            caption, tags = _parse(fn(prompt))
            if caption:
                if not tags:
                    tags = _fallback(title, topic, platform)[1]
                _record(name, started)
                return caption[:600], tags, name
            errors.append(f"{name}: resposta vazia")
        except Exception as e:
            errors.append(f"{name}: {_friendly(e)}")
    _record("Offline", time.time(), "; ".join(errors))
    caption, tags = _fallback(title, topic, platform)
    return caption, tags, "Offline"


# ---------------- Etapa 4: divulgacao em comunidades ----------------
def _ask_json(prompt):
    """Pergunta a IA conforme AI_MODE e devolve o primeiro JSON valido (ou None)."""
    mode = os.getenv("AI_MODE", "hybrid").lower()
    fns = []
    if mode in ("hybrid", "ollama"):
        fns.append(_ollama)
    if mode in ("hybrid", "api"):
        fns.append(_openai_compatible)
    import time
    errors = []
    for fn in fns:
        name = "Ollama" if fn is _ollama else "API"
        started = time.time()
        try:
            m = re.search(r"\{.*\}", fn(prompt), re.S)
            if m:
                obj = json.loads(m.group(0))
                _record(name, started)
                return obj
            errors.append(f"{name}: resposta sem JSON")
        except Exception as e:
            errors.append(f"{name}: {_friendly(e)}")
    if fns:
        _record("Offline", time.time(), "; ".join(errors))
    return None


def suggest_keywords(title, topic, audience, hashtags):
    """Ate 5 termos curtos para procurar comunidades (pt e en)."""
    obj = _ask_json(f"""Quero encontrar comunidades online (Reddit, Lemmy, canais do YouTube) onde um vídeo
caberia bem. Título: {title}
Tema: {topic or 'não informado'}
Público: {audience or 'geral'}
Hashtags: {hashtags or '-'}
Responda SOMENTE com JSON: {{"termos": ["termo1", "termo2", "termo3", "termo4", "termo5"]}}
Use termos curtos (1 a 3 palavras) de nicho, 3 em português e 2 em inglês, sem hashtags.""")
    terms = (obj or {}).get("termos") or (obj or {}).get("terms") or []
    return [str(t) for t in terms if str(t).strip()][:5]


def generate_place_post(c, place):
    """Texto adaptado para um local. Retorna (titulo, texto, fonte)."""
    link = c["video_url"] or ""
    kind = "canal do YouTube (mensagem de parceria/collab para o dono do canal)" if place["source"] == "YouTube" \
        else f"comunidade {place['name']} no {place['source']}"
    obj = _ask_json(f"""Escreva uma postagem honesta para divulgar um vídeo na {kind}.
Título do vídeo: {c['title']}
Tema: {c['topic'] or '-'}
Link: {link or '(sem link)'}
Sobre o local: {place['title']} — {(place['description'] or '')[:400]}
Regras do local (resumo): {(place['rules'] or 'não informadas')[:800]}
Regras para você: diga que o vídeo é seu (criador), seja natural e breve, convide para comentar,
respeite as regras do local, sem clickbait e sem pedir like/inscrição. Use o idioma da comunidade
({'português' if place['language'] == 'pt' else 'o mesmo idioma da descrição do local'}).
Responda SOMENTE com JSON: {{"titulo": "título curto do post", "texto": "corpo do post com o link no final"}}""")
    if obj and (obj.get("texto") or obj.get("text")):
        return (str(obj.get("titulo") or obj.get("title") or c["title"])[:200],
                str(obj.get("texto") or obj.get("text"))[:2000], "IA")
    if place["source"] == "YouTube":
        text = (f"Oi! Sou criador de um canal do mesmo nicho que o seu e curto muito o seu conteúdo. "
                f"Acabei de lançar \"{c['title']}\" e acho que combina com o seu público. "
                f"Topa trocar uma ideia sobre uma collab ou indicação mútua?\n{link}")
        return f"Parceria: {c['title']}", text, "Modelo"
    if place["language"] == "pt":
        text = (f"Fiz este vídeo ({c['title']}) e acho que tem a ver com a comunidade. "
                f"Sou o criador e adoraria saber o que vocês acham, críticas são bem-vindas!\n{link}")
    else:
        text = (f"I made this video ({c['title']}) and thought it fits this community. "
                f"I'm the creator and would love your honest feedback!\n{link}")
    return f"[OC] {c['title']}", text, "Modelo"
