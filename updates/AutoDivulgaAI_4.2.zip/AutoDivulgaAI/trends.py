"""Em alta: o que esta bombando agora (Google Trends Brasil + YouTube Brasil) e ideias de video
geradas pela IA local cruzando as tendencias com o nicho do canal e com o que ja deu certo.

Os dados de terceiros ficam so em memoria (cache de algumas horas) e nunca vao para o banco.
"""
import json, threading, time, xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

import requests

from core import BASE, db, save_env, setting

UA = "AutoDivulgaAI/3.1 (+painel local)"
CACHE_TTL = 3 * 3600
NICHE_TTL = 12 * 3600
IDEAS_FILE = BASE / "ideias.json"
DEFAULT_NICHES = "animação, histórias dark, pós-apocalíptico, mistério, curiosidades"
YT_CATEGORIES = [("", "Geral"), ("1", "Filmes e animação"), ("24", "Entretenimento"), ("20", "Jogos")]

youtube = None          # injetado pelo app
_cache = {}
ideas_state = {"running": False, "error": ""}


def niches():
    raw = setting("TREND_NICHES") or DEFAULT_NICHES
    return [n.strip() for n in raw.split(",") if n.strip()][:6]


def set_niches(text):
    clean = ", ".join(n.strip() for n in (text or "").replace("\n", ",").split(",") if n.strip())[:300]
    save_env({"TREND_NICHES": clean or DEFAULT_NICHES})


def _cached(key, ttl, fn):
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    try:
        value = fn()
        _cache[key] = (time.time(), value)
        return value
    except Exception as e:
        if hit:
            return hit[1]
        return {"error": str(e)[:200], "items": []}


def clear_cache():
    _cache.clear()


# ---------------- Google Trends (o que o Brasil esta buscando) ----------------
def _tag(el, name):
    for child in el:
        if child.tag.split("}")[-1] == name:
            return child
    return None


def _traffic(value):
    digits = "".join(c for c in (value or "") if c.isdigit())
    return int(digits) if digits else 0


def google_trends(geo="BR"):
    def fetch():
        r = requests.get(f"https://trends.google.com/trending/rss?geo={geo}", timeout=15,
                         headers={"User-Agent": UA})
        r.raise_for_status()
        root = ET.fromstring(r.content)
        items = []
        for it in root.iter("item"):
            news = []
            for n in it:
                if n.tag.split("}")[-1] == "news_item":
                    t, u, s = _tag(n, "news_item_title"), _tag(n, "news_item_url"), _tag(n, "news_item_source")
                    if t is not None and u is not None:
                        news.append({"title": t.text or "", "url": u.text or "", "source": (s.text if s is not None else "")})
            when = ""
            pd = _tag(it, "pubDate")
            try:
                when = parsedate_to_datetime(pd.text).astimezone().strftime("%d/%m %H:%M") if pd is not None else ""
            except Exception:
                pass
            tr = _tag(it, "approx_traffic")
            items.append({"title": (_tag(it, "title").text or "").strip(), "traffic": tr.text if tr is not None else "",
                          "traffic_n": _traffic(tr.text if tr is not None else ""), "when": when, "news": news[:2]})
        items.sort(key=lambda x: x["traffic_n"], reverse=True)
        return {"error": "", "items": items[:20]}
    return _cached(("gt", geo), CACHE_TTL, fetch)


# ---------------- YouTube ----------------
def _hours_since(iso):
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return max((datetime.now(timezone.utc) - dt).total_seconds() / 3600, 1)
    except Exception:
        return 1


def _video_items(resp):
    out = []
    for it in resp.get("items", []):
        sn, st = it.get("snippet", {}), it.get("statistics", {})
        views = int(st.get("viewCount", 0))
        hours = _hours_since(sn.get("publishedAt", ""))
        out.append({"id": it["id"] if isinstance(it["id"], str) else it["id"].get("videoId"),
                    "title": sn.get("title", ""), "channel": sn.get("channelTitle", ""),
                    "thumb": (sn.get("thumbnails", {}).get("medium") or {}).get("url", ""),
                    "views": views, "likes": int(st.get("likeCount", 0)),
                    "comments": int(st.get("commentCount", 0)),
                    "per_hour": round(views / hours), "age_h": round(hours),
                    "tags": (sn.get("tags") or [])[:6]})
    return out


def youtube_popular(category=""):
    """Mais populares do YouTube Brasil (1 unidade de cota)."""
    def fetch():
        if not youtube or not youtube.is_connected():
            return {"error": "Conecte o YouTube em Contas para ver os vídeos em alta.", "items": []}
        kw = {"part": "snippet,statistics", "chart": "mostPopular", "regionCode": "BR", "maxResults": 24,
              "hl": "pt_BR"}
        if category:
            kw["videoCategoryId"] = category
        try:
            resp = youtube.service().videos().list(**kw).execute()
        except Exception as e:
            if "notFound" in str(e) or "404" in str(e):
                return {"error": "O YouTube não tem lista de em alta para esta categoria no Brasil.", "items": []}
            raise
        items = _video_items(resp)
        items.sort(key=lambda x: x["per_hour"], reverse=True)
        return {"error": "", "items": items}
    return _cached(("yt", category), CACHE_TTL, fetch)


def niche_videos(keyword):
    """Videos do nicho que mais cresceram nos ultimos 7 dias (search custa 100 unidades: so sob demanda)."""
    def fetch():
        if not youtube or not youtube.is_connected():
            return {"error": "Conecte o YouTube em Contas.", "items": []}
        yt = youtube.service()
        after = datetime.fromtimestamp(time.time() - 7 * 86400, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        res = yt.search().list(part="id", q=keyword, type="video", order="viewCount", regionCode="BR",
                               relevanceLanguage="pt", publishedAfter=after, maxResults=12).execute()
        ids = [i["id"]["videoId"] for i in res.get("items", []) if i.get("id", {}).get("videoId")]
        if not ids:
            return {"error": "", "items": []}
        items = _video_items(yt.videos().list(part="snippet,statistics", id=",".join(ids)).execute())
        items.sort(key=lambda x: x["per_hour"], reverse=True)
        return {"error": "", "items": items}
    return _cached(("niche", keyword.lower()), NICHE_TTL, fetch)


def cached_niche(keyword):
    hit = _cache.get(("niche", keyword.lower()))
    return hit[1] if hit and time.time() - hit[0] < NICHE_TTL else None


# ---------------- ideias da IA ----------------
def load_ideas():
    try:
        return json.loads(IDEAS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"at": "", "ideas": []}


def _my_best():
    try:
        with db() as con:
            return [r["title"] for r in con.execute(
                "SELECT title FROM yt_videos WHERE privacy!='private' ORDER BY views DESC LIMIT 5")]
    except Exception:
        return []


def _campaign_topics():
    try:
        with db() as con:
            return [f"{r['title']} ({r['topic']})" for r in con.execute(
                "SELECT title, topic FROM campaigns ORDER BY id DESC LIMIT 5")]
    except Exception:
        return []


def tiktok_note():
    return (setting("TT_TRENDS_NOTE") or "").replace(" | ", "\n")


def set_tiktok_note(text):
    clean = " | ".join(l.strip() for l in (text or "").splitlines() if l.strip())[:600]
    save_env({"TT_TRENDS_NOTE": clean.replace("=", " ")})


PLATFORM_HINT = {
    "tiktok": "TikTok (vertical, até 60 s, gancho no 1º segundo, legenda curta, pode usar som em alta)",
    "shorts": "YouTube Shorts (vertical, até 60 s, gancho forte, final que puxe para o episódio seguinte)",
    "ambos": "TikTok e YouTube Shorts ao mesmo tempo (vertical, até 60 s)",
}


def _ask_ideas(ai_writer, prompt):
    """As ideias pedem uma resposta longa: no Ollama damos ate 8 minutos (o padrao do app e 3)."""
    import os, re, time as _t
    mode = os.getenv("AI_MODE", "hybrid").lower()
    if mode in ("hybrid", "ollama"):
        started = _t.time()
        try:
            payload = {"model": ai_writer.chosen_model(), "prompt": prompt, "stream": False, "format": "json",
                       "think": False, "keep_alive": "30m",
                       "options": {"temperature": 0.8, "num_ctx": 4096, "num_predict": 1400}}
            try:
                data = ai_writer._post_json(f"{ai_writer.OLLAMA}/api/generate", payload, timeout=480)
            except Exception as e:
                if "400" not in str(e):
                    raise
                payload.pop("think")
                data = ai_writer._post_json(f"{ai_writer.OLLAMA}/api/generate", payload, timeout=480)
            m = re.search(r"\{.*\}", data.get("response", ""), re.S)
            if m:
                ai_writer._record("Ollama", started)
                return json.loads(m.group(0))
        except Exception as e:
            ideas_state["error"] = f"Ollama: {ai_writer._friendly(e)}"
        if mode == "ollama":
            return None
    return ai_writer._ask_json(prompt)


def generate_ideas(platform="ambos"):
    import ai_writer
    ideas_state.update(running=True, error="")
    try:
        gt = [t["title"] for t in google_trends().get("items", [])[:8]]
        yt = [v["title"][:70] for v in youtube_popular("").get("items", [])[:6]]
        for n in niches()[:2]:
            hit = cached_niche(n)
            if hit:
                yt += [v["title"][:70] for v in hit.get("items", [])[:3]]
        prompt = (
            "Você é estrategista de conteúdo viral para YouTube Shorts e TikTok no Brasil.\n"
            f"Nicho do canal: {', '.join(niches())}.\n"
            f"Séries e campanhas do criador: {'; '.join(_campaign_topics()) or 'série animada própria'}.\n"
            f"Vídeos do canal que mais funcionaram: {'; '.join(_my_best()) or 'ainda sem dados'}.\n"
            f"O que o Brasil está buscando agora (Google Trends): {'; '.join(gt) or 'sem dados'}.\n"
            f"Vídeos em alta no YouTube Brasil: {'; '.join(yt) or 'sem dados'}.\n"
            f"Hashtags e sons em alta no TikTok Brasil (anotados pelo criador): {setting('TT_TRENDS_NOTE') or 'sem dados'}.\n"
            f"Plataforma de destino: {PLATFORM_HINT.get(platform, PLATFORM_HINT['ambos'])}.\n\n"
            "Crie 5 ideias de vídeos curtos (até 60 s) que liguem uma tendência atual ao nicho do canal, "
            "sem copiar ninguém e sem usar marcas, personagens ou músicas protegidas. Prefira ganchos de "
            "curiosidade, mistério e reviravolta. Responda SOMENTE com JSON no formato:\n"
            '{"ideias":[{"titulo":"até 70 caracteres","gancho":"primeira frase falada nos 3 primeiros segundos",'
            '"roteiro":"3 a 4 frases do que acontece","tendencia":"qual tendência aproveita",'
            '"formato":"Short/TikTok ou vídeo longo","hashtags":"#a #b #c #d","potencial":"alto, médio ou baixo"}]}'
        )
        obj = _ask_ideas(ai_writer, prompt)
        ideas = (obj or {}).get("ideias") or (obj or {}).get("ideas") or []
        clean = []
        for i in ideas[:10]:
            if isinstance(i, dict) and i.get("titulo"):
                clean.append({k: str(i.get(k, ""))[:400] for k in
                              ("titulo", "gancho", "roteiro", "tendencia", "formato", "hashtags", "potencial")})
        if not clean:
            ideas_state["error"] = ideas_state["error"] or ("A IA não devolveu ideias. Confira se o Ollama está ligado em Configurações "
                                    "→ Inteligência artificial e tente de novo.")
            return
        IDEAS_FILE.write_text(json.dumps({"at": datetime.now().strftime("%d/%m/%Y %H:%M"), "ideas": clean,
                                          "platform": platform},
                                         ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as e:
        ideas_state["error"] = f"Falha ao gerar ideias: {e}"
    finally:
        ideas_state["running"] = False


def generate_ideas_async(platform="ambos"):
    if ideas_state["running"]:
        return False
    ideas_state["running"] = True
    threading.Thread(target=generate_ideas, args=(platform if platform in PLATFORM_HINT else "ambos",),
                     name="ideias", daemon=True).start()
    return True


# ---------------- ideia -> roteiro completo ----------------
script_state = {}      # campaign_id -> "rodando" | "erro: ..." | "ok"


def expand_script(cid, idea):
    """Escreve o roteiro cena a cena (ate 60 s) e grava na campanha."""
    import ai_writer
    from core import _lock, now
    script_state[cid] = "rodando"
    prompt = (
        "Você é roteirista de vídeos curtos verticais (TikTok/Shorts) de animação dark e mistério.\n"
        f"Ideia: {idea.get('titulo','')}\nGancho: {idea.get('gancho','')}\nResumo: {idea.get('roteiro','')}\n"
        f"Nicho do canal: {', '.join(niches())}.\n\n"
        "Escreva o roteiro completo de 45 a 60 segundos em português do Brasil, dividido em 5 a 7 cenas. "
        "Para cada cena: tempo (ex.: 0-3s), o que aparece na tela (descrição visual para animar), a narração ou "
        "fala exata e um texto curto na tela. A primeira cena é o gancho e não pode passar de 3 segundos. "
        "A última cena termina com uma pergunta para os comentários e um gancho para a parte 2. "
        'Responda SOMENTE com JSON: {"cenas":[{"tempo":"","visual":"","narracao":"","texto_tela":""}],'
        '"legenda":"legenda curta para postar","hashtags":"#a #b #c #d #e"}'
    )
    try:
        obj = _ask_ideas(ai_writer, prompt) or {}
        cenas = obj.get("cenas") or []
        if not cenas:
            script_state[cid] = "erro: a IA não devolveu o roteiro (confira o Ollama em Configurações)"
            return
        lines = [f"GANCHO: {idea.get('gancho','')}", ""]
        for i, cn in enumerate(cenas, 1):
            if not isinstance(cn, dict):
                continue
            lines += [f"CENA {i} ({cn.get('tempo','')})",
                      f"  Visual: {cn.get('visual','')}",
                      f"  Narração: {cn.get('narracao','')}",
                      f"  Texto na tela: {cn.get('texto_tela','')}", ""]
        script = "\n".join(lines).strip()
        with _lock, db() as con:
            con.execute("UPDATE campaigns SET script=?, updated_at=? WHERE id=?", (script, now(), cid))
            if obj.get("legenda"):
                con.execute("UPDATE campaigns SET caption=? WHERE id=? AND (caption='' OR caption=?)",
                            (str(obj["legenda"])[:500], cid, idea.get("gancho", "")))
            if obj.get("hashtags"):
                con.execute("UPDATE campaigns SET hashtags=? WHERE id=? AND hashtags=?",
                            (str(obj["hashtags"])[:300], cid, idea.get("hashtags", "")))
        script_state[cid] = "ok"
    except Exception as e:
        script_state[cid] = f"erro: {e}"


def expand_script_async(cid, idea):
    if script_state.get(cid) == "rodando":
        return
    script_state[cid] = "rodando"
    threading.Thread(target=expand_script, args=(cid, idea), name=f"roteiro-{cid}", daemon=True).start()


# ---------------- Instagram: hashtags do nicho ----------------
meta = None
IG_TTL = 12 * 3600


def ig_tags():
    return ["".join(ch for ch in n.lower().replace(" ", "") if ch.isalnum() or ch == "_") for n in niches()]


def ig_hashtag(tag):
    def fetch():
        if not meta or not meta.ig_ready():
            return {"error": "Conecte o Instagram em Contas.", "items": []}
        try:
            return {"error": "", "items": meta.hashtag_top(tag)}
        except Exception as e:
            msg = str(e)
            if "Public Content" in msg or "permiss" in msg.lower() or "(10)" in msg:
                msg = ("o app da Meta precisa do recurso Instagram Public Content Access para buscar hashtags "
                       "(Meta for Developers → Casos de uso → Instagram → Permissões e recursos).")
            elif "30" in msg and "hashtag" in msg.lower():
                msg = "limite da Meta: 30 hashtags diferentes por semana. Tente uma que você já buscou."
            return {"error": msg, "items": []}
    return _cached(("ig", tag), IG_TTL, fetch)


def cached_ig(tag):
    hit = _cache.get(("ig", tag))
    return hit[1] if hit and time.time() - hit[0] < IG_TTL else None
