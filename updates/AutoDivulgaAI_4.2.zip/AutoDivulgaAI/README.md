# AutoDivulga AI 4.0 · Windows 10 e 11

Painel local para publicar, medir e divulgar os seus vídeos no YouTube, TikTok, Instagram e Facebook. Qualquer pessoa pode usar: cada uma conecta as próprias contas. Roda no seu computador, em http://127.0.0.1:5055.

## Atualizar uma instalação que já existe
1. Feche a janela preta do AutoDivulga.
2. Extraia o zip de atualização **por cima** da pasta do AutoDivulga e aceite substituir os arquivos. Ele só traz o programa: seus dados, contas e configurações continuam.
3. Abra o `INICIAR.bat`. Se os pop-ups estiverem publicados, o script na Cloudflare se atualiza sozinho em alguns segundos.

## Instalar em um computador novo (pendrive)
1. Instale o **Python 3.11 ou mais novo** em python.org. Na primeira tela do instalador, marque **"Add Python to PATH"**.
2. Copie a pasta `AutoDivulgaAI` do pendrive para o computador, por exemplo em `C:\AutoDivulgaAI`. Não rode direto do pendrive.
3. Dê dois cliques em **`INICIAR.bat`**. Na primeira vez ele instala o que precisa (precisa de internet, leva uns minutos) e abre o painel no navegador.
4. Para a IA local, instale o **Ollama** em ollama.com e, no painel, vá em **Configurações → Inteligência artificial → Baixar um modelo**.
   - PC com placa de vídeo (ex.: RX 5600 XT): `qwen3.5:4b`.
   - PC sem placa de vídeo e com 8 GB de RAM: `gemma3:1b`.
5. Opcional: para os cortes de vídeo, no Prompt de Comando rode `winget install Gyan.FFmpeg`.
6. Se quiser que abra junto com o Windows: **Configurações → Iniciar com o Windows**.

### Contas e segurança
Este pacote leva suas contas conectadas (YouTube, TikTok, Cloudflare) e a configuração. Os arquivos `.env`, `*_token.json` e `client_secret.json` funcionam como senhas:
- depois de copiar para o computador novo, **apague o pacote do pendrive**;
- **não rode o AutoDivulga em dois computadores ao mesmo tempo**: as publicações sairiam em dobro e o TikTok desconecta um dos dois ao renovar o acesso. Use um de cada vez, ou deixe o piloto automático ligado em só um deles.

## O que o AutoDivulga faz
- **Instagram e Facebook** (novo na 4.0): um login da Meta conecta a Página do Facebook e o Instagram profissional ligado a ela. Reels publicados sozinhos na hora marcada, números no Desempenho e hashtags em alta do seu nicho.
- **Várias contas** (novo na 4.0): guarde mais de uma conta por rede e troque a ativa com um clique (Contas → Contas neste computador).
- **Para qualquer pessoa** (novo na 4.0): passo a passo dentro do painel para cada um criar as próprias chaves grátis (Google, TikTok, Meta), cartão Primeiros passos e botão para gerar um pacote do programa sem nenhum dado pessoal (Configurações → Compartilhar o AutoDivulga).
- **Desempenho** (novo na 3.1): visualizações, curtidas, comentários e engajamento de todos os vídeos do canal, com gráficos, ranking, melhor dia e horário, Shorts x longos e recomendações automáticas.
- **Em alta** (novo na 3.1): o que o Brasil está buscando (Google Trends), vídeos em alta no YouTube Brasil, vídeos que mais cresceram no seu nicho e ideias de vídeo geradas pela IA local.
- **Campanhas**: cada vídeo vira uma campanha, com legenda e hashtags escritas pela IA local (Ollama), por uma API ou por um modelo pronto.
- **Publicações**: agenda e publica nos horários definidos. TikTok: envia como rascunho para a caixa de entrada do app. YouTube: modo assistido até a auditoria do Google ser aprovada.
- **Onde divulgar**: encontra comunidades do Reddit e do Lemmy e canais parecidos no YouTube, com nota de relevância e as regras de cada lugar. Nada é postado sem a sua aprovação.
- **Lemmy automático**: comunidades aprovadas recebem o post sozinhas, uma por vez, com intervalo mínimo. Comunidades que proíbem divulgação nunca recebem post automático.
- **Sites parceiros**: pop-up discreto com o seu vídeo em sites cujo dono colou o código. Roda grátis na sua conta da Cloudflare e mostra exibições e cliques.
- **Bluesky, Mastodon e canal do Telegram**: cada episódio marcado como Publicada é anunciado sozinho no seu perfil, uma vez por rede (episódios antigos não são reanunciados).
- **Compartilhar**: na página da campanha, botões prontos para WhatsApp, Facebook, X, Threads, Telegram, Bluesky e Reddit, e links para colar no Instagram, TikTok e YouTube.
- **Links rastreáveis**: com os pop-ups publicados na Cloudflare, cada rede ganha um link próprio e a campanha mostra de onde vieram os cliques.
- **Aprovar pelo celular**: o bot do Telegram manda as melhores sugestões (até 15 por dia) com botões Aprovar e Descartar, e avisa quando uma publicação precisa de você. Só obedece ao celular vinculado com o código do painel.
- **Cortes de vídeo**: corte vertical 9:16 de arquivos do computador (precisa do FFmpeg).

## O que ele não faz, de propósito
- Não gera visualizações, curtidas ou inscritos artificiais (proibido pelas plataformas, pode derrubar o canal).
- Não posta em comunidades sem a sua aprovação, nem comenta em vídeos de outras pessoas.
- Não coloca pop-up em sites sem a autorização do dono.
- Não baixa vídeos de links de plataformas.

## Endereços úteis
- Painel: http://127.0.0.1:5055
- Pop-ups (Cloudflare): veja em **Sites parceiros → Publicação na Cloudflare**.
- Políticas públicas (auditoria): https://oliveiraffael.github.io/autodivulga/

## Se algo der errado
- Os detalhes ficam em `iniciar.log`, nesta pasta. Envie esse arquivo para receber ajuda.
- "Python não encontrado": reinstale o Python marcando "Add Python to PATH".
- Rede que bloqueia `*.workers.dev` (comum em empresas): o painel continua sincronizando os pop-ups pela API da Cloudflare; só a página de demonstração não abre nesse computador.
- Para encerrar, feche a janela preta.

## Histórico
- **4.0**: Instagram e Facebook (publicar Reels, Desempenho, hashtags em alta), várias contas por rede, guias para criar as chaves, Primeiros passos, gerador de pacote sem dados pessoais e páginas legais para todas as redes.
- **3.2**: caixa de Comentários do YouTube (ler, sugerir com IA e responder), ideia vira campanha com roteiro cena a cena, relatório semanal no Telegram (segunda 9h), exclusão de campanha que pergunta o que fazer com as publicações, números do TikTok no Desempenho e botão Reiniciar o painel.
- **3.1**: páginas Desempenho e Em alta, proteção contra comandos vindos de outros sites, cópia de segurança diária do banco (pasta backups, 7 dias).
- **3.0**: Bluesky e Mastodon automáticos, kit de compartilhamento, links rastreáveis e aprovação pelo celular (onda 1 da avaliação).
- **2.9**: postagem automática no Lemmy e aviso opcional no Telegram.
- **2.8**: sites parceiros com pop-ups na Cloudflare (etapa 5).
- **2.7**: visual novo ("sala de controle").
- **2.6**: integração completa com o Ollama (baixar modelos, abrir sozinho, diagnóstico).
- **2.5**: busca inteligente de onde divulgar (etapa 4).
- **2.4**: TikTok, envio de rascunhos (etapa 3).
- **2.1 a 2.3**: YouTube conectado, estatísticas, arrastar arquivos.
- **2.0**: gerenciador de publicações e piloto automático (etapa 1).
