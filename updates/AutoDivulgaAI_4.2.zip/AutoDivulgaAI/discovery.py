"""Etapa 4: busca inteligente de locais para divulgar uma campanha.

Fontes (sem precisar de chave):
  - Reddit: comunidades (subreddits) e suas regras
  - Lemmy: comunidades abertas (lemmy.world e lemmy.eco.br)
  - YouTube: canais parecidos para parcerias (usa a conta já conectada)

Nada e publicado aqui: os locais encontrados entram na fila de aprovacao com
uma nota de relevancia e um resumo das regras de autopromocao.
"""
import json, math, re, threading, time, traceback, unicodedata
from datetime import datetime, timedelta

import requests

from core import VERSION, db, log, now_iso, setting, _lock

UA = f"windows:autodivulga-ai:{VERSION} (ferramenta pessoal de divulgacao)"
TIMEOUT = 15
PAUSE = 1.2           # pausa entre chamadas (respeita limites das APIs publicas)
MAX_KEYWORDS = 5
AUTO_EVERY_HOURS = 24
LEMMY_INSTANCES = ["https://lemmy.world", "https://lemmy.eco.br"]
SOURCES = ["Reddit", "Lemmy", "YouTube"]
PLACE_STATUSES = ["Sugerido", "Aprovado", "Divulgado", "Descartado"]

running = {}          # campaign_id -> {"started": iso, "step": texto}
_last_auto = 0.0

STOP = set("""a o as os um uma uns umas de do da dos das no na nos nas em por para pra com sem que
e ou se ao aos à às é ser foi vai meu minha seu sua novo nova video vídeo videos vídeos canal
episodio episódio ep parte the of and to in on for with my your new channel part""".split())

PT_HINTS = set("""você voce não nao são sao histórias historias brasil brasileiro brasileira português portugues
vídeos videos animação animacao canal inscreva comunidade também tambem aqui então entao coisas""".split())

PROMO_BAN = re.compile(r"(no|não|nao|proibid\w*|vedad\w*|sem)\s+(self[- ]?promo\w*|autopromo\w*|promo\w*|divulga\w*|"
                       r"advertis\w*|spam|propaganda|links? (de|para) (canal|youtube))|"
                       r"self[- ]?promo\w* (is|are)? ?(not allowed|banned|prohibited|forbidden)|"
                       r"don'?t (self[- ]?)?promote|do not (self[- ]?)?promote", re.I)
PROMO_LIMIT = re.compile(r"self[- ]?promo\w*|autopromo\w*|promo\w*|divulga\w*|10\s?%|one in ten|"
                         r"spam|advertis\w*|propaganda|(your|seu|sua) (own )?(channel|canal|content|conteúdo)", re.I)
PROMO_ALLOW = re.compile(r"(self[- ]?promo\w*|autopromo\w*|divulga\w*)[^.]{0,40}(allowed|welcome|permitid\w*|liberad\w*|pode)|"
                         r"(share|post|compartilh\w*|poste)[^.]{0,30}(your|seu|sua)[^.]{0,20}(work|art|video|vídeo|"
                         r"animation|animação|creation|criação|trabalho)|(oc|original content)\b", re.I)


# ---------------- utilidades ----------------
def norm(text):
    text = unicodedata.normalize("NFKD", str(text or "").lower())
    return "".join(c for c in text if not unicodedata.combining(c))


def words(text):
    return [w for w in re.findall(r"[a-z0-9]+", norm(text)) if len(w) > 3 and w not in STOP]


def hits(kw_words, text):
    """Palavras-chave que aparecem inteiras no texto (aceita plural/variacao: 'historia' ~ 'historias')."""
    tokens = set(re.findall(r"[a-z0-9]+", text))
    out = set()
    for w in kw_words:
        stem = w[:-2] if len(w) > 6 and w.endswith("s") else (w[:-1] if len(w) > 5 else w)
        if w in tokens or any(t.startswith(stem) and len(t) - len(stem) <= 3 for t in tokens if len(stem) >= 5):
            out.add(w)
    return out


# traducoes simples para buscar em comunidades em ingles quando a IA estiver desligada
EN = {"animacao": "animation", "animacoes": "animation", "desenho": "cartoon", "desenhos": "cartoons",
      "historias": "stories", "historia": "story", "terror": "horror", "medo": "scary", "misterio": "mystery",
      "misterios": "mysteries", "pos apocaliptico": "post apocalyptic", "apocaliptico": "apocalyptic",
      "curiosidades": "fun facts", "suspense": "thriller", "animais": "animals", "humanoides": "anthro",
      "historias dark": "dark stories", "creepypasta": "creepypasta", "lendas": "legends", "jogos": "games",
      "ficcao": "fiction", "fantasia": "fantasy", "drama": "drama", "comedia": "comedy", "novela": "web series",
      "curta": "short film", "curtas": "short films", "sobrevivencia": "survival", "zumbi": "zombie"}


def to_english(kw):
    n = re.sub(r"[^a-z0-9 ]", " ", norm(kw)).strip()
    n = re.sub(r"\s+", " ", n)
    if n in EN:
        return EN[n]
    parts = [EN.get(w, "") for w in n.split()]
    return " ".join(p for p in parts if p) if any(parts) else ""


def http_json(url, params=None, headers=None):
    r = requests.get(url, params=params, headers={"User-Agent": UA, **(headers or {})}, timeout=TIMEOUT)
    if r.status_code == 429:
        raise RuntimeError("limite de buscas atingido, tente mais tarde")
    r.raise_for_status()
    return r.json()


def looks_portuguese(*texts):
    w = set(norm(" ".join(t or "" for t in texts)).split())
    return len(w & {norm(x) for x in PT_HINTS}) >= 2


def promo_policy(rules_text):
    """Classifica as regras: proibe / restringe / permite / desconhecido."""
    if not rules_text:
        return "desconhecido"
    if PROMO_ALLOW.search(rules_text) and not PROMO_BAN.search(rules_text):
        return "permite"
    if PROMO_BAN.search(rules_text):
        return "proibe"
    if PROMO_LIMIT.search(rules_text):
        return "restringe"
    return "permite"


POLICY_LABEL = {"permite": "Aceita divulgação", "restringe": "Divulgação com limites",
                "proibe": "Proíbe divulgação", "desconhecido": "Regras não lidas"}


# ---------------- palavras-chave ----------------
def keywords_for(c):
    """Palavras-chave de busca: IA (Ollama/API) com fallback local."""
    from ai_writer import suggest_keywords
    kws = []
    try:
        kws = suggest_keywords(c["title"], c["topic"], c["audience"], c["hashtags"])
    except Exception:
        kws = []
    if not kws:
        kws = fallback_keywords(c)
    seen, out = set(), []
    for k in kws:
        k = re.sub(r"\s+", " ", str(k).strip().lstrip("#"))[:40]
        if k and norm(k) not in seen:
            seen.add(norm(k))
            out.append(k)
    return out[:MAX_KEYWORDS]


def fallback_keywords(c):
    out = []
    if c["topic"]:
        out += [t.strip() for t in re.split(r"[,;/]", c["topic"]) if t.strip()]
    out += [re.sub(r"(?<!^)(?=[A-Z])", " ", t.lstrip("#")) for t in (c["hashtags"] or "").split()
            if t.lstrip("#").lower() not in ("fyp", "paravoce", "foryou", "viral", "videonovo", "youtube",
                                              "youtubebrasil", "tiktokbrasil", "teste")]
    if len(out) < 3:
        out += words(c["title"])[:2]
    out = out or ["animação", "histórias"]
    english = [e for e in (to_english(k) for k in out) if e]
    pt = out[:3]
    return pt + [e for e in english if norm(e) not in {norm(x) for x in pt}][:2]


# ---------------- pontuacao ----------------
def score_place(place, kws):
    """Nota de 0 a 100 + motivos legiveis."""
    text_name = norm(f"{place['name']} {place['title']}")
    text_all = text_name + " " + norm(place.get("description", ""))
    reasons, score = [], 0
    kw_words = {w for k in kws for w in words(k)}
    hits_name = hits(kw_words, text_name)
    hits_desc = hits(kw_words, text_all) - hits_name
    if hits_name:
        score += min(40, 20 * len(hits_name))
        reasons.append("nome combina com " + ", ".join(sorted(hits_name)[:3]))
    if hits_desc:
        score += min(20, 7 * len(hits_desc))
        reasons.append("descrição fala de " + ", ".join(sorted(hits_desc)[:3]))
    members = place.get("members") or 0
    if members:
        size = math.log10(max(members, 1))
        if 3 <= size <= 5.7:          # 1 mil a ~500 mil: bom alcance sem se perder no meio
            score += 20
            reasons.append(f"{fmt_members(members)} membros (bom tamanho)")
        elif size > 5.7:
            score += 10
            reasons.append(f"{fmt_members(members)} membros (enorme, post some rápido)")
        elif members >= 100:
            score += 6
            reasons.append(f"{fmt_members(members)} membros (pequena)")
        else:
            score -= 20
            reasons.append("quase sem membros")
    if place.get("language") == "pt":
        score += 15
        reasons.append("em português")
    pol = place.get("promo_policy", "desconhecido")
    if pol == "permite":
        score += 10
    elif pol == "restringe":
        score -= 5
    elif pol == "proibe":
        score -= 40
    if place.get("source") == "YouTube":
        reasons.insert(0, "canal do mesmo nicho para parceria/collab")
    return max(0, min(100, score)), "; ".join(reasons)


def fmt_members(n):
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f} mi".replace(".0 ", " ")
    if n >= 1000:
        return f"{n / 1000:.0f} mil"
    return str(n)


# ---------------- fontes ----------------
class Blocked(Exception):
    pass


def reddit_json(path, params):
    try:
        return http_json("https://www.reddit.com" + path, params)
    except Exception as e:
        if "403" in str(e) or "401" in str(e):
            raise Blocked("o Reddit não permite busca automática sem conta de desenvolvedor; "
                          "use os atalhos de busca abaixo") from e
        raise


def search_reddit(kw):
    data = reddit_json("/subreddits/search.json", {"q": kw, "limit": 15, "include_over_18": "off", "raw_json": 1})
    out = []
    for ch in data.get("data", {}).get("children", []):
        d = ch.get("data", {})
        if d.get("over18") or d.get("subreddit_type") not in ("public", "restricted"):
            continue
        name = d.get("display_name_prefixed") or ("r/" + d.get("display_name", ""))
        desc = d.get("public_description") or ""
        out.append({"source": "Reddit", "name": name, "title": d.get("title") or "",
                    "url": "https://www.reddit.com" + (d.get("url") or f"/{name}/"),
                    "description": desc[:600], "members": d.get("subscribers") or 0,
                    "language": "pt" if d.get("lang") == "pt" or looks_portuguese(desc, d.get("title")) else "",
                    "restricted": d.get("subreddit_type") == "restricted"})
    return out


def reddit_rules(name):
    sub = name.split("/", 1)[-1]
    data = reddit_json(f"/r/{sub}/about/rules.json", {"raw_json": 1})
    rules = [f"{r.get('short_name', '')}: {r.get('description', '')}".strip(": ") for r in data.get("rules", [])]
    return "\n".join(rules)[:3000]


def search_lemmy(kw):
    out = []
    for base in LEMMY_INSTANCES:
        try:
            data = http_json(f"{base}/api/v3/search", {"q": kw, "type_": "Communities", "limit": 10, "sort": "TopAll"})
        except Exception:
            continue
        for item in data.get("communities", []):
            cm, counts = item.get("community", {}), item.get("counts", {})
            if cm.get("nsfw") or cm.get("removed") or cm.get("deleted"):
                continue
            full = cm.get("description") or ""
            desc = re.split(r"(?im)^#+\s*(rules|regras)", full)[0].strip()[:600] or full[:600]
            host = re.sub(r"^https?://", "", cm.get("actor_id", "")).split("/")[0]
            out.append({"source": "Lemmy", "name": f"!{cm.get('name')}@{host}", "title": cm.get("title") or "",
                        "url": cm.get("actor_id") or "", "description": desc,
                        "members": counts.get("subscribers") or 0,
                        "language": "pt" if host.endswith(".br") or looks_portuguese(desc, cm.get("title")) else "",
                        "rules": full[:3000], "restricted": bool(cm.get("posting_restricted_to_mods"))})
        time.sleep(PAUSE)
    return out


def search_youtube(kw):
    import youtube
    if not youtube.is_connected():
        return []
    service = youtube.service()
    res = service.search().list(part="snippet", q=kw, type="channel", maxResults=8,
                                regionCode="BR", relevanceLanguage="pt").execute()
    ids = [i["id"]["channelId"] for i in res.get("items", []) if i.get("id", {}).get("channelId")]
    if not ids:
        return []
    stats = service.channels().list(part="snippet,statistics", id=",".join(ids)).execute()
    mine = (youtube.channel_info() or {}).get("id")
    out = []
    for ch in stats.get("items", []):
        hidden = bool(ch.get("statistics", {}).get("hiddenSubscriberCount"))
        if ch["id"] == mine or (not hidden and int(ch.get("statistics", {}).get("subscriberCount") or 0) < 100):
            continue   # canais quase sem inscritos nao valem uma parceria
        sn, st = ch.get("snippet", {}), ch.get("statistics", {})
        desc = (sn.get("description") or "")[:600]
        out.append({"source": "YouTube", "name": sn.get("title", ""), "title": sn.get("customUrl", ""),
                    "url": f"https://www.youtube.com/channel/{ch['id']}", "description": desc,
                    "members": int(st.get("subscriberCount") or 0),
                    "language": "pt" if (sn.get("defaultLanguage") or "").startswith("pt") or sn.get("country") == "BR"
                    or looks_portuguese(desc) else "", "rules": ""})
    return out


FINDERS = {"Reddit": search_reddit, "Lemmy": search_lemmy, "YouTube": search_youtube}


def search_shortcuts(c):
    """Links de busca prontos para sites sem API aberta: voce pesquisa e adiciona o local."""
    from urllib.parse import quote
    kws = fallback_keywords(c)[:4]
    sites = [("Reddit", "https://www.reddit.com/search/?type=communities&q={}", "text"),
             ("Discord", "https://disboard.org/pt-br/servers/tag/{}", "slug"),
             ("Grupos do Facebook", "https://www.facebook.com/search/groups/?q={}", "text"),
             ("TikTok (hashtag)", "https://www.tiktok.com/tag/{}", "tag"),
             ("Lemmy", "https://lemmyverse.net/communities?query={}", "text")]
    out = []
    for name, tpl, mode in sites:
        links = []
        for k in kws:
            term = {"slug": re.sub(r"[^a-z0-9]+", "-", norm(k)).strip("-"),
                    "tag": re.sub(r"[^a-z0-9]", "", norm(k))}.get(mode, k)
            links.append((k, tpl.format(quote(term))))
        out.append((name, links))
    return out


def enabled_sources():
    raw = setting("DISCOVERY_SOURCES") or "Reddit,Lemmy,YouTube"
    return [s for s in SOURCES if s.lower() in raw.lower()]


# ---------------- execucao ----------------
def discover(cid):
    """Busca locais para a campanha e grava os novos como 'Sugerido'. Retorna (novos, erros)."""
    with db() as con:
        c = con.execute("SELECT * FROM campaigns WHERE id=?", (cid,)).fetchone()
    if not c:
        return 0, ["campanha não encontrada"]
    running[cid] = {"started": now_iso(), "step": "gerando palavras-chave"}
    errors, found = [], {}
    try:
        kws = keywords_for(c)
        blocked = set()
        for source in enabled_sources():
            for kw in kws[:3] if source == "YouTube" else kws:   # YouTube gasta cota: no maximo 3 buscas
                if source in blocked:
                    break
                running[cid]["step"] = f"{source}: “{kw}”"
                try:
                    for p in FINDERS[source](kw):
                        if p["url"] and p["url"] not in found:
                            p["keyword"] = kw
                            found[p["url"]] = p
                except Blocked as e:
                    blocked.add(source)
                    errors.append(f"{source}: {e}")
                except Exception as e:
                    errors.append(f"{source} ({kw}): {short_error(e)}")
                time.sleep(PAUSE)
        with db() as con:
            known = {r["url"] for r in con.execute("SELECT url FROM places WHERE campaign_id=?", (cid,))}
        fresh = [p for p in found.values() if p["url"] not in known]
        # pre-nota sem regras para decidir quais regras vale a pena ler
        for p in fresh:
            p.setdefault("promo_policy", promo_policy(p.get("rules", "")) if p.get("rules") else "desconhecido")
            p["score"], _ = score_place(p, kws)
        fresh.sort(key=lambda p: p["score"], reverse=True)
        for p in [p for p in fresh if p["source"] == "Reddit" and "Reddit" not in blocked][:10]:
            running[cid]["step"] = f"lendo regras de {p['name']}"
            try:
                p["rules"] = reddit_rules(p["name"])
                p["promo_policy"] = promo_policy(p["rules"])
            except Blocked:
                break
            except Exception:
                pass
            time.sleep(PAUSE)
        for p in fresh:
            if p.get("restricted"):
                p["promo_policy"] = "proibe" if p["source"] == "Lemmy" else p["promo_policy"]
            p["score"], p["reasons"] = score_place(p, kws)
        fresh = [p for p in fresh if p["score"] >= 25][:40]
        t = now_iso()
        with _lock, db() as con:
            for p in fresh:
                con.execute("""INSERT OR IGNORE INTO places(campaign_id, source, name, title, url, description,
                    members, language, keyword, score, reasons, rules, promo_policy, status, created_at, updated_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'Sugerido',?,?)""",
                            (cid, p["source"], p["name"], p["title"], p["url"], p.get("description", ""),
                             p.get("members") or 0, p.get("language", ""), p.get("keyword", ""), p["score"],
                             p["reasons"], p.get("rules", ""), p["promo_policy"], t, t))
            con.execute("UPDATE campaigns SET discovered_at=? WHERE id=?", (t, cid))
        log(f"Busca de locais da campanha #{cid}: {len(fresh)} sugestão(ões) nova(s)"
            + (f", {len(errors)} falha(s)" if errors else ""))
        return len(fresh), errors
    except Exception as e:
        traceback.print_exc()
        return 0, errors + [short_error(e)]
    finally:
        running.pop(cid, None)
        last_result[cid] = {"at": now_iso(), "errors": errors}


last_result = {}


def short_error(e):
    msg = str(e)
    if "403" in msg:
        return "acesso negado pelo site (bloqueio temporário)"
    if "429" in msg or "limite" in msg:
        return "limite de buscas atingido, tente mais tarde"
    if "timed out" in msg.lower() or "timeout" in msg.lower():
        return "o site demorou para responder"
    if "quota" in msg.lower():
        return "cota diária do YouTube esgotada"
    return msg[:160]


def start(cid):
    """Inicia a busca em segundo plano. Retorna False se ja estiver rodando."""
    if cid in running:
        return False
    running[cid] = {"started": now_iso(), "step": "iniciando"}
    threading.Thread(target=discover, args=(cid,), name=f"busca-{cid}", daemon=True).start()
    return True


def purge_old_youtube():
    """Politica do YouTube: dados vindos da API nao ficam guardados mais de 30 dias."""
    limit = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d %H:%M")
    with _lock, db() as con:
        con.execute("DELETE FROM places WHERE source='YouTube' AND updated_at<?", (limit,))


def auto_hook():
    """Chamado pelo agendador: busca locais 1x por dia para campanhas ativas."""
    global _last_auto
    if setting("DISCOVERY_AUTO") != "on" or time.time() - _last_auto < 3600:
        return 0
    _last_auto = time.time()
    purge_old_youtube()
    limit = (datetime.now() - timedelta(hours=AUTO_EVERY_HOURS)).strftime("%Y-%m-%d %H:%M")
    with db() as con:
        rows = con.execute("""SELECT id FROM campaigns WHERE status IN ('Aprovada','Publicada')
                              AND (discovered_at IS NULL OR discovered_at='' OR discovered_at<?)
                              ORDER BY id DESC LIMIT 3""", (limit,)).fetchall()
    ids = [r["id"] for r in rows if r["id"] not in running]
    if ids:   # roda em outra thread para nao atrasar o agendador de publicacoes
        threading.Thread(target=lambda: [discover(i) for i in ids], name="busca-auto", daemon=True).start()
    return len(ids)
