// AutoDivulga AI · pop-ups em sites parceiros (Cloudflare Workers, plano gratuito)
// Publicado automaticamente pelo painel do AutoDivulga. Nao edite pelo site da Cloudflare:
// alteracoes feitas la sao sobrescritas na proxima publicacao.
//
// Rotas:
//   GET  /widget.js?p=ID       script que o site parceiro cola na pagina
//   GET  /api/promo?p=ID       video que o parceiro deve mostrar agora (JSON)
//   POST /api/event            {p, c, t: "view"|"close"} contagem anonima
//   GET  /go?p=ID&c=CID        conta o clique e redireciona para o video
//   GET  /l/c12-wa             link rastreavel: conta o clique por origem (wa = WhatsApp...) e redireciona
//   PUT  /admin/config         configuracao enviada pelo painel (Bearer ADMIN_TOKEN)
//   GET  /admin/stats?days=30  numeros por dia, parceiro e campanha (Bearer ADMIN_TOKEN)
//   GET  /health

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS stats (day TEXT NOT NULL, partner TEXT NOT NULL, promo TEXT NOT NULL,
     views INTEGER DEFAULT 0, clicks INTEGER DEFAULT 0, closes INTEGER DEFAULT 0,
     PRIMARY KEY (day, partner, promo))`,
];

let cache = { at: 0, cfg: null };
let schemaReady = false;

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status, headers: { "Content-Type": "application/json; charset=utf-8", ...CORS, ...extra },
  });
}

async function ensureSchema(env) {
  if (schemaReady) return;
  for (const sql of SCHEMA) await env.DB.prepare(sql).run();
  schemaReady = true;
}

async function getConfig(env) {
  if (cache.cfg && Date.now() - cache.at < 60_000) return cache.cfg;
  await ensureSchema(env);
  const row = await env.DB.prepare("SELECT value FROM config WHERE key = 'main'").first();
  cache = { at: Date.now(), cfg: row ? JSON.parse(row.value) : { partners: {}, promos: {}, settings: {} } };
  return cache.cfg;
}

function promoFor(cfg, partnerId) {
  const partner = cfg.partners?.[partnerId];
  if (!partner || !partner.active) return null;
  const key = partner.promo && cfg.promos?.[partner.promo] ? partner.promo : cfg.latest;
  const promo = cfg.promos?.[key];
  return promo ? { key, ...promo } : null;
}

const today = () => new Date().toISOString().slice(0, 10);
const cleanId = (v) => String(v || "").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 40);

async function count(env, partner, promo, field) {
  if (!["views", "clicks", "closes"].includes(field)) return;
  await ensureSchema(env);
  await env.DB.prepare(
    `INSERT INTO stats (day, partner, promo, ${field}) VALUES (?1, ?2, ?3, 1)
     ON CONFLICT (day, partner, promo) DO UPDATE SET ${field} = ${field} + 1`
  ).bind(today(), partner, promo).run();
}

function authorized(req, env) {
  const h = req.headers.get("Authorization") || "";
  return env.ADMIN_TOKEN && h === `Bearer ${env.ADMIN_TOKEN}`;
}

export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);
    const path = url.pathname;

    if (req.method === "OPTIONS") return new Response(null, { headers: CORS });

    if (path === "/demo") {
      const p = cleanId(url.searchParams.get("p"));
      return new Response(`<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Demonstração do pop-up</title>
<style>body{font:17px/1.6 Georgia,serif;max-width:680px;margin:48px auto;padding:0 20px;color:#222;background:#f7f6f3}
h1{font-size:30px}p{color:#444}</style></head><body><h1>Demonstração do pop-up</h1>
<p>Assim o cartão aparece no site do parceiro: no canto da tela, sem cobrir o conteúdo.
Nesta página ele aparece sempre e não entra nas estatísticas.</p>
<script src="/widget.js?p=${p}&demo=1" async></script></body></html>`,
        { headers: { "Content-Type": "text/html; charset=utf-8" } });
    }

    if (path === "/health") return json({ ok: true, app: "AutoDivulga pop-ups" });

    if (path === "/widget.js") {
      const p = cleanId(url.searchParams.get("p"));
      const demo = url.searchParams.get("demo") === "1";
      return new Response(widget(url.origin, p, demo), {
        headers: { "Content-Type": "application/javascript; charset=utf-8",
                   "Cache-Control": "public, max-age=300", ...CORS },
      });
    }

    if (path === "/api/promo") {
      const cfg = await getConfig(env);
      const p = cleanId(url.searchParams.get("p"));
      const promo = promoFor(cfg, p);
      if (!promo) return json({ show: false });
      const s = cfg.settings || {};
      return json({ show: true, promo: { key: promo.key, title: promo.title, text: promo.text,
                    thumb: promo.thumb, cta: promo.cta || "Assistir agora" },
                    delay: s.delay ?? 8, cap_hours: s.cap_hours ?? 24, position: s.position || "right" },
                  200, { "Cache-Control": "public, max-age=60" });
    }

    if (path === "/api/event" && req.method === "POST") {
      let body = {};
      try { body = await req.json(); } catch {}
      const p = cleanId(body.p), c = cleanId(body.c);
      const field = body.t === "view" ? "views" : body.t === "close" ? "closes" : null;
      if (p && c && field) ctx.waitUntil(count(env, p, c, field));
      return new Response(null, { status: 204, headers: CORS });
    }

    if (path === "/go") {
      const cfg = await getConfig(env);
      const p = cleanId(url.searchParams.get("p")), c = cleanId(url.searchParams.get("c"));
      const promo = cfg.promos?.[c];
      if (!promo) return new Response("Vídeo não encontrado.", { status: 404 });
      if (p) ctx.waitUntil(count(env, p, c, "clicks"));
      return Response.redirect(promo.url, 302);
    }

    const short = path.match(/^\/l\/(c\d+)-([a-z]{2,3})$/);
    if (short) {
      const cfg = await getConfig(env);
      const promo = cfg.promos?.[short[1]];
      if (!promo) return new Response("Vídeo não encontrado.", { status: 404 });
      ctx.waitUntil(count(env, "via:" + short[2], short[1], "clicks"));
      return Response.redirect(promo.url, 302);
    }

    if (path === "/admin/config" && req.method === "PUT") {
      if (!authorized(req, env)) return json({ error: "não autorizado" }, 401);
      const cfg = await req.json();
      await ensureSchema(env);
      await env.DB.prepare(
        `INSERT INTO config (key, value, updated_at) VALUES ('main', ?1, ?2)
         ON CONFLICT (key) DO UPDATE SET value = ?1, updated_at = ?2`
      ).bind(JSON.stringify(cfg), new Date().toISOString()).run();
      cache = { at: 0, cfg: null };
      return json({ ok: true, partners: Object.keys(cfg.partners || {}).length });
    }

    if (path === "/admin/stats") {
      if (!authorized(req, env)) return json({ error: "não autorizado" }, 401);
      await ensureSchema(env);
      const days = Math.min(365, Number(url.searchParams.get("days")) || 30);
      const since = new Date(Date.now() - days * 86400_000).toISOString().slice(0, 10);
      const { results } = await env.DB.prepare(
        "SELECT day, partner, promo, views, clicks, closes FROM stats WHERE day >= ?1 ORDER BY day"
      ).bind(since).all();
      return json({ ok: true, since, rows: results });
    }

    return new Response("AutoDivulga pop-ups", { status: 404 });
  },
};

// Script do parceiro: um cartao discreto no canto, uma vez a cada X horas por visitante,
// fecha com um clique ou com Esc, isolado do site (Shadow DOM), sem cookies.
function widget(origin, partner, demo) {
  return `(function(){
"use strict";
if (window.__autodivulga) return; window.__autodivulga = 1;
var O=${JSON.stringify(origin)}, P=${JSON.stringify(partner)}, K="autodivulga_seen_"+P, DEMO=${demo ? "true" : "false"};
function seenRecently(h){if(DEMO)return false;try{var t=+localStorage.getItem(K)||0;return Date.now()-t<h*3600e3}catch(e){return false}}
function mark(){try{localStorage.setItem(K,String(Date.now()))}catch(e){}}
function send(t,c){if(DEMO)return;try{fetch(O+"/api/event",{method:"POST",keepalive:true,headers:{"Content-Type":"application/json"},body:JSON.stringify({p:P,c:c,t:t})})}catch(e){}}
fetch(O+"/api/promo?p="+encodeURIComponent(P)).then(function(r){return r.json()}).then(function(d){
  if(!d||!d.show||seenRecently(d.cap_hours))return;
  setTimeout(function(){show(d)},DEMO?800:Math.max(0,d.delay)*1000);
}).catch(function(){});
function esc(s){return String(s||"").replace(/[&<>"']/g,function(m){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]})}
function show(d){
  var p=d.promo, host=document.createElement("div"); host.setAttribute("data-autodivulga","");
  host.style.cssText="position:fixed;z-index:2147483000;bottom:20px;"+(d.position==="left"?"left":"right")+":20px";
  var root=host.attachShadow?host.attachShadow({mode:"open"}):host;
  root.innerHTML='<style>'+
  '.c{position:relative;width:300px;max-width:calc(100vw - 40px);font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;color:#ece8e1;background:#1e2129;border:1px solid #323744;border-radius:12px;box-shadow:0 12px 32px rgba(0,0,0,.35);overflow:hidden;transform:translateY(12px);opacity:0;transition:transform .35s ease,opacity .35s ease}'+
  '.c.in{transform:none;opacity:1}'+
  '.th{display:block;position:relative;aspect-ratio:16/9;background:#17191f center/cover no-repeat}'+
  '.th::after{content:"";position:absolute;inset:0;margin:auto;width:48px;height:48px;border-radius:50%;background:rgba(240,164,58,.92) url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27%3E%3Cpath d=%27M9 6.5v11l9-5.5z%27 fill=%27%232a1a04%27/%3E%3C/svg%3E") center/26px no-repeat}'+
  '.b{padding:12px 14px 14px}.k{font-size:12px;color:#9ea1ab;margin:0 0 4px}.t{font-weight:600;font-size:15px;margin:0 0 6px}.x{font-size:13px;color:#c9c6c0;margin:0 0 12px}'+
  '.a{display:inline-block;background:#f0a43a;color:#2a1a04;font-weight:600;text-decoration:none;padding:8px 14px;border-radius:8px}'+
  '.a:focus-visible,.cl:focus-visible{outline:2px solid #f0a43a;outline-offset:2px}'+
  '.cl{position:absolute;z-index:2;top:8px;right:8px;width:28px;height:28px;border-radius:50%;border:0;background:rgba(23,25,31,.8);color:#ece8e1;font-size:18px;line-height:28px;cursor:pointer}'+
  '@media (prefers-reduced-motion:reduce){.c{transition:none}}'+
  '</style><div class="c" role="dialog" aria-label="Vídeo recomendado">'+
  '<button class="cl" aria-label="Fechar">×</button>'+
  (p.thumb?'<a class="th" target="_blank" rel="noopener" href="'+O+'/go?p='+encodeURIComponent(P)+'&c='+encodeURIComponent(p.key)+'" style="background-image:url('+esc(p.thumb)+')" aria-label="Assistir"></a>':'')+
  '<div class="b"><p class="k">Vídeo recomendado</p><p class="t">'+esc(p.title)+'</p>'+(p.text?'<p class="x">'+esc(p.text)+'</p>':'')+
  '<a class="a" target="_blank" rel="noopener" href="'+O+'/go?p='+encodeURIComponent(P)+'&c='+encodeURIComponent(p.key)+'">'+esc(p.cta)+'</a></div></div>';
  document.body.appendChild(host); mark(); send("view",p.key);
  var card=root.querySelector(".c"); requestAnimationFrame(function(){card.classList.add("in")});
  function close(){send("close",p.key);host.remove();document.removeEventListener("keydown",onKey)}
  function onKey(e){if(e.key==="Escape")close()}
  root.querySelector(".cl").addEventListener("click",close); document.addEventListener("keydown",onKey);
  root.querySelectorAll("a").forEach(function(a){a.addEventListener("click",function(){setTimeout(function(){host.remove()},100)})});
}
})();`;
}
