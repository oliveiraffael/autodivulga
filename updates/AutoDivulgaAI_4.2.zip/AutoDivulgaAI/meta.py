"""Integracao com a Meta: Instagram (conta profissional) e Facebook (Pagina), num unico login.

- Login: Facebook Login for Business (codigo OAuth) com o App ID e a Chave Secreta do app da pessoa.
  O retorno vai para http://localhost:5055/meta/callback/ (localhost e liberado pela Meta em modo
  de desenvolvimento; em producao, cadastre esse endereco em "URIs de redirecionamento OAuth validos").
- Publica Reels no Instagram (upload do arquivo do computador, protocolo resumable) e Reels na
  Pagina do Facebook (video_reels). Le numeros dos videos e as hashtags em alta do nicho.
- Token salvo em meta_token.json, so neste computador. O token de Pagina nao expira.
"""
import json, secrets, time
from pathlib import Path
from urllib.parse import urlencode

import requests

import publishers
from core import BASE, log, setting

VER = "v25.0"
GRAPH = f"https://graph.facebook.com/{VER}"
RUPLOAD_IG = f"https://rupload.facebook.com/ig-api-upload/{VER}"
TOKEN_FILE = BASE / "meta_token.json"
REDIRECT_URI = "http://localhost:5055/meta/callback/"
SCOPES = ["pages_show_list", "pages_read_engagement", "pages_manage_posts", "read_insights",
          "business_management", "instagram_basic", "instagram_content_publish", "instagram_manage_insights",
          "instagram_manage_comments", "pages_read_user_content", "pages_manage_engagement"]
TIMEOUT = 30
MAX_MB = 300                 # limite de Reels no Instagram e boa margem para o Facebook

_pending = {}


class MetaError(Exception):
    pass


# ---------------- credenciais e token ----------------
def app_id():
    return setting("META_APP_ID").strip()


def app_secret():
    return setting("META_APP_SECRET").strip()


def has_credentials():
    return bool(app_id() and app_secret())


def load():
    try:
        return json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save(data):
    TOKEN_FILE.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return data


def is_connected():
    return has_credentials() and bool(load().get("user_token"))


def page_ready():
    d = load()
    return is_connected() and bool(d.get("page_id") and d.get("page_token"))


def ig_ready():
    d = load()
    return is_connected() and bool(d.get("ig_id"))


def _call(method, path, token=None, **kw):
    url = path if path.startswith("http") else f"{GRAPH}/{path.lstrip('/')}"
    params = kw.pop("params", {}) or {}
    if token and "headers" not in kw:
        params["access_token"] = token
    try:
        r = requests.request(method, url, params=params, timeout=kw.pop("timeout", TIMEOUT), **kw)
    except requests.RequestException as e:
        raise publishers.TemporaryError(f"Sem conexão com a Meta: {e.__class__.__name__}")
    try:
        data = r.json()
    except Exception:
        data = {}
    if r.status_code >= 400 or (isinstance(data, dict) and data.get("error")):
        err = (data or {}).get("error", {}) if isinstance(data, dict) else {}
        code, msg = err.get("code"), err.get("message") or r.text[:200]
        if r.status_code >= 500 or code in (1, 2, 4, 17, 32, 341, 613, 9007):
            raise publishers.TemporaryError(f"Meta ocupada ou limite atingido ({code}): {msg}")
        if code == 190:
            raise publishers.PermanentError("A conexão com a Meta expirou. Vá em Contas e conecte de novo.")
        if code in (10, 200) or (isinstance(code, int) and 200 <= code < 300):
            raise publishers.PermanentError(f"Falta permissão no app da Meta ({msg}).")
        raise publishers.PermanentError(f"A Meta recusou ({code}): {msg}")
    return data


# ---------------- login ----------------
def start_login(switch=False):
    if not has_credentials():
        raise RuntimeError("Informe o App ID e a Chave Secreta do seu app da Meta primeiro (Contas → Instagram e Facebook).")
    state = secrets.token_urlsafe(16)
    _pending[state] = time.time()
    params = {"client_id": app_id(), "redirect_uri": REDIRECT_URI, "state": state, "response_type": "code"}
    config = setting("META_CONFIG_ID").strip()
    if config:      # app do tipo Empresa (Facebook Login for Business): as permissoes vem da configuracao
        params["config_id"] = config
    else:           # Facebook Login classico: as permissoes vao na lista
        params["scope"] = ",".join(SCOPES)
    if switch:
        params["auth_type"] = "reauthenticate"     # pede a senha de novo: da para entrar com outra conta
    return f"https://www.facebook.com/{VER}/dialog/oauth?" + urlencode(params)


def finish_login(state, code):
    if not _pending.pop(state, None):
        raise RuntimeError("O login expirou ou o programa foi reiniciado no meio. Clique em Conectar de novo.")
    short = _call("GET", "oauth/access_token", params={
        "client_id": app_id(), "client_secret": app_secret(), "redirect_uri": REDIRECT_URI, "code": code})
    long = _call("GET", "oauth/access_token", params={
        "grant_type": "fb_exchange_token", "client_id": app_id(), "client_secret": app_secret(),
        "fb_exchange_token": short["access_token"]})
    token = long["access_token"]
    me = _call("GET", "me", token, params={"fields": "id,name"})
    data = {"user_token": token, "user_id": me.get("id"), "user_name": me.get("name", ""),
            "expires_at": time.time() + int(long.get("expires_in") or 60 * 86400), "pages": list_pages(token)}
    if len(data["pages"]) == 1:
        _apply_page(data, data["pages"][0])
    save(data)
    log(f"Meta conectada: {data['user_name']} ({len(data['pages'])} Página(s))")
    return data


def list_pages(token):
    out, url = [], "me/accounts"
    params = {"fields": "id,name,access_token,followers_count,instagram_business_account{id,username,followers_count,profile_picture_url}",
              "limit": 50}
    for _ in range(5):
        d = _call("GET", url, token, params=params)
        for p in d.get("data", []):
            ig = p.get("instagram_business_account") or {}
            out.append({"id": p["id"], "name": p.get("name", ""), "token": p.get("access_token", ""),
                        "followers": p.get("followers_count"), "ig_id": ig.get("id", ""),
                        "ig_username": ig.get("username", ""), "ig_followers": ig.get("followers_count"),
                        "ig_picture": ig.get("profile_picture_url", "")})
        nxt = (d.get("paging") or {}).get("next")
        if not nxt:
            break
        url, params = nxt, {}
    return out


def _apply_page(data, page):
    data.update(page_id=page["id"], page_name=page["name"], page_token=page["token"],
                ig_id=page.get("ig_id", ""), ig_username=page.get("ig_username", ""))


def choose_page(page_id):
    data = load()
    page = next((p for p in data.get("pages", []) if p["id"] == page_id), None)
    if not page:
        raise RuntimeError("Página não encontrada. Conecte de novo.")
    _apply_page(data, page)
    save(data)
    log(f"Meta: Página escolhida {page['name']}" + (f" (Instagram @{page['ig_username']})" if page.get("ig_username") else ""))


def refresh_pages():
    data = load()
    data["pages"] = list_pages(data["user_token"])
    if data.get("page_id"):
        page = next((p for p in data["pages"] if p["id"] == data["page_id"]), None)
        if page:
            _apply_page(data, page)
    save(data)
    return data


def disconnect(revoke=True):
    data = load()
    if revoke and data.get("user_token") and data.get("user_id"):
        try:
            requests.delete(f"{GRAPH}/{data['user_id']}/permissions", params={"access_token": data["user_token"]}, timeout=15)
        except Exception:
            pass
    TOKEN_FILE.unlink(missing_ok=True)


def summary():
    d = load()
    days_left = int((d.get("expires_at", 0) - time.time()) / 86400) if d else 0
    return {"connected": is_connected(), "user": d.get("user_name", ""), "pages": d.get("pages", []),
            "page_id": d.get("page_id", ""), "page_name": d.get("page_name", ""),
            "ig_id": d.get("ig_id", ""), "ig_username": d.get("ig_username", ""), "days_left": days_left}


# ---------------- envio ----------------
def _check_file(path):
    p = Path(path or "")
    if not path or not p.is_file():
        raise publishers.PermanentError("Arquivo do vídeo não encontrado. Informe o caminho na publicação.")
    if p.suffix.lower() not in (".mp4", ".mov"):
        raise publishers.PermanentError("Instagram e Facebook aceitam vídeos MP4 ou MOV.")
    if p.stat().st_size > MAX_MB * 1024 * 1024:
        raise publishers.PermanentError(f"O vídeo passa de {MAX_MB} MB, o limite dos Reels.")
    return p


def _upload_bytes(url, token, path):
    size = path.stat().st_size
    with open(path, "rb") as f:
        try:
            r = requests.post(url, data=f, timeout=600, headers={
                "Authorization": f"OAuth {token}", "offset": "0", "file_size": str(size)})
        except requests.RequestException as e:
            raise publishers.TemporaryError(f"Falha de conexão no envio do vídeo: {e.__class__.__name__}")
    try:
        data = r.json()
    except Exception:
        data = {}
    if r.status_code >= 400 or not data.get("success", True):
        raise publishers.TemporaryError(f"A Meta não recebeu o arquivo ({r.status_code}): {str(data)[:200]}")
    return data


def _caption(pub):
    text = (pub["description"] or pub["title"] or "").strip()
    if pub["hashtags"] and pub["hashtags"] not in text:
        text = (text + "\n\n" + pub["hashtags"]).strip()
    return text[:2200]


def publish_instagram(pub):
    d = load()
    if not d.get("ig_id"):
        raise publishers.PermanentError("Nenhuma conta profissional do Instagram ligada à Página escolhida.")
    path = _check_file(pub["video_path"])
    token = d["user_token"]
    box = _call("POST", f"{d['ig_id']}/media", token, params={
        "media_type": "REELS", "upload_type": "resumable", "caption": _caption(pub), "share_to_feed": "true"})
    cid = box["id"]
    _upload_bytes(f"{RUPLOAD_IG}/{cid}", token, path)
    status = ""
    for _ in range(60):                       # ate ~5 minutos processando
        status = _call("GET", cid, token, params={"fields": "status_code,status"}).get("status_code", "")
        if status == "FINISHED":
            break
        if status in ("ERROR", "EXPIRED"):
            raise publishers.PermanentError("O Instagram não conseguiu processar o vídeo (formato ou duração). "
                                            "Use MP4 vertical 9:16, de 3 s a 15 min.")
        time.sleep(5)
    if status != "FINISHED":
        raise publishers.TemporaryError("O Instagram ainda está processando o vídeo. Nova tentativa em alguns minutos.")
    media = _call("POST", f"{d['ig_id']}/media_publish", token, params={"creation_id": cid})
    link = ""
    try:
        link = _call("GET", media["id"], token, params={"fields": "permalink"}).get("permalink", "")
    except Exception:
        pass
    return publishers.PublishResult("Publicada", "Reel publicado no Instagram.", link)


def publish_facebook(pub):
    d = load()
    if not d.get("page_id"):
        raise publishers.PermanentError("Escolha a Página do Facebook em Contas.")
    path = _check_file(pub["video_path"])
    token = d["page_token"]
    start = _call("POST", f"{d['page_id']}/video_reels", token, params={"upload_phase": "start"})
    vid = start["video_id"]
    _upload_bytes(start.get("upload_url") or f"https://rupload.facebook.com/video-upload/{VER}/{vid}", token, path)
    _call("POST", f"{d['page_id']}/video_reels", token, params={
        "upload_phase": "finish", "video_id": vid, "video_state": "PUBLISHED", "description": _caption(pub)})
    return publishers.PublishResult("Publicada", "Reel enviado para a Página do Facebook (fica no ar em alguns minutos).",
                                    f"https://www.facebook.com/reel/{vid}")


class InstagramPublisher:
    name = "Instagram API"
    automatic = True

    def is_connected(self):
        return ig_ready() and setting("IG_UPLOAD") != "off"

    def publish(self, pub):
        return publish_instagram(pub)


class FacebookPublisher:
    name = "Facebook API"
    automatic = True

    def is_connected(self):
        return page_ready() and setting("FB_UPLOAD") != "off"

    def publish(self, pub):
        return publish_facebook(pub)


publishers.register("Instagram", InstagramPublisher())
publishers.register("Facebook", FacebookPublisher())
publishers.UPLOAD_PAGES.update({"Instagram": "https://www.instagram.com/", "Facebook": "https://www.facebook.com/"})


# ---------------- numeros ----------------
def _metric(insights, name):
    for m in (insights or {}).get("data", []):
        if m.get("name") == name:
            vals = m.get("values") or [{}]
            return int(m.get("total_value", {}).get("value") or vals[0].get("value") or 0)
    return 0


def instagram_stats(max_items=60):
    d = load()
    token, ig = d["user_token"], d["ig_id"]
    prof = _call("GET", ig, token, params={"fields": "username,followers_count,media_count"})
    items, url, params = [], f"{ig}/media", {
        "fields": "id,caption,media_type,media_product_type,timestamp,permalink,thumbnail_url,media_url,like_count,comments_count",
        "limit": 50}
    while url and len(items) < max_items:
        page = _call("GET", url, token, params=params)
        items += page.get("data", [])
        url, params = (page.get("paging") or {}).get("next"), {}
    out = []
    for m in items[:max_items]:
        views = shares = 0
        try:
            ins = _call("GET", f"{m['id']}/insights", token, params={"metric": "views,shares"})
            views, shares = _metric(ins, "views"), _metric(ins, "shares")
        except Exception:
            pass
        out.append({"id": m["id"], "title": (m.get("caption") or "(sem legenda)").strip()[:200],
                    "created": m.get("timestamp", ""), "thumb": m.get("thumbnail_url") or m.get("media_url") or "",
                    "video": m.get("media_type") == "VIDEO", "views": views, "likes": int(m.get("like_count") or 0),
                    "comments": int(m.get("comments_count") or 0), "shares": shares, "url": m.get("permalink", "")})
    return {"followers": prof.get("followers_count"), "media_count": prof.get("media_count"), "items": out}


def facebook_stats(max_items=50):
    d = load()
    token, page = d["page_token"], d["page_id"]
    info = _call("GET", page, token, params={"fields": "name,followers_count,fan_count"})
    vids = _call("GET", f"{page}/video_reels", token, params={
        "fields": "id,description,created_time,permalink_url,length,picture", "limit": max_items}).get("data", [])
    out = []
    for v in vids:
        views = likes = comments = shares = 0
        try:
            ins = _call("GET", f"{v['id']}/video_insights", token,
                        params={"metric": "blue_reels_play_count,post_video_social_actions"})
            views = _metric(ins, "blue_reels_play_count")
            for m in ins.get("data", []):
                if m.get("name") == "post_video_social_actions":
                    val = (m.get("values") or [{}])[0].get("value") or {}
                    if isinstance(val, dict):
                        likes, comments, shares = int(val.get("REACTION", 0)), int(val.get("COMMENT", 0)), int(val.get("SHARE", 0))
        except Exception:
            pass
        link = v.get("permalink_url", "")
        out.append({"id": v["id"], "title": (v.get("description") or "(sem descrição)").strip()[:200],
                    "created": v.get("created_time", ""), "thumb": v.get("picture", ""), "duration": int(float(v.get("length") or 0)),
                    "views": views, "likes": likes, "comments": comments, "shares": shares,
                    "url": ("https://www.facebook.com" + link) if link.startswith("/") else link})
    return {"followers": info.get("followers_count") or info.get("fan_count"), "items": out}


# ---------------- em alta (hashtags do Instagram) ----------------
def hashtag_top(tag, limit=12):
    """Posts mais fortes de uma hashtag. A Meta permite 30 hashtags diferentes por conta a cada 7 dias."""
    d = load()
    token, ig = d["user_token"], d["ig_id"]
    tag = "".join(ch for ch in tag.lower().replace("#", "") if ch.isalnum() or ch == "_")
    if not tag:
        return []
    hid = _call("GET", "ig_hashtag_search", token, params={"user_id": ig, "q": tag}).get("data", [{}])[0].get("id")
    if not hid:
        return []
    res = _call("GET", f"{hid}/top_media", token, params={
        "user_id": ig, "fields": "id,caption,media_type,permalink,like_count,comments_count,timestamp", "limit": 25})
    out = []
    for m in res.get("data", []):
        out.append({"caption": (m.get("caption") or "")[:160], "url": m.get("permalink", ""),
                    "likes": int(m.get("like_count") or 0), "comments": int(m.get("comments_count") or 0),
                    "video": m.get("media_type") == "VIDEO", "when": (m.get("timestamp") or "")[:10]})
    out.sort(key=lambda x: x["likes"] + 3 * x["comments"], reverse=True)
    return out[:limit]


# ---------------- comentarios (Instagram e Facebook) ----------------
COMMENT_SCOPES = ["instagram_manage_comments", "pages_read_user_content", "pages_manage_engagement"]


def granted():
    """Permissoes concedidas no ultimo login (lista vazia se nao souber)."""
    d = load()
    if not d.get("user_token"):
        return []
    try:
        perms = _call("GET", "me/permissions", d["user_token"]).get("data", [])
        return [p["permission"] for p in perms if p.get("status") == "granted"]
    except Exception:
        return []


def can_comments():
    return set(COMMENT_SCOPES) <= set(granted())


def ig_comments(max_media=25):
    """Comentarios dos ultimos posts do Instagram: [{id, video_id, video_title, url, author, text, likes,
    published_at, reply_count, replied, my_reply}]."""
    d = load()
    if not d.get("ig_id"):
        return []
    me = (d.get("ig_username") or "").lower()
    media = _call("GET", f"{d['ig_id']}/media", d["user_token"], params={
        "fields": "id,caption,permalink,comments_count,comments.limit(50){id,text,username,timestamp,like_count,"
                  "replies{username,text}}", "limit": max_media}).get("data", [])
    out = []
    for m in media:
        title = (m.get("caption") or "(sem legenda)").strip().split("\n")[0][:120]
        for c in (m.get("comments") or {}).get("data", []):
            if (c.get("username") or "").lower() == me:
                continue
            replies = (c.get("replies") or {}).get("data", [])
            mine = [r.get("text", "") for r in replies if (r.get("username") or "").lower() == me]
            out.append({"id": "ig:" + c["id"], "video_id": "ig:" + m["id"], "video_title": title,
                        "url": m.get("permalink", ""), "author": c.get("username", ""), "author_avatar": "",
                        "text": c.get("text", ""), "likes": int(c.get("like_count") or 0),
                        "published_at": c.get("timestamp", ""), "reply_count": len(replies),
                        "replied": 1 if mine else 0, "my_reply": mine[-1] if mine else ""})
    return out


def fb_comments(max_videos=25):
    """Comentarios dos Reels da Pagina do Facebook (mesmo formato do Instagram)."""
    d = load()
    if not d.get("page_id"):
        return []
    token, page = d["page_token"], d["page_id"]
    vids = _call("GET", f"{page}/video_reels", token, params={
        "fields": "id,description,permalink_url", "limit": max_videos}).get("data", [])
    out = []
    for v in vids:
        try:
            cs = _call("GET", f"{v['id']}/comments", token, params={
                "fields": "id,message,from{id,name},created_time,like_count,comments{from{id},message}",
                "limit": 50, "filter": "toplevel"}).get("data", [])
        except Exception:
            continue
        link = v.get("permalink_url", "")
        url = ("https://www.facebook.com" + link) if link.startswith("/") else link
        title = (v.get("description") or "(sem descrição)").strip().split("\n")[0][:120]
        for c in cs:
            if (c.get("from") or {}).get("id") == page:
                continue
            replies = (c.get("comments") or {}).get("data", [])
            mine = [r.get("message", "") for r in replies if (r.get("from") or {}).get("id") == page]
            out.append({"id": "fb:" + c["id"], "video_id": "fb:" + v["id"], "video_title": title, "url": url,
                        "author": (c.get("from") or {}).get("name", "Alguém"), "author_avatar": "",
                        "text": c.get("message", ""), "likes": int(c.get("like_count") or 0),
                        "published_at": c.get("created_time", ""), "reply_count": len(replies),
                        "replied": 1 if mine else 0, "my_reply": mine[-1] if mine else ""})
    return out


def reply_comment(cid, text):
    """Responde um comentario do Instagram (ig:...) ou do Facebook (fb:...)."""
    d = load()
    net, _, raw = cid.partition(":")
    if net == "ig":
        _call("POST", f"{raw}/replies", d["user_token"], params={"message": text})
    elif net == "fb":
        _call("POST", f"{raw}/comments", d["page_token"], params={"message": text})
    else:
        raise RuntimeError("Comentário desconhecido.")
