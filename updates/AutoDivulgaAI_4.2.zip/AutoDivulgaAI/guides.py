"""Guias passo a passo (dentro do painel) para cada pessoa criar as proprias chaves de desenvolvedor.

Enquanto os apps oficiais do AutoDivulga nao forem aprovados pelo Google, TikTok e Meta, cada pessoa
que baixa o programa usa o proprio app (gratis) e conecta so as proprias contas.
"""

GUIDES = {
    "google": {
        "title": "YouTube: criar a chave no Google Cloud",
        "time": "10 a 15 minutos · grátis",
        "intro": "O AutoDivulga usa a API oficial do YouTube. Cada pessoa cria um projeto grátis no Google Cloud e "
                 "baixa um arquivo client_secret.json, que fica só no próprio computador.",
        "steps": [
            ("Crie o projeto", "Entre em <a href='https://console.cloud.google.com/projectcreate' target='_blank'>console.cloud.google.com</a> "
             "com a conta do Google do seu canal e crie um projeto chamado, por exemplo, “AutoDivulga”."),
            ("Ative a API do YouTube", "Menu → APIs e serviços → Biblioteca → procure <b>YouTube Data API v3</b> → Ativar."),
            ("Tela de consentimento", "APIs e serviços → Tela de consentimento OAuth (ou “Google Auth Platform”) → Público <b>Externo</b>. "
             "Preencha nome do app, seu e-mail de suporte e e-mail de contato. Em <b>Público-alvo → Usuários de teste</b>, "
             "adicione o e-mail da conta do seu canal."),
            ("Crie a credencial", "APIs e serviços → Credenciais → Criar credenciais → <b>ID do cliente OAuth</b> → Tipo "
             "<b>App para computador</b> → Criar → <b>Baixar JSON</b>."),
            ("Envie para o AutoDivulga", "Em Contas → YouTube, clique em <b>Enviar client_secret.json</b> e escolha o arquivo baixado. "
             "Depois clique em <b>Conectar canal</b>."),
            ("Evite reconectar toda semana", "Com o app em “Teste”, o Google desconecta a cada 7 dias. Para não acontecer, na tela de "
             "consentimento clique em <b>Publicar app</b> (fica “Em produção, não verificado”). O Google mostra um aviso "
             "“app não verificado” no login: clique em Avançado → Acessar. Funciona para até 100 contas."),
        ],
        "notes": ["Desde 2 de novembro de 2026 o YouTube não deixa mais privados os vídeos enviados pela API de projetos não auditados: "
                  "o vídeo sai com a visibilidade escolhida na publicação.",
                  "Cota: os envios têm uma cota própria (cerca de 100 unidades por envio); leituras e respostas usam as 10.000 unidades diárias."],
    },
    "tiktok": {
        "title": "TikTok: criar o app no TikTok for Developers",
        "time": "10 minutos · grátis",
        "intro": "O AutoDivulga envia os vídeos como rascunho para o app do TikTok e lê os números dos vídeos. "
                 "Cada pessoa cria o próprio app em modo Sandbox, que já funciona para a própria conta.",
        "steps": [
            ("Crie a conta de desenvolvedor", "Entre em <a href='https://developers.tiktok.com/' target='_blank'>developers.tiktok.com</a> "
             "→ Log in → Manage apps → <b>Connect an app</b> (tipo Individual)."),
            ("Preencha o básico", "Nome, ícone (1024×1024), categoria, descrição, links de Termos e Privacidade "
             "(pode usar as páginas em /static/legal/ do AutoDivulga publicadas no GitHub Pages) e plataforma <b>Desktop</b>."),
            ("Adicione os produtos", "Products → <b>Login Kit</b> e <b>Content Posting API</b>. No Login Kit (Desktop), cadastre o "
             "Redirect URI <code>http://127.0.0.1:5055/tiktok/callback/</code>."),
            ("Marque as permissões", "Scopes → <code>user.info.basic</code>, <code>video.upload</code>, "
             "<code>user.info.stats</code> e <code>video.list</code>."),
            ("Crie o Sandbox", "Troque para <b>Sandbox</b> no topo → crie um Sandbox → em <b>Target users</b> adicione o @ da sua conta "
             "do TikTok → <b>Apply changes</b>."),
            ("Conecte", "Copie o Client key e o Client secret do Sandbox para Contas → TikTok → Credenciais, salve e clique em "
             "<b>Conectar conta do TikTok</b>. Depois, em Desempenho → TikTok, clique em <b>Ativar e reconectar</b>."),
        ],
        "notes": ["Para outras pessoas usarem o seu app (sem criar o próprio), ele precisa passar pela revisão do TikTok "
                  "(Submit for review) com um vídeo de demonstração."],
    },
    "meta": {
        "title": "Instagram e Facebook: criar o app na Meta",
        "time": "15 a 20 minutos · grátis",
        "intro": "Um app da Meta conecta o Instagram profissional e a Página do Facebook. Em modo de desenvolvimento ele "
                 "já funciona para quem tem função no app (você).",
        "steps": [
            ("Prepare as contas", "O Instagram precisa ser <b>profissional</b> (em Configurações → Tipo de perfil aparece “Profissional”) e "
             "estar <b>ligado a uma Página do Facebook</b>: no Instagram, Perfil → Editar perfil → <b>Facebook → Conectar</b> e escolha a Página. "
             "Faça isso <b>antes</b> de conectar no AutoDivulga. Os Reels da API só vão para Páginas, não para perfil pessoal."),
            ("Crie o app", "Entre em <a href='https://developers.facebook.com/apps/' target='_blank'>developers.facebook.com/apps</a> → "
             "<b>Criar app</b>. Escolha os casos de uso de <b>gerenciar tudo na sua Página</b> e <b>gerenciar mensagens e conteúdo no "
             "Instagram (API do Instagram com login do Facebook)</b>."),
            ("Permissões", "Em Casos de uso → Personalizar, adicione: <code>pages_show_list</code>, <code>pages_read_engagement</code>, "
             "<code>pages_manage_posts</code>, <code>read_insights</code>, <code>business_management</code>, <code>instagram_basic</code>, "
             "<code>instagram_content_publish</code>, <code>instagram_manage_insights</code> e, para a caixa de comentários, <code>instagram_manage_comments</code>, <code>pages_read_user_content</code> e <code>pages_manage_engagement</code>. Para as hashtags em alta, também o recurso "
             "<b>Instagram Public Content Access</b>."),
            ("Configuração de login", "Apps novos usam o <b>Login do Facebook para Empresas</b>. No menu do app, Login do Facebook para "
             "Empresas → <b>Configurações</b> (a segunda) → Criar configuração: dê um nome, variação <b>Geral</b>, token <b>de acesso do "
             "usuário</b>, marque as 11 permissões acima e clique em Criar. Copie a <b>Identificação da configuração</b>. O endereço "
             "<code>http://localhost:5055/meta/callback/</code> já é aceito em modo de desenvolvimento."),
            ("Copie as chaves", "Configurações do app → Básico → <b>ID do app</b> e <b>Chave secreta do app</b> (clique em Mostrar). "
             "Cole em Contas → Instagram e Facebook → Chaves do app (e o ID da configuração, se tiver) e salve."),
            ("Conecte", "Clique em <b>Conectar Instagram e Facebook</b>, entre com o Facebook que administra a Página, marque a Página "
             "e o Instagram e confirme. Se tiver mais de uma Página, escolha qual vai receber os Reels. Se o Instagram aparecer como "
             "“sem Instagram ligado”, ligue-o à Página no app do Instagram e clique em <b>Trocar de conta</b> para autorizar de novo."),
        ],
        "notes": ["Limite da Meta: 30 Reels por dia na Página e 30 hashtags diferentes por semana na busca de tendências.",
                  "O login dura 60 dias; o painel avisa quando estiver perto de vencer. O token da Página não expira.",
                  "Para outras pessoas entrarem no seu app sem criar o próprio, ele precisa da Revisão do app da Meta (cada permissão) "
                  "e da verificação da empresa."],
    },
}
