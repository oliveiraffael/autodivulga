"""Nucleo compartilhado: caminhos, configuracao (.env), banco SQLite e registro de atividade."""
import os, sqlite3, secrets, sys, threading
from datetime import datetime
from pathlib import Path

VERSION = "4.2"
FROZEN = bool(getattr(sys, "frozen", False))          # versao instalada (AutoDivulgaAI.exe)
BASE = Path(sys.executable).resolve().parent if FROZEN else Path(__file__).resolve().parent   # dados do usuario
RES = Path(getattr(sys, "_MEIPASS", BASE))             # telas e estilos (dentro do .exe quando instalado)
DB = BASE / "autodivulga.db"
ENV = BASE / ".env"
EXPORTS = BASE / "exports"
MEDIA = BASE / "media"          # arquivos enviados arrastando para o painel

STATUSES = ["Rascunho", "Aprovada", "Publicada", "Pausada"]
PLATFORMS = ["YouTube", "TikTok", "Instagram", "Facebook", "Ambas", "Instagram + Facebook", "Todas as redes"]

# Status de uma publicacao na fila
PUB_STATUSES = ["Agendada", "Processando", "Aguardando você", "Publicada", "Erro", "Cancelada"]
PUB_PLATFORMS = ["YouTube", "TikTok", "Instagram", "Facebook"]

DEFAULTS = {
    "AI_MODE": "hybrid",
    "OLLAMA_MODEL": "qwen3.5:4b",
    "AUTOPILOT": "on",                 # executa publicacoes agendadas sozinho
    "POST_TIMES": "12:00,18:00,20:30", # horarios usados no agendamento automatico
    "SMART_TIMES": "on",               # usar os horarios que mais renderam (aprendidos dos seus numeros)
    "MAX_PER_DAY": "2",                # maximo de publicacoes por plataforma por dia
    "YT_CATEGORY": "22",               # Pessoas e blogs
    "YT_MADE_FOR_KIDS": "off",
    "YT_API_UPLOAD": "on",             # desde 02/11/2026 envios sem auditoria nao ficam privados
    "YT_AUDITED": "off",
    "YT_PRIVACY": "public",            # visibilidade padrao no YouTube (agendamento automatico)
    "TT_UPLOAD": "on",                 # enviar ao TikTok como rascunho quando a conta estiver conectada
    "DISCOVERY_AUTO": "on",            # buscar locais de divulgacao 1x por dia para campanhas ativas
    "DISCOVERY_SOURCES": "Reddit,Lemmy,YouTube",
}

_lock = threading.Lock()


# ---------- configuracao ----------
def read_env():
    values = {}
    if ENV.exists():
        for line in ENV.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                values[k.strip()] = v.strip().strip('"').strip("'")
    return values


def load_env():
    for k, v in {**DEFAULTS, **read_env()}.items():
        os.environ[k] = v


def save_env(updates):
    values = read_env()
    values.update(updates)
    lines = ["# Configuracao do AutoDivulga AI (gerado pelo painel). Nao compartilhe este arquivo."]
    lines += [f"{k}={v}" for k, v in values.items()]
    ENV.write_text("\n".join(lines) + "\n", encoding="utf-8")
    load_env()


def setting(key):
    return os.getenv(key, DEFAULTS.get(key, ""))


def secret_key():
    f = BASE / ".secret"
    if not f.exists():
        f.write_text(secrets.token_hex(32), encoding="utf-8")
    return f.read_text(encoding="utf-8").strip()


# ---------- banco ----------
def db():
    con = sqlite3.connect(DB, timeout=15)
    con.row_factory = sqlite3.Row
    return con


def now():
    return datetime.now().strftime("%d/%m/%Y %H:%M")


def now_iso():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def iso_to_br(value):
    try:
        return datetime.strptime(value, "%Y-%m-%d %H:%M").strftime("%d/%m/%Y %H:%M")
    except Exception:
        return value or ""


def log(message):
    with _lock, db() as con:
        con.execute("INSERT INTO activity(message, created_at) VALUES (?,?)", (message, now()))


def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS campaigns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, video_url TEXT NOT NULL, platform TEXT NOT NULL,
            topic TEXT DEFAULT '', audience TEXT DEFAULT '', status TEXT DEFAULT 'Rascunho',
            caption TEXT DEFAULT '', hashtags TEXT DEFAULT '', created_at TEXT NOT NULL
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS activity (
            id INTEGER PRIMARY KEY AUTOINCREMENT, message TEXT NOT NULL, created_at TEXT NOT NULL
        )""")
        cols = {r["name"] for r in con.execute("PRAGMA table_info(campaigns)")}
        for col in ("ai_source", "updated_at", "video_path", "discovered_at", "script"):
            if col not in cols:
                con.execute(f"ALTER TABLE campaigns ADD COLUMN {col} TEXT DEFAULT ''")
        con.execute("""CREATE TABLE IF NOT EXISTS publications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campaign_id INTEGER,
            platform TEXT NOT NULL,
            title TEXT DEFAULT '',
            description TEXT DEFAULT '',
            hashtags TEXT DEFAULT '',
            video_path TEXT DEFAULT '',
            privacy TEXT DEFAULT 'private',
            scheduled_at TEXT NOT NULL,
            status TEXT DEFAULT 'Agendada',
            attempts INTEGER DEFAULT 0,
            next_try_at TEXT DEFAULT '',
            result_url TEXT DEFAULT '',
            message TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT DEFAULT '',
            published_at TEXT DEFAULT ''
        )""")
        pcols = {r["name"] for r in con.execute("PRAGMA table_info(publications)")}
        for col, ddl in (("thumbnail_path", "TEXT DEFAULT ''"), ("views", "INTEGER"), ("likes", "INTEGER"),
                         ("comments", "INTEGER"), ("stats_at", "TEXT DEFAULT ''")):
            if col not in pcols:
                con.execute(f"ALTER TABLE publications ADD COLUMN {col} {ddl}")
        con.execute("CREATE INDEX IF NOT EXISTS ix_pub_due ON publications(status, scheduled_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS places (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campaign_id INTEGER NOT NULL,
            source TEXT NOT NULL,
            name TEXT NOT NULL,
            title TEXT DEFAULT '',
            url TEXT NOT NULL,
            description TEXT DEFAULT '',
            members INTEGER DEFAULT 0,
            language TEXT DEFAULT '',
            keyword TEXT DEFAULT '',
            score INTEGER DEFAULT 0,
            reasons TEXT DEFAULT '',
            rules TEXT DEFAULT '',
            promo_policy TEXT DEFAULT 'desconhecido',
            status TEXT DEFAULT 'Sugerido',
            post_title TEXT DEFAULT '',
            post_text TEXT DEFAULT '',
            posted_url TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT DEFAULT '',
            UNIQUE(campaign_id, url)
        )""")
        con.execute("CREATE INDEX IF NOT EXISTS ix_places ON places(campaign_id, status)")


# ---------- copia de seguranca ----------
BACKUPS = BASE / "backups"


def backup_db(keep=7):
    """Guarda 1 copia por dia do banco (campanhas, publicacoes, historico) e mantem as 7 mais novas."""
    BACKUPS.mkdir(exist_ok=True)
    out = BACKUPS / f"autodivulga-{datetime.now():%Y-%m-%d}.db"
    if out.exists():
        return 0
    src = sqlite3.connect(DB, timeout=15)
    dst = sqlite3.connect(out)
    try:
        src.backup(dst)
    finally:
        dst.close(); src.close()
    for old in sorted(BACKUPS.glob("autodivulga-*.db"))[:-keep]:
        old.unlink(missing_ok=True)
    return 0
