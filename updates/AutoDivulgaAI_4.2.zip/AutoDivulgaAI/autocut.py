"""Cortes automaticos: acha os trechos mais fortes de um video longo (som mais intenso + mais
mudancas de cena) e gera cortes verticais 9:16, com o titulo escrito no topo se voce quiser."""
import os, re, shutil, subprocess, sys, threading
from pathlib import Path

from core import EXPORTS, log

state = {"running": False, "step": "", "source": "", "suggestions": [], "made": [], "error": ""}
FONTS = ["C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/segoeuib.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]


def ffmpeg_ok():
    return bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def _run(cmd, timeout=1800):
    kw = {"capture_output": True, "text": True, "encoding": "utf-8", "errors": "replace", "timeout": timeout}
    if sys.platform.startswith("win"):
        kw["creationflags"] = 0x08000000          # sem janela preta piscando
    return subprocess.run(cmd, **kw)


def duration(path):
    r = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)], 60)
    try:
        return float(r.stdout.strip())
    except ValueError:
        return 0.0


def _loudness(path):
    """RMS do audio (dB) a cada segundo."""
    r = _run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(path), "-vn", "-af",
              "aresample=8000,asetnsamples=n=8000,astats=metadata=1:reset=1,"
              "ametadata=print:key=lavfi.astats.Overall.RMS_level", "-f", "null", "-"])
    vals = []
    for m in re.finditer(r"RMS_level=(-?[\d.]+|-inf)", r.stderr):
        v = m.group(1)
        vals.append(-90.0 if v == "-inf" else max(float(v), -90.0))
    return vals


def _scenes(path):
    """Segundos em que a cena muda (video reduzido para ser rapido)."""
    r = _run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(path), "-an", "-vf",
              "fps=4,scale=160:-2,select='gt(scene,0.30)',showinfo", "-f", "null", "-"])
    return [float(m.group(1)) for m in re.finditer(r"pts_time:([\d.]+)", r.stderr)]


def _fmt(s):
    s = int(s)
    return f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}" if s >= 3600 else f"{s // 60}:{s % 60:02d}"


def suggest(path, clip_len=30, count=3):
    total = duration(path)
    if total <= 0:
        raise RuntimeError("Não consegui ler a duração do vídeo.")
    clip_len = max(5, min(int(clip_len), 180))
    if total <= clip_len * 1.2:
        return [{"start": 0, "end": round(total), "label": f"0:00 – {_fmt(total)}", "score": 100,
                 "why": "o vídeo já é curto: o corte é o vídeo inteiro"}]
    state["step"] = "Ouvindo o áudio…"
    loud = _loudness(path)
    state["step"] = "Procurando mudanças de cena…"
    cuts = _scenes(path)
    n = int(total)
    loud = (loud + [-90.0] * n)[:n]
    lo = sorted(loud)[len(loud) // 10] if loud else -90
    hi = sorted(loud)[len(loud) * 9 // 10] if loud else -20
    norm = [min(max((v - lo) / max(hi - lo, 1), 0), 1) for v in loud]
    density = [0] * n
    for c in cuts:
        if int(c) < n:
            density[int(c)] += 1
    margin = int(total * 0.03)
    cands = []
    for s in range(margin, max(n - clip_len - margin, margin + 1), max(2, clip_len // 6)):
        win = norm[s:s + clip_len]
        if not win:
            continue
        energy = sum(win) / len(win)
        peak = max(win)
        scenes = sum(density[s:s + clip_len]) / (clip_len / 10)
        hook = sum(norm[s:s + 3]) / 3            # comeco forte segura a pessoa
        score = energy * 0.45 + peak * 0.15 + min(scenes, 3) / 3 * 0.25 + hook * 0.15
        cands.append((score, s, energy, scenes, hook))
    cands.sort(reverse=True)
    chosen = []
    for c in cands:
        if all(abs(c[1] - o[1]) >= clip_len for o in chosen):
            chosen.append(c)
        if len(chosen) == count:
            break
    best = chosen[0][0] if chosen else 1
    out = []
    for score, s, energy, scenes, hook in sorted(chosen, key=lambda x: x[1]):
        why = []
        if energy > 0.6:
            why.append("som forte")
        if scenes >= 1.5:
            why.append("muitas mudanças de cena")
        if hook > 0.6:
            why.append("começo forte")
        out.append({"start": s, "end": s + clip_len, "label": f"{_fmt(s)} – {_fmt(s + clip_len)}",
                    "score": round(score * 100 / best), "why": ", ".join(why) or "trecho mais movimentado"})
    return out


def _esc(text):
    return (text.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\u2019").replace("%", "\\%")
            .replace(",", "\\,"))


def _wrap(text, width=22):
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width and cur:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return lines[:3]


def make(path, start, length, out_name, mode="crop", title=""):
    EXPORTS.mkdir(exist_ok=True)
    out = EXPORTS / out_name
    if mode == "blur":
        base = ("split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20:2[bg];"
                "[b]scale=1080:1920:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1")
    else:
        base = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1"
    font = next((f for f in FONTS if os.path.exists(f)), None)
    if title.strip() and font:
        fontfile = font.replace("\\", "/").replace(":", "\\:")
        for i, line in enumerate(_wrap(title.strip())):
            base += (f",drawtext=fontfile='{fontfile}':text='{_esc(line)}':fontsize=64:fontcolor=white:"
                     f"borderw=6:bordercolor=black:x=(w-text_w)/2:y=170+{i}*84")
    cmd = ["ffmpeg", "-y", "-ss", str(start), "-i", str(path), "-t", str(length), "-filter_complex", base,
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(out)]
    r = _run(cmd)
    if r.returncode != 0:
        raise RuntimeError("\n".join(r.stderr.strip().splitlines()[-6:]))
    return out


def _job(path, clip_len, count, make_all, mode, title, prefix):
    try:
        state["step"] = "Analisando o vídeo…"
        sugg = suggest(path, clip_len, count)
        state["suggestions"] = sugg
        if make_all:
            for i, s in enumerate(sugg, 1):
                state["step"] = f"Gerando corte {i} de {len(sugg)}…"
                out = make(path, s["start"], s["end"] - s["start"], f"{prefix}_{i}.mp4", mode, title)
                state["made"].append(str(out))
                log(f"Corte automático gerado: {out.name}")
        state["step"] = "Pronto"
    except subprocess.TimeoutExpired:
        state["error"] = "A análise demorou demais e foi cancelada."
    except Exception as e:
        state["error"] = str(e)
    finally:
        state["running"] = False


def start(path, clip_len=30, count=3, make_all=False, mode="crop", title="", prefix="corte_auto"):
    if state["running"]:
        return False
    state.update(running=True, step="Começando…", source=str(path), suggestions=[], made=[], error="",
                 clip_len=clip_len, mode=mode, title=title, prefix=prefix)
    threading.Thread(target=_job, args=(path, clip_len, count, make_all, mode, title, prefix),
                     name="cortes-auto", daemon=True).start()
    return True


def _make_one(i):
    try:
        s = state["suggestions"][i]
        state["step"] = f"Gerando o corte {s['label']}…"
        out = make(state["source"], s["start"], s["end"] - s["start"], f"{state.get('prefix','corte_auto')}_{i + 1}.mp4",
                   state.get("mode", "crop"), state.get("title", ""))
        state["made"].append(str(out))
        log(f"Corte automático gerado: {out.name}")
        state["step"] = "Pronto"
    except Exception as e:
        state["error"] = str(e)
    finally:
        state["running"] = False


def make_one_async(i):
    if state["running"] or not (0 <= i < len(state["suggestions"])):
        return False
    state.update(running=True, error="")
    threading.Thread(target=_make_one, args=(i,), name="corte-um", daemon=True).start()
    return True
