"""Postagem automatica no Lemmy (API oficial v3), so em comunidades que voce aprovou.

- A senha e usada uma vez para entrar e nao e guardada: fica salvo so o token de sessao.
- Cada comunidade aprovada recebe 1 post por campanha, com intervalo minimo entre posts.
- Comunidades cujas regras proibem divulgacao nunca recebem post automatico.
"""
import re, time
from datetime import datetime, timedelta

import requests

from core import VERSION, db, log, now_iso, save_env, setting, _lock

UA = f"AutoDivulgaAI/{VERSION}"
TIMEOUT = 25
FMT = "%Y-%m-%d %H:%M"
MAX_ATTEMPTS = 3


class LemmyError(Exception):
    pass


def instance():
    url = setting("LEMMY_INSTANCE").strip().rstrip("/")
    if url and not url.startswith("http"):
        url = "https://" + url
    return url


def is_connected():
    return bool(instance() and setting("LEMMY_JWT"))


def auto_on():
    return is_connected() and setting("LEMMY_AUTO") != "off"


def gap_minutes():
    try:
        return max(15, min(24 * 60, int(setting("LEMMY_GAP_MIN") or 45)))
    except ValueError:
        return 45


def _req(method, path, auth=True, base=None, **kw):
    headers = {"User-Agent": UA}
    if auth:
        headers["Authorization"] = f"Bearer {setting('LEMMY_JWT')}"
    try:
        r = requests.request(method, (base or instance()) + "/api/v3" + path, headers=headers, timeout=TIMEOUT, **kw)
    except requests.RequestException as e:
        raise LemmyError(f"o servidor do Lemmy não respondeu ({e.__class__.__name__})") from e
    try:
        data = r.json()
    except ValueError:
        raise LemmyError(f"resposta inesperada do Lemmy (HTTP {r.status_code})")
    if r.status_code >= 400 or (isinstance(data, dict) and data.get("error")):
        raise LemmyError(friendly(data.get("error") if isinstance(data, dict) else str(r.status_code)))
    return data


FRIENDLY = {
    "incorrect_login": "usuário ou senha incorretos",
    "email_not_verified": "confirme o seu e-mail no link que o Lemmy enviou e tente de novo",
    "registration_application_pending": "o cadastro ainda está esperando aprovação dos administradores do servidor",
    "registration_denied": "o servidor recusou o cadastro",
    "missing_totp_token": "a conta usa verificação em 2 etapas; desative-a no Lemmy para conectar aqui",
    "not_logged_in": "a sessão expirou; conecte o Lemmy de novo em Contas",
    "rate_limit_error": "limite de posts do servidor atingido; o AutoDivulga tenta de novo mais tarde",
    "banned_from_community": "você está banido desta comunidade",
    "site_ban": "a conta foi banida do servidor",
    "only_mods_can_post_in_community": "só moderadores podem postar nesta comunidade",
    "couldnt_find_community": "comunidade não encontrada",
    "invalid_url": "o link do vídeo foi recusado",
    "deleted": "a comunidade foi apagada",
}


def friendly(code):
    code = str(code or "")
    return FRIENDLY.get(code, code or "erro desconhecido")


def login(inst, user, password):
    """Entra com usuario e senha e guarda so o token de sessao."""
    inst = inst.strip().rstrip("/")
    if not inst.startswith("http"):
        inst = "https://" + inst
    data = _req("POST", "/user/login", auth=False, base=inst,
                json={"username_or_email": user.strip(), "password": password})
    jwt = data.get("jwt")
    if not jwt:
        if data.get("verify_email_sent"):
            raise LemmyError(FRIENDLY["email_not_verified"])
        if data.get("registration_created"):
            raise LemmyError(FRIENDLY["registration_application_pending"])
        raise LemmyError("o servidor não devolveu a sessão")
    save_env({"LEMMY_INSTANCE": inst, "LEMMY_USER": user.strip(), "LEMMY_JWT": jwt})
    name = whoami() or user.strip()
    save_env({"LEMMY_USER": name})
    log(f"Lemmy conectado: {name} em {inst}")
    return name


def whoami():
    try:
        data = _req("GET", "/site")
        p = (data.get("my_user") or {}).get("local_user_view", {}).get("person", {})
        return p.get("name")
    except LemmyError:
        return None


def disconnect():
    try:
        _req("POST", "/user/logout")
    except Exception:
        pass
    save_env({"LEMMY_JWT": ""})
    log("Lemmy desconectado")


def community_id(actor_url):
    """Id da comunidade no SEU servidor (federa comunidades de outros servidores)."""
    try:
        data = _req("GET", "/resolve_object", params={"q": actor_url})
        cid = ((data.get("community") or {}).get("community") or {}).get("id")
        if cid:
            return cid
    except LemmyError as e:
        if "sessão expirou" in str(e):
            raise
    m = re.match(r"https?://([^/]+)/c/([^/?#]+)", actor_url or "")
    if not m:
        raise LemmyError("endereço de comunidade inválido")
    data = _req("GET", "/community", params={"name": f"{m.group(2)}@{m.group(1)}"})
    return data["community_view"]["community"]["id"]


def create_post(actor_url, title, body, link):
    cid = community_id(actor_url)
    payload = {"name": title[:200], "community_id": cid, "body": body[:9000]}
    if link and link.startswith("http"):
        payload["url"] = link
    data = _req("POST", "/post", json=payload)
    post = data["post_view"]["post"]
    return post.get("ap_id") or f"{instance()}/post/{post['id']}"


# ---------------- fila automatica ----------------
def init():
    with db() as con:
        cols = {r["name"] for r in con.execute("PRAGMA table_info(places)")}
        for col, ddl in (("auto_at", "TEXT DEFAULT ''"), ("auto_error", "TEXT DEFAULT ''"),
                         ("auto_attempts", "INTEGER DEFAULT 0")):
            if col not in cols:
                con.execute(f"ALTER TABLE places ADD COLUMN {col} {ddl}")


def can_auto(place):
    return place["source"] == "Lemmy" and place["promo_policy"] != "proibe" and auto_on()


def next_slot():
    """Proximo horario livre respeitando o intervalo minimo entre posts."""
    gap = timedelta(minutes=gap_minutes())
    with db() as con:
        last = con.execute("""SELECT MAX(t) m FROM (
                                SELECT auto_at t FROM places WHERE auto_at != '' AND status='Aprovado'
                                UNION ALL SELECT updated_at FROM places WHERE source='Lemmy' AND status='Divulgado')""").fetchone()["m"]
    start = datetime.now() + timedelta(minutes=2)
    if last:
        try:
            start = max(start, datetime.strptime(last, FMT) + gap)
        except ValueError:
            pass
    return start.strftime(FMT)


def schedule(plid):
    slot = next_slot()
    with _lock, db() as con:
        con.execute("UPDATE places SET auto_at=?, auto_error='', auto_attempts=0 WHERE id=?", (slot, plid))
    return slot


def unschedule(plid):
    with _lock, db() as con:
        con.execute("UPDATE places SET auto_at='' WHERE id=?", (plid,))


def post_place(plid):
    """Publica um local aprovado agora. Retorna o link do post."""
    with db() as con:
        pl = con.execute("""SELECT p.*, c.video_url, c.title AS ctitle FROM places p
                            JOIN campaigns c ON c.id = p.campaign_id WHERE p.id=?""", (plid,)).fetchone()
    if not pl or pl["status"] != "Aprovado":
        raise LemmyError("local não está aprovado")
    if pl["promo_policy"] == "proibe":
        raise LemmyError("as regras desta comunidade proíbem divulgação")
    title = pl["post_title"] or pl["ctitle"]
    import links
    link = links.link({"id": pl["campaign_id"], "video_url": pl["video_url"]}, "lm")
    url = create_post(pl["url"], title, pl["post_text"] or title, link)
    with _lock, db() as con:
        con.execute("""UPDATE places SET status='Divulgado', posted_url=?, auto_at='', auto_error='',
                       updated_at=? WHERE id=?""", (url, now_iso(), plid))
    log(f"Post automático no Lemmy: {pl['name']}")
    return url


def run_due():
    """Chamado pelo agendador a cada 30 s: publica no maximo 1 post vencido por vez."""
    if not auto_on():
        return 0
    with db() as con:
        row = con.execute("""SELECT id, auto_attempts FROM places WHERE source='Lemmy' AND status='Aprovado'
                             AND auto_at != '' AND auto_at <= ? ORDER BY auto_at LIMIT 1""", (now_iso(),)).fetchone()
    if not row:
        return 0
    try:
        post_place(row["id"])
        return 1
    except LemmyError as e:
        tries = row["auto_attempts"] + 1
        retry = "" if tries >= MAX_ATTEMPTS or "proíbem" in str(e) or "banido" in str(e) \
            else (datetime.now() + timedelta(hours=tries)).strftime(FMT)
        with _lock, db() as con:
            con.execute("UPDATE places SET auto_error=?, auto_attempts=?, auto_at=? WHERE id=?",
                        (str(e), tries, retry, row["id"]))
        if "sessão expirou" in str(e):
            save_env({"LEMMY_JWT": ""})
        log(f"Post automático no Lemmy falhou: {e}")
        return 0
