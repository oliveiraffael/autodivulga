"""Varias contas por rede: guarda as conexoes em contas/<rede>/<id>/ e troca qual esta ativa.

A conta ativa continua nos arquivos de sempre (youtube_token.json, tiktok_token.json, meta_token.json),
entao o resto do programa nao muda. Trocar de conta nao revoga nada: so troca os arquivos de lugar.
"""
import json, shutil, time
from pathlib import Path

from core import BASE, log

STORE = BASE / "contas"
FILES = {"youtube": ["youtube_token.json", "youtube_channel.json"],
         "tiktok": ["tiktok_token.json", "tiktok_user.json"],
         "meta": ["meta_token.json"]}
NAMES = {"youtube": "YouTube", "tiktok": "TikTok", "meta": "Instagram e Facebook"}


def _read(name):
    try:
        return json.loads((BASE / name).read_text(encoding="utf-8"))
    except Exception:
        return {}


def current(platform):
    """(id, nome) da conta ativa, ou (None, None)."""
    if platform == "youtube":
        if not (BASE / "youtube_token.json").exists():
            return None, None
        ch = _read("youtube_channel.json")
        return (ch.get("id") or "canal"), (ch.get("title") or "Canal do YouTube")
    if platform == "tiktok":
        tok = _read("tiktok_token.json")
        if not tok:
            return None, None
        return tok.get("open_id") or "conta", _read("tiktok_user.json").get("display_name") or "Conta do TikTok"
    if platform == "meta":
        d = _read("meta_token.json")
        if not d.get("user_token"):
            return None, None
        label = d.get("user_name") or "Conta da Meta"
        if d.get("page_name"):
            label += f" · {d['page_name']}" + (f" (@{d['ig_username']})" if d.get("ig_username") else "")
        return f"{d.get('user_id', 'meta')}_{d.get('page_id', '')}".strip("_"), label
    return None, None


def _safe(ident):
    return "".join(ch for ch in str(ident) if ch.isalnum() or ch in "-_")[:80] or "conta"


def stash(platform):
    """Guarda uma copia da conta ativa (chamado ao conectar e antes de trocar)."""
    ident, label = current(platform)
    if not ident:
        return None
    folder = STORE / platform / _safe(ident)
    folder.mkdir(parents=True, exist_ok=True)
    for name in FILES[platform]:
        src = BASE / name
        if src.exists():
            shutil.copy2(src, folder / name)
    (folder / "conta.json").write_text(json.dumps({"label": label, "saved": time.strftime("%d/%m/%Y %H:%M")},
                                                  ensure_ascii=False), encoding="utf-8")
    return _safe(ident)


def listing(platform):
    active, _ = current(platform)
    out = []
    base = STORE / platform
    if base.is_dir():
        for folder in sorted(base.iterdir()):
            if folder.is_dir():
                try:
                    info = json.loads((folder / "conta.json").read_text(encoding="utf-8"))
                except Exception:
                    info = {"label": folder.name}
                out.append({"id": folder.name, "label": info.get("label", folder.name),
                            "active": bool(active) and folder.name == _safe(active)})
    return out


def detach(platform):
    """Tira a conta ativa (guardada antes) sem revogar, para conectar outra."""
    stash(platform)
    for name in FILES[platform]:
        (BASE / name).unlink(missing_ok=True)


def switch(platform, ident):
    folder = STORE / platform / _safe(ident)
    if not folder.is_dir():
        raise RuntimeError("Conta não encontrada.")
    stash(platform)
    for name in FILES[platform]:
        src, dst = folder / name, BASE / name
        if src.exists():
            shutil.copy2(src, dst)
        else:
            dst.unlink(missing_ok=True)
    _, label = current(platform)
    log(f"{NAMES[platform]}: conta trocada para {label}")
    return label


def forget(platform, ident):
    active, _ = current(platform)
    if active and _safe(active) == _safe(ident):
        raise RuntimeError("Essa é a conta ativa. Troque para outra antes de esquecer esta.")
    shutil.rmtree(STORE / platform / _safe(ident), ignore_errors=True)
