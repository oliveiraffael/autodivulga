"""Caixa de comentarios: le os comentarios de todos os videos do canal do YouTube num lugar so,
mostra quais ainda nao tem resposta sua, sugere resposta com a IA local e responde pelo painel.

Cota: ler custa 1 unidade por pagina de 100 comentarios; responder custa 50 unidades.
Os comentarios ficam guardados no maximo 30 dias sem atualizacao (politica da API do YouTube).
"""
import threading, time
from datetime import datetime, timedelta

from core import db, log, now_iso, _lock

youtube = None
meta = None
NET_NAMES = {"yt": "YouTube", "ig": "Instagram", "fb": "Facebook"}
state = {"running": False, "error": "", "at": 0.0}
MAX_PAGES = 5


def init():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS yt_comments (
            id TEXT PRIMARY KEY, video_id TEXT, video_title TEXT DEFAULT '', author TEXT DEFAULT '',
            author_avatar TEXT DEFAULT '', text TEXT DEFAULT '', likes INTEGER DEFAULT 0,
            published_at TEXT DEFAULT '', reply_count INTEGER DEFAULT 0, replied INTEGER DEFAULT 0,
            my_reply TEXT DEFAULT '', status TEXT DEFAULT 'novo', updated_at TEXT DEFAULT '')""")
        cols = {r["name"] for r in con.execute("PRAGMA table_info(yt_comments)")}
        if "net" not in cols:
            con.execute("ALTER TABLE yt_comments ADD COLUMN net TEXT DEFAULT 'yt'")
        if "url" not in cols:
            con.execute("ALTER TABLE yt_comments ADD COLUMN url TEXT DEFAULT ''")


def _local(iso):
    try:
        return datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone().strftime("%Y-%m-%d %H:%M")
    except Exception:
        return ""


def refresh():
    if not youtube or not youtube.is_connected():
        state["error"] = "Conecte o canal do YouTube em Contas."
        return 0
    state.update(running=True, error="")
    try:
        yt = youtube.service()
        ch = yt.channels().list(part="id", mine=True).execute().get("items", [])
        if not ch:
            state["error"] = "A conta conectada não tem canal."
            return 0
        my_id = ch[0]["id"]
        try:
            with db() as con:
                titles = {r["video_id"]: r["title"] for r in con.execute("SELECT video_id, title FROM yt_videos")}
        except Exception:
            titles = {}
        rows, token = [], None
        for _ in range(MAX_PAGES):
            resp = yt.commentThreads().list(part="snippet,replies", allThreadsRelatedToChannelId=my_id,
                                            maxResults=100, order="time", textFormat="plainText",
                                            pageToken=token).execute()
            for it in resp.get("items", []):
                top = it["snippet"]["topLevelComment"]["snippet"]
                if (top.get("authorChannelId") or {}).get("value") == my_id:
                    continue                      # comentario do proprio canal
                replies = (it.get("replies") or {}).get("comments", [])
                mine = [r["snippet"]["textDisplay"] for r in replies
                        if (r["snippet"].get("authorChannelId") or {}).get("value") == my_id]
                vid = it["snippet"].get("videoId", "")
                rows.append({"id": it["id"], "video_id": vid, "video_title": titles.get(vid, ""),
                             "author": top.get("authorDisplayName", ""),
                             "author_avatar": top.get("authorProfileImageUrl", ""),
                             "text": top.get("textDisplay", ""), "likes": int(top.get("likeCount", 0)),
                             "published_at": _local(top.get("publishedAt", "")),
                             "reply_count": int(it["snippet"].get("totalReplyCount", 0)),
                             "replied": 1 if mine else 0, "my_reply": mine[-1] if mine else ""})
            token = resp.get("nextPageToken")
            if not token:
                break
        with _lock, db() as con:
            for r in rows:
                old = con.execute("SELECT status, my_reply FROM yt_comments WHERE id=?", (r["id"],)).fetchone()
                status = "respondido" if r["replied"] else (old["status"] if old and old["status"] == "ignorado" else "novo")
                con.execute("""INSERT OR REPLACE INTO yt_comments (id, video_id, video_title, author, author_avatar,
                               text, likes, published_at, reply_count, replied, my_reply, status, updated_at)
                               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                            (r["id"], r["video_id"], r["video_title"], r["author"], r["author_avatar"], r["text"],
                             r["likes"], r["published_at"], r["reply_count"], r["replied"],
                             r["my_reply"] or (old["my_reply"] if old else ""), status, now_iso()))
            limit = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d %H:%M")
            con.execute("DELETE FROM yt_comments WHERE updated_at<?", (limit,))
        state["at"] = time.time()
        return len(rows)
    except Exception as e:
        msg = str(e)
        if "insufficient" in msg.lower():
            msg = "falta a permissão de gerenciar comentários. Clique em Ativar comentários."
        elif "quota" in msg.lower():
            msg = "limite diário da API do YouTube atingido. Tente de novo amanhã."
        state["error"] = f"Não foi possível ler os comentários: {msg}"
        return 0
    finally:
        state["running"] = False


def _save_rows(rows, net):
    with _lock, db() as con:
        for r in rows:
            old = con.execute("SELECT status, my_reply FROM yt_comments WHERE id=?", (r["id"],)).fetchone()
            status = "respondido" if r["replied"] else (old["status"] if old and old["status"] in ("ignorado", "respondido") else "novo")
            con.execute("""INSERT OR REPLACE INTO yt_comments (id, video_id, video_title, author, author_avatar,
                           text, likes, published_at, reply_count, replied, my_reply, status, updated_at, net, url)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (r["id"], r["video_id"], r["video_title"], r["author"], r["author_avatar"], r["text"],
                         r["likes"], _local(r["published_at"]) or r["published_at"][:16].replace("T", " "),
                         r["reply_count"], r["replied"], r["my_reply"] or (old["my_reply"] if old else ""),
                         status, now_iso(), net, r.get("url", "")))


def meta_ready():
    try:
        return bool(meta and meta.is_connected() and meta.can_comments())
    except Exception:
        return False


def refresh_meta():
    """Le os comentarios do Instagram e do Facebook (precisa das permissoes de comentarios da Meta)."""
    if not meta_ready():
        return 0
    n, errors = 0, []
    for net, fn in (("ig", meta.ig_comments), ("fb", meta.fb_comments)):
        try:
            rows = fn()
            _save_rows(rows, net)
            n += len(rows)
        except Exception as e:
            errors.append(f"{NET_NAMES[net]}: {e}")
    if errors:
        state["error"] = "Não foi possível ler os comentários (" + "; ".join(errors) + ")"
    return n


def refresh_all():
    n = 0
    if youtube and youtube.is_connected() and youtube.can_reply():
        n += refresh()
    state["running"] = True
    try:
        n += refresh_meta()
    finally:
        state["running"] = False
        state["at"] = time.time()
    return n


def refresh_async():
    if not state["running"]:
        state["running"] = True
        threading.Thread(target=refresh_all, name="comentarios", daemon=True).start()


def stats_hook():
    return refresh_all()


def counts():
    try:
        with db() as con:
            out = {"novo": 0, "respondido": 0, "ignorado": 0}
            for r in con.execute("SELECT status, COUNT(*) n FROM yt_comments GROUP BY status"):
                out[r["status"]] = r["n"]
            return out
    except Exception:
        return {"novo": 0, "respondido": 0, "ignorado": 0}


def listing(status="novo", net=""):
    sql = "SELECT * FROM yt_comments WHERE 1=1"
    args = []
    if status in ("novo", "respondido", "ignorado"):
        sql += " AND status=?"; args.append(status)
    if net in NET_NAMES:
        sql += " AND COALESCE(net,'yt')=?"; args.append(net)
    with db() as con:
        return con.execute(sql + " ORDER BY published_at DESC LIMIT 300", args).fetchall()


def get(cid):
    with db() as con:
        return con.execute("SELECT * FROM yt_comments WHERE id=?", (cid,)).fetchone()


def set_status(cid, status):
    with _lock, db() as con:
        con.execute("UPDATE yt_comments SET status=? WHERE id=?", (status, cid))


def reply(cid, text):
    """Publica a resposta no YouTube (precisa da permissao youtube.force-ssl)."""
    text = (text or "").strip()[:1500]
    if not text:
        raise RuntimeError("Escreva a resposta primeiro.")
    if cid.startswith(("ig:", "fb:")):
        meta.reply_comment(cid, text)
        with _lock, db() as con:
            con.execute("UPDATE yt_comments SET status='respondido', replied=1, my_reply=?, reply_count=reply_count+1 "
                        "WHERE id=?", (text, cid))
        log(f"Resposta publicada num comentário do {NET_NAMES[cid[:2]]}")
        return
    if not youtube.can_reply():
        raise RuntimeError("Ative as respostas pelo painel (botão no topo desta página).")
    yt = youtube.service()
    yt.comments().insert(part="snippet", body={"snippet": {"parentId": cid, "textOriginal": text}}).execute()
    with _lock, db() as con:
        con.execute("UPDATE yt_comments SET status='respondido', replied=1, my_reply=?, reply_count=reply_count+1 "
                    "WHERE id=?", (text, cid))
    log("Resposta publicada num comentário do YouTube")


def suggest(cid):
    """Sugere uma resposta curta e humana com a IA local (o usuario revisa antes de enviar)."""
    import ai_writer
    c = get(cid)
    if not c:
        return ""
    rede = NET_NAMES.get((c["net"] if "net" in c.keys() else "") or "yt", "YouTube")
    prompt = (f"Você é o criador do perfil e vai responder um comentário no seu vídeo do {rede}.\n"
              f"Vídeo: {c['video_title'] or 'um episódio da sua série animada'}\n"
              f"Comentário de {c['author']}: \"{c['text'][:600]}\"\n\n"
              "Escreva UMA resposta em português do Brasil, simpática e natural, com no máximo 2 frases, "
              "agradecendo de forma específica (nada genérico) e terminando com uma pergunta curta que puxe a "
              "conversa sobre a história. Sem hashtags, sem links, sem pedir inscrição de forma insistente. "
              'Responda SOMENTE com JSON: {"resposta": "..."}')
    obj = ai_writer._ask_json(prompt) or {}
    return str(obj.get("resposta") or obj.get("reply") or "").strip()[:600]
